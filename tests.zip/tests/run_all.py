#!/usr/bin/env python3
"""Executa as suítes de teste do Wolfin e mostra um resumo claro (com a causa de cada falha).

  python3 tests/run_all.py                 # suítes principais (cálculos, pagamentos, armazenamento, segurança, backups, relatórios, navegação, PWA)
  python3 tests/run_all.py --full          # + visual/UX (tutorial, tema, mascote, boas-vindas...)
  python3 tests/run_all.py --grupo seguranca
  python3 tests/run_all.py --suite armazenamento
  python3 tests/run_all.py --list

Sai com código 1 se QUALQUER teste falhar (o GitHub Actions marca a execução como falha).
Usa só dados fictícios, em navegadores novos e isolados: nunca toca em dados reais."""
import argparse,os,re,subprocess,sys,time,xml.sax.saxutils as X
HERE=os.path.dirname(os.path.abspath(__file__));REPORT=os.path.join(HERE,'report')
Q={'NOSKIP':'1','SK_TEST':'1'}
# (nome, grupo, env, timeout_s, descrição)
SUITES=[
 ('estatico','estatico',Q,150,'Sintaxe do JavaScript (app e Service Worker), HTML, manifesto, ícones, versão e abertura sem erros'),
 ('marca_wolfin','estatico',Q,300,'Identidade Wolfin: nome, slogan, título, manifesto, nada da marca antiga, e conta antiga abre sem perder dados'),
 ('calculos_nucleo','calculos',Q,300,'Saldo, fluxo, dívidas, caixinhas, parcelas e cartões: 150 cenários aleatórios contra recálculo independente'),
 ('calculos_situacao','calculos',Q,300,'Situação financeira com cartões (fatura aberta, parcial, quitada, atrasada, vários cartões)'),
 ('pagamentos_cartao','pagamentos',Q,300,'Pagamentos de fatura: parcial, quitação, excesso, duplicidade e dados antigos'),
 ('armazenamento','armazenamento',Q,330,'Salvamento (modo normal e protegido), falhas de gravação, ordem, fechar durante o salvamento, duas janelas'),
 ('seguranca_acesso','seguranca',{'NOSKIP':'1'},330,'Login, senha incorreta, criptografia, código de recuperação e troca de senha'),
 ('seguranca_tentativas','seguranca',Q,330,'Espera progressiva, 3 locais de controle, reinício do navegador, recuperação durante a espera'),
 ('backup_importacao','backups',Q,420,'Importação: arquivos válidos, inválidos, corrompidos, duplicados, versões antigas e criptografados'),
 ('backup_modo_protegido','backups',Q,330,'Importação no modo protegido, reversão em falhas e tela de boas-vindas'),
 ('backup_basico','backups',{'NOSKIP':'1'},240,'Exportação e importação básicas (comum e criptografada, acentos na senha)'),
 ('relatorios','relatorios',Q,330,'Relatórios: resumo, indicadores, comprometimento, recorrentes, dívidas e comparação conferidos em Python'),
 ('navegacao_rapida','navegacao',{'NOSKIP':'1'},150,'Navegação entre as telas e a barra inferior'),
 ('auditoria_geral','navegacao',{},300,'Auditoria geral: telas, janelas, formulários, tema, calculadora, backup'),
 ('acessibilidade','navegacao',Q,420,'Acessibilidade: toque, nomes, foco, teclado, janelas, leitor de tela, redução de movimento, contraste'),
 ('pwa_instalacao','pwa',{},180,'PWA: instalável, manifesto, ícones e funcionamento offline'),
 ('pwa_cache_atualizacao','pwa',Q,420,'Service Worker: caches próprios, atualização, falha na instalação, offline, outros projetos intactos'),
 # --- visual / experiência (rodam com --full) ---
 ('intro_wolfin','extras',Q,300,'Intro animada: logo, nome e slogan, temas, pular, login, navegação, movimento reduzido, offline'),
 ('tutorial','extras',Q,300,'Tutorial do primeiro acesso'),
 ('tema_perola','extras',Q,330,'Tema Pérola, cores e etapa de cor no cadastro'),
 ('mascote_estilos','extras',{},330,'Estilos do mascote'),
 ('boas_vindas','extras',{'NOSKIP':'1'},200,'Tela de boas-vindas e criação de conta'),
 ('login_visual','extras',{'NOSKIP':'1'},150,'Login, sol/lua, olho da senha'),
 ('acabamento_visual','extras',{'NOSKIP':'1'},200,'Animações e transições'),
]
def run_one(name,env,timeout):
    t0=time.time();e=dict(os.environ);e.update(env);e['PYTHONPATH']=os.path.join(HERE,'lib')+os.pathsep+e.get('PYTHONPATH','');e['PYTHONUNBUFFERED']='1'
    try:
        p=subprocess.run([sys.executable,os.path.join(HERE,'suites',name+'.py')],capture_output=True,text=True,timeout=timeout,env=e,encoding='utf-8',errors='replace');out=(p.stdout or '')+('\n'+p.stderr if p.stderr.strip() else '');rc=p.returncode;to=False
    except subprocess.TimeoutExpired as ex:
        out=(ex.stdout.decode('utf-8','replace') if isinstance(ex.stdout,bytes) else (ex.stdout or ''))+'\n[tempo esgotado]';rc=-9;to=True
    lines=out.splitlines();passes=[l for l in lines if l.startswith('PASS ')];fails=[l for l in lines if l.startswith('FAIL ')]
    m=None
    for l in reversed(lines):
        m=re.match(r'^(?:RESUMO:\s*)?(\d+)\s*/\s*(\d+)(?:\s+testes aprovados)?$',l.strip())
        if m:break
    tb=[l for l in lines if 'Traceback' in l]
    crashed=bool(tb) or to or rc not in(0,None) or not m
    ok_=(not fails) and (not crashed) and bool(m) and m.group(1)==m.group(2) and int(m.group(2))>0
    return {'nome':name,'ok':ok_,'passes':len(passes),'fails':fails,'total':int(m.group(2)) if m else len(passes)+len(fails),'crash':crashed and not fails or (crashed and bool(tb)),'timeout':to,'out':out,'secs':time.time()-t0}
def explica(out):
    """Resume em uma frase por que a suíte parou (erro de Python/Playwright)."""
    ex=[l.strip() for l in out.splitlines() if re.match(r'^\w*(Error|Exception|Timeout\w*)\b.*:',l.strip()) or 'Timeout' in l and 'exceeded' in l]
    base=ex[-1][:220] if ex else 'a suíte terminou sem relatar o resultado'
    if 'data-lk=nosec' in out or ('wait_for_selector' in out and '#nav' in out):base+=' — o app não abriu: provável erro de JavaScript (veja a suíte "estatico")'
    if 'tempo esgotado' in out:base='tempo esgotado (a suíte travou ou ficou lenta demais)'
    return base
def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--suite',help='nome(s) separados por vírgula');ap.add_argument('--grupo',help='grupo(s) separados por vírgula');ap.add_argument('--full',action='store_true');ap.add_argument('--list',action='store_true')
    ap.add_argument('--retries',type=int,default=int(os.environ.get('WS_RETRIES','1')),help='repetições de uma suíte que falhou (ambiente instável); 0 desliga')
    a=ap.parse_args()
    if a.list:
        for n,g,_,_,d in SUITES:print(f'{n:26s} [{g}] {d}')
        return 0
    sel=SUITES
    if a.suite:names=set(a.suite.split(','));sel=[s for s in SUITES if s[0] in names]
    elif a.grupo:gs=set(a.grupo.split(','));sel=[s for s in SUITES if s[1] in gs]
    elif not a.full:sel=[s for s in SUITES if s[1]!='extras']
    if not sel:print('Nenhuma suíte selecionada. Use --list.');return 2
    os.makedirs(REPORT,exist_ok=True);results=[]
    print(f'Executando {len(sel)} suíte(s)…\n',flush=True)
    for n,g,env,to,d in sel:
        r=run_one(n,env,to);tries=1;flaky=False
        while not r['ok'] and tries<=a.retries:
            print(f'  ↻ {n}: falhou, repetindo ({tries}/{a.retries})…',flush=True);first=r;r=run_one(n,env,to);tries+=1
            if r['ok']:flaky=True;r['primeira']=first
        r.update(grupo=g,desc=d,flaky=flaky);results.append(r)
        open(os.path.join(REPORT,n+'.log'),'w',encoding='utf-8').write(r['out'])
        sym='✅' if r['ok'] else '❌';print(f"{sym} {n:26s} {r['passes']:>3}/{r['total']:<3} testes  {r['secs']:6.1f}s{'  (passou só na repetição — instável)' if flaky else ''}",flush=True)
    bad=[r for r in results if not r['ok']];fl=[r for r in results if r['flaky']];tp=sum(r['passes'] for r in results);tt=sum(r['total'] for r in results)
    lines=['# Resultado dos testes do Wolfin','',f'**{tp} de {tt} verificações passaram** em {len(results)} suítes — '+('✅ **tudo certo**' if not bad else f'❌ **{len(bad)} suíte(s) com falha**'),'','| Suíte | Grupo | Resultado | Tempo |','|---|---|---|---|']
    for r in results:lines.append(f"| {r['nome']} | {r['grupo']} | {'✅ '+str(r['passes'])+'/'+str(r['total']) if r['ok'] else '❌ '+str(r['passes'])+'/'+str(r['total'])}{' ⚠️ instável' if r['flaky'] else ''} | {r['secs']:.0f}s |")
    if bad:
        lines+=['','## Falhas','']
        for r in bad:
            lines.append(f"### ❌ {r['nome']}  \nReproduzir: `python3 tests/run_all.py --suite {r['nome']}`  \nLog completo: `tests/report/{r['nome']}.log`\n")
            if r['timeout']:lines.append('- Tempo esgotado (a suíte travou ou ficou lenta demais).')
            for f in r['fails']:lines.append('- '+f.replace('FAIL ','',1)[:400])
            if not r['fails']:
                lines.append('- '+explica(r['out']))
                tail='\n'.join(r['out'].strip().splitlines()[-8:]);lines+=['- Final do log:','```',tail,'```']
    if fl:
        lines+=['','## ⚠️ Passaram só na repetição (ambiente instável)','']
        for r in fl:
            ff=r.get('primeira',{}).get('fails',[]) or [ '(erro/tempo)' ]
            lines.append(f"- **{r['nome']}** — falha na 1ª tentativa: "+'; '.join(x.replace('FAIL ','',1)[:120] for x in ff[:2]))
    md='\n'.join(lines)+'\n';open(os.path.join(REPORT,'resumo.md'),'w',encoding='utf-8').write(md)
    if os.environ.get('GITHUB_STEP_SUMMARY'):open(os.environ['GITHUB_STEP_SUMMARY'],'a',encoding='utf-8').write(md)
    # JUnit para ferramentas
    tcs=''
    for r in results:
        tcs+=f'<testcase classname="{X.escape(r["grupo"])}" name="{X.escape(r["nome"])}" time="{r["secs"]:.1f}">'
        if not r['ok']:tcs+='<failure message="'+X.quoteattr('; '.join(f[:200] for f in r['fails'][:3]) or 'erro/tempo esgotado')[1:-1]+'"/>'
        tcs+='</testcase>'
    open(os.path.join(REPORT,'junit.xml'),'w',encoding='utf-8').write(f'<?xml version="1.0" encoding="UTF-8"?><testsuite name="wallstreet" tests="{len(results)}" failures="{len(bad)}">{tcs}</testsuite>')
    print('\n'+('='*60));print(md)
    if bad:
        for r in bad:
            for f in r['fails'][:20]:print(f"::error title=Falha em {r['nome']}::{f.replace('FAIL ','',1)[:300]}")
            if not r['fails']:print(f"::error title=Erro em {r['nome']}::a suíte terminou com erro ou tempo esgotado (veja tests/report/{r['nome']}.log)")
    return 1 if bad else 0
if __name__=='__main__':sys.exit(main())
