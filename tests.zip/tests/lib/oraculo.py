"""Recálculo INDEPENDENTE (Python puro) das regras financeiras, usado para conferir o que o app calcula.
Datas fixas dos testes: hoje = 2026-11-15, mês atual = 2026-11."""
import datetime
TODAY=datetime.date(2026,11,15);CM='2026-11'
def dim(y,m):return (datetime.date(y+(m==12),m%12+1,1)-datetime.timedelta(days=1)).day
def shift(ym,k):y,m=map(int,ym.split('-'));t=y*12+m-1+k;return '%04d-%02d'%(t//12,t%12+1)
def rows(S,t,m):return [i for i in S['items'] if i['t']==t and ((i.get('fixed') and m>=i['from']) or (not i.get('fixed') and i.get('ym')==m))]
def duedate(i,m):y,mo=map(int,m.split('-'));return datetime.date(y,mo,min(i['day'],dim(y,mo)))
def stat(i,m):return 'ok' if (i.get('done') or {}).get(m) is not None else ('late' if duedate(i,m)<TODAY else 'pend')
def flows(S):
    f={}
    g=lambda k:f.setdefault(k,{'inc':0,'exp':0,'dp':0,'bx':0})
    for i in S['items']:
        for k,c in (i.get('done') or {}).items():g(k)[i['t']]+=c
    for d in S['debts']:
        for p in d['pays']:g(p['d'][:7])['dp']+=p['c']
    for b in S['boxes']:
        for p in b['moves']:g(p['d'][:7])['bx']+=p['c']
    for k in S.get('cards',[]) or []:
        for p in k.get('pays',[]) or []:g(p['d'][:7])['exp']+=p['c']
    for q in S.get('parc',[]) or []:   # parcela paga sai do caixa na data do pagamento (paidOn) > vencimento > mês da parcela
        if q.get('paid') and isinstance(q.get('c'),int) and q['c']>0:
            d=q.get('paidOn') or q.get('due') or ((q['ym']+'-01') if q.get('ym') else '')
            if len(d)>=7 and d[4]=='-':g(d[:7])['exp']+=q['c']
    return f
def net(x):return x['inc']-x['exp']-x['dp']-x['bx']
def balance(S):return (S.get('opening') or {}).get('c',0)+sum(net(v) for v in flows(S).values())
def flow(S,m):
    F=flows(S);f=F.get(m,{'inc':0,'exp':0,'dp':0,'bx':0});ini=(S.get('opening') or {}).get('c',0)+sum(net(v) for k,v in F.items() if k<m)
    return {**f,'res':net(f),'ini':ini,'fin':ini+net(f)}
def parts(k):
    out=[]
    for b in k['buys']:
        np_=b.get('np') or 1;base=b['c']//np_;rest=b['c']-base*np_;dt=b['dt'];ym0=dt[:7]
        inv=ym0 if int(dt[8:])<=min(k['cl'],dim(*map(int,ym0.split('-')))) else shift(ym0,1)
        for n in range(np_):out.append({'n':n+1,'of':np_,'ym':shift(inv,n),'cm':shift(ym0,n),'c':base+(rest if n==0 else 0)})
    return out
def cc_tot(k,ym):return sum(p['c'] for p in parts(k) if p['ym']==ym)
def cc_paid(k,ym):return sum(p['c'] for p in (k.get('pays') or []) if p['ym']==ym)
def cc_owed(k):return max(0,sum(p['c'] for p in parts(k))-sum(p['c'] for p in (k.get('pays') or [])))
def cc_due(k,ym):
    y=ym if k['dd']>k['cl'] else shift(ym,1);yy,mm=map(int,y.split('-'));return datetime.date(yy,mm,min(k['dd'],dim(yy,mm)))
def commit(S,m):
    z=lambda:{'tot':0,'paid':0,'pend':0,'late':0}
    ct,pt,cc=z(),z(),z()
    for i in rows(S,'exp',m):
        s=stat(i,m);ct['tot']+=i['c']
        if s=='ok':ct['paid']+=i['done'][m]
        elif s=='late':ct['late']+=i['c']
        else:ct['pend']+=i['c']
    for q in [q for q in S['parc'] if q['ym']==m]:
        pt['tot']+=q['c']
        if q.get('paid'):pt['paid']+=q['c']
        elif (q.get('due') and datetime.date.fromisoformat(q['due'])<TODAY) or (not q.get('due') and q['ym']<CM):pt['late']+=q['c']
        else:pt['pend']+=q['c']
    for k in S.get('cards',[]) or []:
        pp=parts(k);yms={p['ym'] for p in pp}|{p['ym'] for p in (k.get('pays') or [])}
        for ym in yms:
            dd=cc_due(k,ym)
            if dd.isoformat()[:7]!=m:continue
            t=cc_tot(k,ym);pd=min(cc_paid(k,ym),t);rest=t-pd
            if not t:continue
            cc['tot']+=t;cc['paid']+=pd
            if rest>0:
                if dd<TODAY:cc['late']+=rest
                else:cc['pend']+=rest
    R_=sum(i['c'] for i in rows(S,'inc',m));Cm=ct['tot']+pt['tot']+cc['tot']
    return {'R':R_,'ct':ct,'pt':pt,'cc':cc,'Cm':Cm,'paid':ct['paid']+pt['paid']+cc['paid'],'pend':ct['pend']+pt['pend']+cc['pend'],'late':ct['late']+pt['late']+cc['late']}
