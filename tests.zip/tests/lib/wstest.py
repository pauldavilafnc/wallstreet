"""Infra comum dos testes do Wolfin (só biblioteca padrão + Playwright).
Cada suíte importa `from wstest import *`: caminhos relativos ao repositório, servidor local próprio (porta livre), dados fictícios.
NUNCA usa dados reais: tudo roda em navegadores novos, isolados, com dados de teste."""
import os,sys,socket,threading,tempfile,json,hashlib
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
LIB=os.path.dirname(os.path.abspath(__file__));TESTS=os.path.dirname(LIB);ROOT=os.path.dirname(TESTS)
FIX=os.path.join(TESTS,'fixtures');TMP=os.environ.get('WS_TMP') or tempfile.mkdtemp(prefix='wstest_')
os.makedirs(os.path.join(TMP,'shots'),exist_ok=True)
FILE_URL='file://'+ROOT+'/index.html'
def free_port():
    s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p
class _H(SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
    def log_error(self,*a):pass
def start_server(directory,port):
    srv=ThreadingHTTPServer(('127.0.0.1',port),partial(_H,directory=directory));threading.Thread(target=srv.serve_forever,daemon=True).start();return srv
PORT=free_port();_SRV=start_server(ROOT,PORT)       # serve o repositório (somente leitura) para os testes que precisam de http (criptografia exige contexto seguro)
PORT2=free_port()                                   # porta livre para suítes que montam o próprio servidor
HTTP_URL=f'http://127.0.0.1:{PORT}/index.html'
INSTR_JS=open(os.path.join(LIB,'instr.js'),encoding='utf-8').read()
def golden(name):
    with open(os.path.join(FIX,'golden',name+'.json'),encoding='utf-8') as f:return json.load(f)
def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()

REPO=ROOT
def check_golden(name,value):
    """Compara com a referência guardada em tests/fixtures/golden (ou regrava se WS_UPDATE_GOLDEN=1)."""
    p=os.path.join(FIX,'golden',name+'.json')
    if os.environ.get('WS_UPDATE_GOLDEN'):
        os.makedirs(os.path.dirname(p),exist_ok=True)
        with open(p,'w',encoding='utf-8') as f:json.dump(value,f,indent=0)
        return True
    try:
        with open(p,encoding='utf-8') as f:return json.load(f)==value
    except FileNotFoundError:return False
