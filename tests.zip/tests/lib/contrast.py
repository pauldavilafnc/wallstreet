import io,json,statistics
from PIL import Image
JS_COLLECT="""()=>{const out=[];const W=innerWidth,H=innerHeight;
 const op=e=>{let o=1;for(let n=e;n&&n.nodeType===1;n=n.parentElement){const v=parseFloat(getComputedStyle(n).opacity);if(!isNaN(v))o*=v}return o};
 const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;const seen=new Set();
 while(n=tw.nextNode()){const t=n.textContent.trim();if(!t)continue;const e=n.parentElement;if(!e||seen.has(e))continue;if(e.closest('[hidden],script,style,svg,.cft'))continue;
  const cs=getComputedStyle(e);if(cs.visibility==='hidden'||cs.display==='none'||op(e)<.05)continue;
  const r=document.createRange();r.selectNodeContents(n);const b=r.getBoundingClientRect();if(b.width<4||b.height<6)continue;if(b.bottom<0||b.top>H||b.right<0||b.left>W)continue;
  let x0=Math.max(0,b.left),y0=Math.max(0,b.top),x1=Math.min(W,b.right),y1=Math.min(H,b.bottom);if(x1-x0<3||y1-y0<5)continue;
  seen.add(e);out.push({t:t.slice(0,40),c:cs.color,fs:parseFloat(cs.fontSize),fw:parseInt(cs.fontWeight)||400,o:op(e),x0,y0,x1,y1,cls:(e.className&&e.className.baseVal===undefined?e.className:'')+'|'+e.tagName})}
 return out}"""
def lum(c):
    f=lambda v:(v/255/12.92) if v/255<=0.03928 else (((v/255)+0.055)/1.055)**2.4
    return 0.2126*f(c[0])+0.7152*f(c[1])+0.0722*f(c[2])
def ratio(a,b):
    la,lb=lum(a),lum(b);hi,lo=max(la,lb),min(la,lb);return (hi+0.05)/(lo+0.05)
def parse(c):
    v=[float(x) for x in c[c.index('(')+1:c.index(')')].replace('/',' ').replace(',',' ').split()];return v[:3],(v[3] if len(v)>3 else 1)
def measure(pg,scope='content'):
    try:pg.emulate_media(reduced_motion='reduce');pg.wait_for_timeout(60)
    except Exception:pass
    """devolve lista de (razão, texto, classe) para o que está visível agora"""
    items=pg.evaluate(JS_COLLECT.replace("if(e.closest('[hidden],script,style,svg,.cft'))continue;","if(e.closest('[hidden],script,style,svg,.cft'))continue;if(%s(e.closest('nav')))continue;if(e.closest('#cfab'))continue;"%('!' if scope=='nav' else '')).replace("if(e.closest('#cfab'))continue;","if(e.closest('#cfab'))continue;"+("if(!e.closest('.sheet'))continue;" if scope=='sheet' else "")+("if(!e.closest('#lock'))continue;" if scope=='lock' else "")+("if(!e.closest('#tour .tcard'))continue;" if scope=='tour' else "")))
    pg.add_style_tag(content=("#cfab{visibility:hidden!important}"+("nav{visibility:visible!important}" if scope=='nav' else "nav{visibility:hidden!important}"))+"*,*::before,*::after{color:transparent!important;-webkit-text-fill-color:transparent!important;text-shadow:none!important;caret-color:transparent!important}input::placeholder{color:transparent!important}")
    pg.wait_for_timeout(120);bg=Image.open(io.BytesIO(pg.screenshot())).convert('RGB')
    pg.evaluate("document.querySelectorAll('style').forEach(s=>{if(s.textContent.startsWith('#cfab{visibility:hidden'))s.remove()})");pg.wait_for_timeout(80)
    sx=bg.size[0]/pg.evaluate('innerWidth');res=[]
    for it in items:
        box=(int(it['x0']*sx),int(it['y0']*sx),max(int(it['x1']*sx),int(it['x0']*sx)+2),max(int(it['y1']*sx),int(it['y0']*sx)+2));reg=bg.crop(box);px=list(reg.getdata())
        if not px:continue
        med=tuple(statistics.median(p[i] for p in px) for i in range(3));col,al=parse(it['c']);a=al*it['o']
        fg=tuple(col[i]*a+med[i]*(1-a) for i in range(3));r=ratio(fg,med)
        big=it['fs']>=24 or (it['fs']>=18.66 and it['fw']>=700);need=3.0 if big else 4.5
        res.append((round(r,2),need,it['t'],it['cls']))
    return res
