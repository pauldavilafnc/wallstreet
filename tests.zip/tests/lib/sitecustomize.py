# Testes antigos: tocam em "Agora não" e, se o app abrir em BRANCO (novo padrão), injetam os dados de exemplo antigos (só nos testes).
import os
if not os.environ.get('NOSKIP'):
    from playwright.sync_api import Page
    import os as _o;LEG=open(_o.path.join(_o.path.dirname(_o.path.dirname(_o.path.abspath(__file__))),'fixtures','legacy_seed.js'),encoding='utf-8').read()
    _goto=Page.goto;_rl=Page.reload
    def prep(self):
        try:
            self.wait_for_timeout(400)
            if self.locator('#lock [data-lk=nosec]').count():
                self.click('#lock [data-lk=nosec]');self.wait_for_selector('#nf [name=n]');self.fill('#nf [name=n]','Paul');self.click('#nf button:not([type=button])');self.wait_for_function("document.getElementById('lock').hidden",timeout=6000);self.wait_for_timeout(900)
            if self.locator('#lock [data-lk=skip]').count(): self.click('#lock [data-lk=skip]')
            if self.evaluate("typeof S!=='undefined'&&typeof SECMODE!=='undefined'&&!SECMODE&&S.items.length===0&&S.debts.length===0&&S.boxes.length===0&&S.inst.length===0&&!localStorage.getItem('wallstreet.legacyinjected')"):
                self.evaluate("(()=>{"+LEG+";const o=legacySeed();o.pref=S.pref;o.owner=S.owner;S=o;migrate(S);localStorage.setItem('wallstreet.legacyinjected','1');S.pref.ma=0;S.pref.ms='terno';save()})()")
                _rl(self);self.wait_for_timeout(700)
        except Exception: pass
    def goto(self,*a,**k):
        r=_goto(self,*a,**k);prep(self);return r
    def reload(self,*a,**k):
        r=_rl(self,*a,**k);prep(self);return r
    Page.goto=goto;Page.reload=reload

# Estilos do mascote: testes antigos usam o mascote fixo (Executivo); os testes de estilos definem SK_TEST=1.
import os as _os
if not _os.environ.get('SK_TEST'):
    from playwright.sync_api import Browser as _B
    _nc=_B.new_context;_np=_B.new_page
    _LJS="window.__WS_NOTOUR=1;if(!localStorage.getItem('wallstreet.look'))localStorage.setItem('wallstreet.look',JSON.stringify({t:'light',p:'blue',g:1,m:'terno',a:0,s:0}));"
    def _new_context(self,*a,**k):
        c=_nc(self,*a,**k);c.add_init_script(_LJS);return c
    def _new_page(self,**k):
        k.setdefault('reduced_motion','reduce');pg=_np(self,**k);pg.context.add_init_script(_LJS);return pg
    _B.new_context=_new_context;_B.new_page=_new_page
