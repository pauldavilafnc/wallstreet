#!/usr/bin/env python3
"""Gera os dados dos 10 mascotes oficiais do Wolfin (WebP otimizado em base64 + coordenadas de animação em % da imagem).
Entrada: os 10 PNG originais (transparentes) enviados pelo dono do app. Saída: /tmp/mc/out/mascotes_data.js (colado no index.html).
Coordenadas de olhos/orelhas/brilhos foram medidas nos PNG originais (pixels) e convertidas para % da imagem."""
import numpy as np,base64,io,json,sys,os
from PIL import Image
SRC=os.environ.get('MC_SRC','/mnt/user-data/uploads');OUT='/tmp/mc/out';os.makedirs(OUT,exist_ok=True)
WIDTH=544;Q=70
# id: arquivo, nome, animal, função, descrição, olhos [cx,cy,w,h,rot], orelhas [(poly,pivot)], brilhos [(x,y,tam,atraso)], reflexos [(x,y,w,h,rot,atraso)], fumaça, neon, avatar(cx,cy,lado), busto(cx,cy,lado), tempos
C=[
 dict(id='wolfin',f='243312',n='Wolfin',a='Lobo',t='CEO',d='Inteligente, sério e estratégico. O rosto do Wolfin.',main=1,
  e=[(529,307,64,24,-3),(661,286,76,28,-8)],
  r=[([(405,205),(405,40),(430,0),(470,0),(525,70),(525,205)],(470,195)),([(695,200),(700,60),(735,0),(790,10),(805,90),(800,200)],(750,190))],
  v=(600,300,640),b=(610,330,860),T=dict(hp=7.5,ha=.9,hy=.5,bk=5.2,bz='n',br=.6,ear=(6.1,8.3))),
 dict(id='leonidas',f='243311',n='Leônidas',a='Leão',t='Rei',d='Imponente e generoso com o tesouro. Liderança e riqueza.',
  e=[(606,291,55,22,3),(726,293,38,22,8)],
  g=[(593,120,70,0),(698,115,46,1.7),(646,163,40,3.1),(472,173,40,4.4),(214,339,60,2.4)],
  v=(640,350,780),b=(630,380,980),T=dict(hp=9.5,ha=.55,hy=.35,bk=7.4,bz='s',br=.5)),
 dict(id='vito',f='243313',n='Don Vito',a='Raposa',t='Magnata',d='Esperto, elegante e ambicioso. Sempre um passo à frente.',
  e=[(491,391,60,33,12),(647,342,100,46,-20)],
  r=[([(700,0),(700,120),(730,230),(830,230),(835,60),(790,0)],(760,225))],
  g=[(545,760,56,0),(690,735,48,2.2),(906,1062,52,4.1),(985,905,44,1.1)],
  v=(640,320,700),b=(630,380,900),T=dict(hp=6.5,ha=1.1,hy=.4,bk=8.0,bz='h',br=.5,ear=(7.7,))),
 dict(id='oraculo',f='243307',n='Oráculo',a='Coruja',t='Analista',d='Observa, analisa e prevê. Sabedoria nos números.',
  e=[(498,301,62,34,-4),(662,270,80,42,-14)],
  sw=[(635,288,150,86,-10,0),(480,318,120,70,6,.5)],g=[(862,1115,44,2.5)],
  v=(610,300,640),b=(620,340,880),T=dict(hp=8,ha=1.3,hy=.3,bk=4.6,bz='n',br=.45,sty='precise')),
 dict(id='brutus',f='243306',n='Brutus',a='Touro',t='Investidor',d='Força e coragem para investir. Determinado e confiante.',
  e=[(502,320,45,29,5),(646,295,61,29,-8)],
  r=[([(318,262),(318,350),(380,362),(458,350),(458,262),(400,252)],(445,325)),([(748,240),(748,350),(840,350),(935,330),(935,250),(850,235)],(765,318))],
  g=[(520,640,60,0),(432,1035,50,2.8)],sm=[(505,418),(568,408)],
  v=(625,290,700),b=(625,340,900),T=dict(hp=6.8,ha=.7,hy=.45,bk=6,bz='n',br=1.4,ear=(7.1,9.4))),
 dict(id='mako',f='243308',n='Mako',a='Tubarão',t='Negociador',d='Frio e calculista. Fecha bons negócios sem pestanejar.',
  e=[(538,170,72,47,-10)],
  g=[(286,880,46,0),(758,1140,46,3.3)],
  v=(590,300,680),b=(600,380,900),T=dict(hp=9.5,ha=.6,hy=.3,bk=8.2,bz='s',br=.5)),
 dict(id='bento',f='243314',n='Bento',a='Castor',t='Planejador',d='Organizado e metódico. Constrói patrimônio com calma.',
  e=[(436,225,52,31,10),(601,180,86,45,-20)],
  sw=[(578,168,150,84,-14,0),(434,223,92,60,10,.5)],g=[(1075,1155,46,2.2)],
  v=(620,285,640),b=(615,350,900),T=dict(hp=7,ha=.8,hy=.4,bk=4.9,bz='n',br=.5)),
 dict(id='penny',f='243309',n='Penny',a='Esquilo',t='Poupador',d='Econômico e prevenido. Sabe guardar cada moeda.',
  e=[(408,349,78,49,18),(598,303,112,56,-16)],
  r=[([(350,215),(352,60),(400,30),(462,90),(462,215)],(420,205)),([(698,235),(700,70),(740,55),(795,120),(795,235)],(745,225))],
  g=[(200,440,84,0),(214,432,40,1.9)],
  v=(620,330,680),b=(620,380,940),T=dict(hp=5.6,ha=1.2,hy=.55,bk=4.3,bz='n',br=.6,ear=(5.7,7.9))),
 dict(id='nyx',f='243310',n='Nyx',a='Pantera',t='Hacker',d='Misteriosa e precisa. Domina o mundo digital.',
  e=[(469,286,45,24,15),(615,245,84,50,-20)],
  r=[([(383,232),(385,120),(420,100),(472,160),(476,232)],(440,222)),([(628,125),(634,5),(700,0),(770,40),(772,125)],(690,115))],
  ng=[(210,610,230),(469,286,70),(615,245,90),(1105,745,110),(830,860,100)],
  v=(630,300,640),b=(630,360,900),T=dict(hp=7.2,ha=.8,hy=.4,bk=5.5,bz='n',br=.5,ear=(8.0,6.6))),
 dict(id='elliot',f='243305',n='Elliot',a='Guaxinim',t='Detetive',d='Curioso e investigativo. Descobre para onde vai o dinheiro.',
  e=[(508,374,59,31,8),(665,339,93,52,-12)],
  r=[([(392,238),(392,60),(440,35),(484,120),(486,238)],(440,235)),([(698,150),(702,5),(760,0),(830,40),(832,150)],(765,150))],
  sw=[(330,520,220,250,-20,0)],
  v=(590,310,680),b=(600,370,940),T=dict(hp=6.2,ha=1.2,hy=.4,bk=5,bz='n',br=.5,ear=(6.3,8.8),sty='scan')),
]
def ringcolor(im,cx,cy,w,h):
    a=np.array(im).astype(int);H,W=a.shape[:2];Y,X=np.ogrid[:H,:W]
    rx,ry=w/2,h/2;d=((X-cx)/rx)**2+((Y-cy)/ry)**2
    m=(d>1.5)&(d<4.2)&(a[...,3]>230);px=a[m][:,:3]
    if len(px)<20:return '#808080'
    lum=px@np.array([.299,.587,.114]);keep=px[lum>np.percentile(lum,18)]
    c=np.median(keep,axis=0).astype(int);return '#%02x%02x%02x'%tuple(c)
data=[];tot=0
for c in C:
    im=Image.open(os.path.join(SRC,c['f']+'.png')).convert('RGBA');Wn,Hn=im.size
    sm=im.resize((WIDTH,round(Hn*WIDTH/Wn)),Image.LANCZOS);buf=io.BytesIO();sm.save(buf,"WEBP",quality=Q,method=6,alpha_quality=60);b=buf.getvalue();tot+=len(b)
    pct=lambda x,y:(round(x/Wn*100,2),round(y/Hn*100,2))
    ex=[]
    for (cx,cy,w,h,rot) in c['e']:
        col=ringcolor(im,cx,cy,w,h);x,y=pct(cx,cy);ex.append([x,y,round(w*1.14/Wn*100,2),round(h*1.5/Hn*100,2),rot,col])
    o=dict(id=c['id'],n=c['n'],a=c['a'],t=c['t'],d=c['d'],W=sm.size[0],H=sm.size[1],v=[round(c['v'][0]/Wn*100,2),round(c['v'][1]/Hn*100,2),round(c['v'][2]/Wn*100,2)],b=[round(c['b'][0]/Wn*100,2),round(c['b'][1]/Hn*100,2),round(c['b'][2]/Wn*100,2)],e=ex)
    if c.get('main'):o['main']=1
    if c.get('r'):o['r']=[[' '.join('%s%% %s%%'%pct(*p) for p in poly).replace(' ',' ').replace('% ','%,').replace(',',' ',0),'%s%% %s%%'%pct(*piv)] for poly,piv in c['r']]
    if c.get('r'):
        o['r']=[]
        for poly,piv in c['r']:
            o['r'].append([','.join('%s%% %s%%'%pct(*p) for p in poly),'%s%% %s%%'%pct(*piv)])
    if c.get('g'):o['g']=[[*pct(x,y),round(s/Wn*100,2),d] for (x,y,s,d) in c['g']]
    if c.get('sw'):o['sw']=[[*pct(x,y),round(w/Wn*100,2),round(h/Hn*100,2),rot,d] for (x,y,w,h,rot,d) in c['sw']]
    if c.get('sm'):o['sm']=[list(pct(x,y)) for (x,y) in c['sm']]
    if c.get('ng'):o['ng']=[[*pct(x,y),round(r/Wn*100,2)] for (x,y,r) in c['ng']]
    o['T']=c['T'];o['_b64']=base64.b64encode(b).decode();o['_kb']=len(b)//1024;data.append(o)
print('WebP total: %d KB (base64 ≈ %d KB)'%(tot//1024,tot*4//3//1024),[(d['id'],d['_kb']) for d in data])
meta=[{k:v for k,v in d.items() if k not in('_b64','_kb')} for d in data]
js='const MCB='+json.dumps({d['id']:d['_b64'] for d in data},separators=(',',':'))+';\nconst MC='+json.dumps(meta,ensure_ascii=False,separators=(',',':'))+';\n'
open(OUT+'/mascotes_data.js','w',encoding='utf-8').write(js);json.dump(meta,open(OUT+'/mascotes_meta.json','w',encoding='utf-8'),ensure_ascii=False)
print('js:',len(js)//1024,'KB')
