(()=>{const o=seed();o.owner='Teste';o.opening={c:50000,d:'2026-01-01'};o.limits={'Casa':120000,'Lazer':20000};
 const D=(id,t,d,c,day,cat,done)=>({id,t,d,c,day,fixed:true,from:'2026-01',done:done||{},cat,pay:'Pix'});
 o.items=[D('i1','inc','Salário',320000,5,'Salário',{'2026-09':320000,'2026-10':320000,'2026-11':320000}),D('i2','inc','Freela',60000,20,'Renda extra',{'2026-10':60000}),
  D('e1','exp','Aluguel',110000,10,'Casa',{'2026-09':110000,'2026-10':110000,'2026-11':110000}),D('e2','exp','Internet',12000,12,'Casa',{'2026-10':12000}),D('e3','exp','Academia',9000,8,'Saúde',{'2026-10':9000,'2026-11':9000}),
  {id:'v1',t:'exp',d:'Mercado',c:45000,day:14,fixed:false,ym:'2026-11',done:{'2026-11':45000},cat:'Alimentação',pay:'Pix'},{id:'v2',t:'exp',d:'Cinema',c:8000,day:15,fixed:false,ym:'2026-11',done:{'2026-11':8000},cat:'Lazer',pay:'Pix'},
  {id:'v3',t:'exp',d:'Mercado',c:52000,day:14,fixed:false,ym:'2026-10',done:{'2026-10':52000},cat:'Alimentação',pay:'Pix'},{id:'v4',t:'exp',d:'Show',c:30000,day:20,fixed:false,ym:'2026-11',done:{},cat:'Lazer',pay:'Pix'}];
 o.inst=[{id:'n1',n:'Celular',c:null,np:null,day:5,paid:false}];o.parc=[{id:'p1',iid:'n1',ym:'2026-10',c:20000,paid:1,paidOn:'2026-10-05'},{id:'p2',iid:'n1',ym:'2026-11',c:20000,paid:0,due:'2026-11-05'},{id:'p3',iid:'n1',ym:'2026-12',c:20000,paid:0}];
 o.debts=[{id:'d1',n:'Banco',o:300000,due:'2026-12-20',pays:[{id:'y1',c:50000,d:'2026-09-05'},{id:'y2',c:50000,d:'2026-10-05'}]},{id:'d2',n:'Amigo',o:80000,due:'2026-10-30',pays:[]}];
 o.boxes=[{id:'b1',n:'Viagem',g:500000,m:20000,dl:'2027-07',moves:[{id:'m1',d:'2026-10-01',c:20000},{id:'m2',d:'2026-11-03',c:20000}]}];
 o.cards=[{id:'k1',n:'Nubank',lim:500000,cl:10,dd:25,buys:[{id:'u1',d:'Notebook',c:150000,dt:'2026-10-20',np:3,cat:'Eletrônicos'},{id:'u2',d:'Jantar',c:12000,dt:'2026-11-02',np:1,cat:'Lazer'}],pays:[{id:'q1',ym:'2026-11',c:50000,d:'2026-11-12'}]}];
 o.flags={tour:1};return migrate(o)})()
