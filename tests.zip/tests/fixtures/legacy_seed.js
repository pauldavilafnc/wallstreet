function legacySeed(){const cm=ymOf(new Date());
 const it=(t,d,c,day,cat)=>({id:uid(),t,d,c,day,cat,fixed:true,from:cm,done:{}});
 const cel=uid(),hp=(ym,c,paid,h)=>({id:uid(),iid:cel,ym,c,paid,h});
 return{v:2,owner:"Paul",opening:null,limits:{},ntf:{read:{}},pref:{theme:'light',pal:'blue',av:{e:0,m:0,bg:0,an:1}},
  items:[it('inc','Comissão',30000,10,'Comissão'),it('inc','Quinzena',81100,15,'Salário'),it('inc','Quinzena',81100,30,'Salário'),
   it('exp','Plano odontológico',2990,5,'Saúde'),it('exp','Aparelho dentário',7000,5,'Saúde'),it('exp','Academia',9500,20,'Lazer'),
   it('exp','Internet Lisieux',5990,17,'Casa'),it('exp','Internet Sobral',2350,5,'Casa')],
  inst:[{id:uid(),n:'Roupas Renadia',c:54800,np:null,day:null,paid:false},{id:uid(),n:'Roupas Charles',c:54500,np:null,day:null,paid:false},{id:cel,n:'Celular',c:null,np:null,day:5,paid:true}],
  parc:[hp('2026-06',20000,1,1),hp('2026-06',20000,1,1),hp('2026-07',16000,1,1),
   hp('2026-08',13000,1),hp('2026-09',13000,1),hp('2026-10',13000,1),hp('2026-11',13000,1),hp('2026-12',13000,0),
   hp('2027-01',13000,0),hp('2027-02',13000,0),hp('2027-03',13000,0),hp('2027-04',13000,0)],
  debts:[['NEXT',59788],['Mercado Pago',4900],['Vivo',3785],['Fácil',7280],['Blipay',7298],['DAS MEI',43822]].map(([n,o])=>({id:uid(),n,o,due:'',pays:[]})),
  boxes:[{id:uid(),n:'Emergência',g:null,m:10000,dl:'',moves:[]},{id:uid(),n:'Habilitação',g:200000,m:40000,dl:'2027-07',moves:[]},
   {id:uid(),n:'Moto usada',g:400000,m:80000,dl:'',moves:[]},{id:uid(),n:'Óculos de grau',g:60000,m:null,dl:'',moves:[]}]}}
