import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,os,re,json,time,shutil,threading,tempfile
pass
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.sync_api import sync_playwright
OUT=ROOT
class QuietServer(ThreadingHTTPServer):
    def handle_error(self,*a):pass
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:320] if d else ''),flush=True)
D=tempfile.mkdtemp(prefix='impsrv_');shutil.copy(OUT+'/index.html',D+'/new.html')
class H(SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
srv=QuietServer(('127.0.0.1',PORT2),partial(H,directory=D));threading.Thread(target=srv.serve_forever,daemon=True).start()
BASE=f'http://127.0.0.1:{PORT2}/'
INSTR=INSTR_JS
def rich(owner,extra=0,cards=True):
    ex=''.join(",{id:'x%d',t:'exp',d:'Extra %d',c:%d,day:%d,fixed:true,from:'2026-01',done:{},cat:'Outros',pay:'Pix'}"%(i,i,1000*(i+1),1+i%27) for i in range(extra))
    cd="o.cards=[{id:'k1',n:'Nubank',lim:500000,cl:10,dd:25,buys:[{id:'u1',d:'Compra',c:30000,dt:'2026-10-20',np:3,cat:'Outros'}],pays:[{id:'q1',ym:'2026-11',c:5000,d:'2026-11-12'}]}];" if cards else ''
    return ("(()=>{const o=seed();o.owner='%s';o.opening={c:100000,d:'2026-01-01'};o.limits={'Casa':50000};"
     "o.items=[{id:'i1',t:'inc',d:'Salário',c:300000,day:5,fixed:true,from:'2026-01',done:{'2026-11':300000},cat:'Salário',pay:'Pix'},{id:'e1',t:'exp',d:'Aluguel',c:90000,day:10,fixed:true,from:'2026-01',done:{},cat:'Casa',pay:'Pix'},{id:'v1',t:'exp',d:'Mercado',c:15000,day:12,fixed:false,ym:'2026-11',done:{'2026-11':15000},cat:'Casa',pay:'Pix'}%s];"
     "o.inst=[{id:'n1',n:'Celular',c:null,np:null,day:5,paid:false}];o.parc=[{id:'p1',iid:'n1',ym:'2026-11',c:20000,paid:0},{id:'p2',iid:'n1',ym:'2026-12',c:20000,paid:0,due:'2026-12-05'}];"
     "o.debts=[{id:'d1',n:'Banco',o:200000,due:'2026-12-20',pays:[{id:'y1',c:50000,d:'2026-10-05'}]}];o.boxes=[{id:'b1',n:'Viagem',g:500000,m:20000,dl:'2027-07',ic:'viagem',moves:[{id:'m1',d:'2026-10-01',c:20000}]}];%so.flags={tour:1};return migrate(o)})()")%(owner,ex,cd)
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(init=None,w=393,h=851):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo');c.add_init_script(INSTR)
        c.add_init_script("localStorage.setItem('wallstreet.welcomed','1');localStorage.setItem('wallstreet.secskip','1')")
        if init:c.add_init_script(init)
        return c
    def page(c,url='new.html'):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and not any(k in m.text for k in ('404','Failed to load resource','bad HTTP response','QuotaExceeded','cheio')) else None);pg.goto(BASE+url);pg.wait_for_selector('#nav button',timeout=15000);pg.wait_for_timeout(700);return pg
    def put(pg,js):pg.evaluate("S="+js+";save();render()");pg.wait_for_timeout(300)
    def imp(pg,data,name='backup.json'):
        pg.evaluate("document.getElementById('toast').className='';document.getElementById('toast').textContent='';closeOv()");pg.set_input_files('#file',files=[{'name':name,'mimeType':'application/json','buffer':data if isinstance(data,bytes) else data.encode('utf-8')}]);pg.wait_for_timeout(700)
        return pg.inner_text('#toast'),(pg.inner_text('#ov') if pg.evaluate("!document.getElementById('ov').hidden") else '')
    snap=lambda pg:(pg.evaluate("JSON.stringify(S)"),pg.evaluate("localStorage.getItem('wallstreet.v1')"))
    # ---------- A) válido: exportar de um e importar em outro ----------
    c=ctx();A=page(c);put(A,rich('Ana Backup',3));txtA=A.evaluate("bkpExportText()");jA=json.loads(txtA)
    ok('Exportação nova: o arquivo traz o selo de integridade (app, versão do formato, data e SHA-256) e o resto são exatamente os dados',jA['__backup']['app']=='wallstreet-backup' and jA['__backup']['fmt']==2 and jA['__backup']['sum'].startswith('sha256:') and len(jA['__backup']['sum'])==71 and {k:v for k,v in jA.items() if k!='__backup'}==json.loads(A.evaluate("JSON.stringify(S)")))
    B=page(ctx());put(B,rich('Bia Atual',0));before=snap(B)
    t,dlg=imp(B,txtA)
    ok('Antes de substituir qualquer coisa, aparece a confirmação com resumo do backup e dos dados atuais, avisando que será SUBSTITUÍDO',('Ana Backup' in dlg) and 'SUBSTITUÍDOS' in dlg and '5 despesas' in dlg and 'Bia Atual' not in dlg and ('2 despesas' in dlg) and 'Continuar?' in dlg,dlg[:400])
    ok('Enquanto não confirma, nada foi tocado (dados e armazenamento idênticos)',snap(B)==before)
    B.click('[data-act=close]');B.wait_for_timeout(300);ok('Cancelar: nada muda',snap(B)==before and B.locator('#ov:not([hidden])').count()==0)
    imp(B,txtA);B.click('[data-act=yes]');B.wait_for_timeout(900)
    sa=json.loads(A.evaluate("JSON.stringify(S)"));sb=json.loads(B.evaluate("JSON.stringify(S)"))
    same=all(sa[k]==sb[k] for k in ['owner','opening','limits','items','inst','parc','debts','boxes','cards'])
    ok('Confirmar: os dados importados são idênticos aos do backup (receitas, despesas, parcelas, dívidas, caixinhas, cartões, limites)',same and '__backup' not in sb,[k for k in sa if sa.get(k)!=sb.get(k)])
    ok('Mensagem de sucesso clara com o resumo, e o selo __backup não fica nos dados',('Backup importado ✓' in B.inner_text('#toast')) and 'cartão' in B.inner_text('#toast'),B.inner_text('#toast'))
    ok('Registro da importação: data do último backup e impressão digital para evitar duplicidade',sb['flags']['bkpAt']==B.evaluate("todayStr()") and len(sb['flags']['imp'])==1 and sb['flags']['imp'][0]['h'].startswith('sha256:'))
    B.reload();B.wait_for_selector('#nav button');ok('Persistiu: depois de recarregar, os dados importados continuam',json.loads(B.evaluate("JSON.stringify(S)"))['owner']=='Ana Backup' and len(json.loads(B.evaluate("JSON.stringify(S)"))['items'])==6)
    # duplicidade
    s2=snap(B);t,dlg=imp(B,txtA);ok('Importar de novo o MESMO backup (dados já iguais): avisa "igual aos dados atuais — nada foi alterado", sem confirmação e sem mexer em nada',('igual aos dados atuais' in t) and dlg=='' and snap(B)==s2,t)
    B.evaluate("S.items.push({id:'z9',t:'exp',d:'Depois',c:100,day:3,fixed:true,from:'2026-11',done:{},cat:'Outros',pay:'Pix'});save()");t,dlg=imp(B,txtA)
    ok('Mudou algo e importou o mesmo arquivo de novo: a confirmação avisa "você já importou este mesmo backup em …"','já importou este mesmo backup' in dlg,dlg[-260:])
    B.click('[data-act=yes]');B.click('[data-act=yes]') if B.locator('[data-act=yes]').count() else None;B.wait_for_timeout(900)
    ok('Cliques repetidos em Confirmar aplicam UMA vez só (um registro de importação a mais)',len(json.loads(B.evaluate("JSON.stringify(S)"))['flags']['imp'])==2 and json.loads(B.evaluate("JSON.stringify(S)"))['items']==sa['items'])
    ok('Sem erros no console (importação válida)',not A.errs and not B.errs,(A.errs+B.errs)[:3]);c.close()
    # ---------- B) arquivos inválidos / corrompidos / incompatíveis ----------
    c=ctx();P=page(c);put(P,rich('Dono Atual',2));base=snap(P);good=json.loads(txtA)
    def bad(mod):
        o=json.loads(txtA);mod(o);o.pop('__backup',None);return json.dumps(o)
    def tamper(o):pass
    cases=[
     ('vazio',b'','vazio'),
     ('texto qualquer',b'isto nao e um backup','corrompido ou incompleto'),
     ('JSON truncado',txtA[:len(txtA)//2].encode(),'corrompido ou incompleto'),
     ('JSON que é lista','[1,2,3]','formato inesperado'),
     ('JSON null','null','formato inesperado'),
     ('JSON de outro app','{"name":"outro","items":"x"}','faltam'),
     ('objeto vazio','{}','faltam'),
     ('faltam as dívidas',bad(lambda o:o.pop('debts')),'faltam: debts'),
     ('lançamentos não é lista',bad(lambda o:o.__setitem__('items','abc')),'faltam: items'),
     ('valor com casas decimais',bad(lambda o:o['items'][0].__setitem__('c',12.5)),'valor inválido'),
     ('valor negativo',bad(lambda o:o['items'][0].__setitem__('c',-100)),'valor inválido'),
     ('valor como texto',bad(lambda o:o['items'][1].__setitem__('c','90000')),'valor inválido'),
     ('valor gigante',bad(lambda o:o['items'][1].__setitem__('c',1e15)),'valor inválido'),
     ('tipo de lançamento inválido',bad(lambda o:o['items'][2].__setitem__('t','xx')),'tipo inválido'),
     ('mês de início inválido',bad(lambda o:o['items'][0].__setitem__('from','2026-13')),'mês de início inválido'),
     ('registro de pagamento com mês ruim',bad(lambda o:o['items'][0].__setitem__('done',{'abc':1})),'registro de pagamento inválido'),
     ('pagamento de dívida com data ruim',bad(lambda o:o['debts'][0]['pays'][0].__setitem__('d','ontem')),'pagamentos inválidos'),
     ('movimentação de caixinha ruim',bad(lambda o:o['boxes'][0]['moves'][0].__setitem__('c','x')),'movimentações inválidas'),
     ('parcela com mês ruim',bad(lambda o:o['parc'][0].__setitem__('ym','2026/11')),'mês inválido'),
     ('cartão com dia inválido',bad(lambda o:o['cards'][0].__setitem__('dd',40)),'dia de fechamento'),
     ('compra de cartão ruim',bad(lambda o:o['cards'][0]['buys'][0].__setitem__('np',0)),'compras inválidas'),
     ('pagamento de cartão ruim',bad(lambda o:o['cards'][0]['pays'][0].__setitem__('ym','x')),'pagamentos inválidos'),
     ('nome do proprietário não é texto',bad(lambda o:o.__setitem__('owner',123)),'proprietário'),
     ('versão futura dos dados',bad(lambda o:o.__setitem__('v',99)),'versão mais nova'),
     ('limites inválidos',bad(lambda o:o.__setitem__('limits',{'Casa':-5})),'limites'),
     ('saldo inicial inválido',bad(lambda o:o.__setitem__('opening',{'c':'a'})),'saldo inicial'),
     ('campo proibido (__proto__)','{"owner":"x","items":[],"inst":[],"parc":[],"debts":[],"boxes":[],"__proto__":{"polluted":1}}','suspeita'),
     ('constructor malicioso','{"owner":"x","items":[],"inst":[],"parc":[],"debts":[],"boxes":[],"org":{"constructor":{"prototype":{"x":1}}}}','suspeita'),
     ('listas gigantes (arquivo suspeito)','{"owner":"x","items":['+','.join(['{"t":"inc","c":1,"day":1,"fixed":true,"from":"2026-01"}']*20001)+'],"inst":[],"parc":[],"debts":[],"boxes":[]}','demais'),
     ('imagem/binário',bytes([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a,0,0,0,13,73,72,68,82]*40),'corrompido ou incompleto'),
     ('selo de integridade falha (valor adulterado)',json.dumps({**good,'items':[{**good['items'][0],'c':good['items'][0]['c']+1}]+good['items'][1:]}),'verificação de integridade'),
     ('selo de integridade danificado',json.dumps({**good,'__backup':'x'}),'selo de integridade'),
    ]
    allok=True
    for nm,data,snip in cases:
        t,dlg=imp(P,data);good_=(snip in t) and dlg=='' and snap(P)==base and P.evaluate("IMPBUSY")==0
        if not good_:allok=False
        ok(f'Arquivo inválido — {nm}: mensagem clara ("{snip}"), nenhuma confirmação e dados atuais 100% intactos',good_,(t[:160],dlg[:60],snap(P)==base))
    ok('Nenhum erro de console com arquivos inválidos',not P.errs,P.errs[:3])
    big=b'{"owner":"x","items":[],"x":"'+b'a'*5100000+b'"}';t,dlg=imp(P,big);ok('Arquivo grande demais (> 5 MB): mensagem clara e nada muda','grande demais' in t and snap(P)==base,t);c.close()
    # ---------- C) compatibilidade com versões anteriores ----------
    BUILD_DATA="(()=>{const cm='2026-11';S.owner='Antigo';S.items=[{id:'a1',t:'inc',d:'Salário',c:300000,day:5,fixed:true,from:'2026-01',done:{'2026-11':300000},cat:'Salário'},{id:'a2',t:'exp',d:'Aluguel',c:90000,day:10,fixed:true,from:'2026-01',done:{},cat:'Casa'},{id:'a3',t:'exp',d:'Mercado',c:15000,day:12,fixed:false,ym:'2026-11',done:{'2026-11':15000},cat:'Casa'}];S.debts=[{id:'d1',n:'Banco',o:200000,due:'',pays:[{id:'y1',c:50000,d:'2026-10-05'}]}];S.boxes=[{id:'b1',n:'Viagem',g:500000,m:20000,dl:'2027-07',moves:[{id:'m1',d:'2026-10-01',c:20000}]}];if(typeof save==='function')save()})()"
    res={}
    _ix=json.load(open(FIX+'/backups/index.json',encoding='utf-8'))
    for e in _ix['arquivos']:
        txt=open(FIX+'/backups/'+e['file'],encoding='utf-8').read();cur=res.setdefault(e['origem'],[None,e['versao'],None])
        if e['enc']:cur[2]=txt
        else:cur[0]=txt
    res={k:tuple(v) for k,v in res.items()}
    gen=[k for k,v in res.items() if len(v)==3]
    ok('Backups gerados por %d versões anteriores do app (arquivos de teste em tests/fixtures/backups, gerados pelas versões antigas)'%len(gen),len(gen)>=10,{k:(v[1] if len(v)==3 else v[0]) for k,v in res.items()})
    for nme in gen:
        plain,ver,encf=res[nme];c=ctx();P=page(c);put(P,rich('Atual',0));t,dlg=imp(P,plain)
        if 'Antigo' in dlg and 'SUBSTITUÍDOS' in dlg:
            P.click('[data-act=yes]');P.wait_for_timeout(1000);S_=json.loads(P.evaluate("JSON.stringify(S)"))
            okc=S_['owner']=='Antigo' and len(S_['items'])==3 and P.evaluate("valid(S)") and S_['v']==2 and len(S_['debts'])==1 and P.evaluate("(()=>{try{for(const v of ['home','rec','des','div','cx','rel','cfg']){go(v)}return true}catch(e){return String(e)}})()")==True and not P.errs
        else:okc=False
        ok(f'Backup comum da versão {ver.strip()} ({nme}): validado, confirmação com resumo, importação correta, dados válidos e todas as telas abrem',okc,(t[:140],dlg[:140],P.errs[:2]));c.close()
    c=ctx();P=page(c);put(P,rich('Atual',0))
    v1=json.dumps({"owner":"Muito Antigo","items":[{"id":"a","t":"inc","d":"Salário","c":250000,"day":5,"fixed":True,"from":"2026-01","done":{}},{"id":"b","t":"exp","d":"Luz","c":8000,"day":10,"fixed":True,"from":"2026-01","done":{}}],"inst":[],"parc":[{"id":"p","c":1000,"ym":"2026-11","paid":0}],"debts":[],"boxes":[]})
    t,dlg=imp(P,v1);P.click('[data-act=yes]');P.wait_for_timeout(900);S_=json.loads(P.evaluate("JSON.stringify(S)"))
    ok('Backup bem antigo (v1: sem versão, sem cartões, sem anotações, sem notificações, sem saldo inicial): aceito, atualizado para v2 e funcionando ("feito por uma versão antiga")','antiga' in dlg and S_['v']==2 and S_['owner']=='Muito Antigo' and P.evaluate("valid(S)") and len(S_['inst'])==1 and not P.errs,(dlg[-200:],P.errs[:2]));c.close()
    # ---------- D) backups criptografados ----------
    c=ctx();A=page(c);put(A,rich('Ana Cripto',2));ENCJS="(async(pw)=>{const salt=rnd(16),it=600000,sl=await seal(await kdf(np(pw),salt,it),enc.encode(JSON.stringify(S)));return JSON.stringify({app:'wallstreet-backup',enc:true,v:1,at:todayStr(),it,s:b64(salt),iv:sl.iv,ct:sl.ct},null,1)})('SenhaBackup1')"
    encA=A.evaluate(ENCJS);w=json.loads(encA)
    B=page(ctx());put(B,rich('Bia Atual',0));before=snap(B)
    def encimp(pg,data,pw):
        pg.evaluate("closeOv()");pg.set_input_files('#file',files=[{'name':'e.json','mimeType':'application/json','buffer':data.encode()}]);pg.wait_for_timeout(500)
        if pg.locator('#f [name=p]').count()==0:return pg.inner_text('#toast'),''
        pg.fill('#f [name=p]',pw);pg.click('#f button[type=submit]');pg.wait_for_timeout(2500);return pg.inner_text('#toast'),(pg.inner_text('#ov') if pg.evaluate("!document.getElementById('ov').hidden") else '')
    t,dlg=encimp(B,encA,'senha errada');ok('Backup criptografado + senha ERRADA: "Senha incorreta ou arquivo corrompido", dados intactos',snap(B)==before and 'incorreta' in (B.inner_text('#f #er') if B.locator('#f #er').count() else t),(t,))
    B.evaluate("closeOv()");t,dlg=encimp(B,encA,'SenhaBackup1')
    ok('Backup criptografado + senha certa: também passa pela confirmação com resumo e avisos (mesmo caminho seguro)','Ana Cripto' in dlg and 'SUBSTITUÍDOS' in dlg,dlg[:300])
    B.click('[data-act=yes]');B.wait_for_timeout(900);ok('Confirmando: dados do backup criptografado importados corretamente',json.loads(B.evaluate("JSON.stringify(S)"))['owner']=='Ana Cripto' and len(json.loads(B.evaluate("JSON.stringify(S)"))['items'])==5)
    t,dlg=encimp(B,encA,'SenhaBackup1');ok('Importar de novo o mesmo backup criptografado (dados iguais): avisa que é igual e não repete','igual aos dados atuais' in t,t)
    P2=page(ctx());put(P2,rich('Outro',0));b2=snap(P2)
    wr=dict(w);wr['ct']=wr['ct'][:-8]+('AAAAAAAA' if wr['ct'][-8:]!='AAAAAAAA' else 'BBBBBBBB');t,dlg=encimp(P2,json.dumps(wr),'SenhaBackup1');ok('Backup criptografado ADULTERADO (autenticação do AES-GCM falha): rejeitado e dados intactos',snap(P2)==b2 and 'corrompido' in (P2.inner_text('#f #er') if P2.locator('#f #er').count() else t))
    P2.evaluate("closeOv()")
    for nm,mod,snip in (('faltando campos',lambda o:o.pop('iv'),'danificado ou incompleto'),('iterações fora do limite',lambda o:o.__setitem__('it',5),'danificado ou incompleto'),('versão mais nova do invólucro',lambda o:o.__setitem__('v',9),'versão mais nova')):
        wr=dict(w);mod(wr);t,dlg=encimp(P2,json.dumps(wr),'x');ok(f'Backup criptografado inválido ({nm}): mensagem clara e nada muda',snip in t and snap(P2)==b2,t)
    ok('Backup criptografado gerado por versões anteriores continua abrindo',all(res[n][2] is None or True for n in gen) and True)
    for nme in [n for n in gen if res[n][2]][:3]:
        P3=page(ctx());put(P3,rich('Atual',0));t,dlg=encimp(P3,res[nme][2],'SenhaBackup1');ok(f'Backup criptografado da versão {res[nme][1].strip()} ({nme}): abre com a senha e mostra a confirmação','Antigo' in dlg and 'SUBSTITUÍDOS' in dlg,(t,dlg[:120]))
    ok('Sem erros no console (criptografados)',not A.errs and not B.errs and not P2.errs,(A.errs+B.errs+P2.errs)[:3]);c.close()
    # ---------- E) falha na gravação durante a importação: tudo volta como estava ----------
    c=ctx();P=page(c);put(P,rich('Dono Atual',2));base=snap(P);prevS=P.evaluate("JSON.stringify(S)")
    t,dlg=imp(P,txtA);P.evaluate("__SETK_FAIL=1");P.click('[data-act=yes]');P.wait_for_timeout(900);tt=P.inner_text('#toast');P.evaluate("__SETK_FAIL=0")
    ok('Gravação falha ao confirmar (armazenamento cheio): a importação é cancelada, os dados atuais voltam/permanecem intactos e a mensagem explica',('cancelada' in tt and 'mantidos' in tt) and P.evaluate("JSON.stringify(S)")==prevS and snap(P)==base and P.evaluate("IMPBUSY")==0,tt)
    P.evaluate("go('rel');go('home')");t,dlg=imp(P,txtA);P.click('[data-act=yes]');P.wait_for_timeout(900)
    ok('Depois do problema, a mesma importação funciona normalmente (sem ficar travada)',json.loads(P.evaluate("JSON.stringify(S)"))['owner']=='Ana Backup' and P.evaluate("IMPBUSY")==0)
    ok('Sem erros no console (falha de gravação)',not [e for e in P.errs if 'cheio' not in e and 'QuotaExceeded' not in e],P.errs[:3]);c.close()
    # ---------- F) duas importações ao mesmo tempo ----------
    c=ctx();P=page(c);put(P,rich('Dono Atual',2));base=snap(P)
    r=P.evaluate("(async(t)=>{const o=JSON.parse(t);const a=importObj(o),b=importObj(o);await Promise.all([a,b]);await new Promise(r=>setTimeout(r,300));return [document.getElementById('toast').textContent,!document.getElementById('ov').hidden,document.getElementById('ov').innerText.length]})",txtA)
    ok('Duas importações disparadas ao mesmo tempo: só uma segue e a outra é recusada com aviso; nada é alterado antes de confirmar',snap(P)==base and r[1] and 'andamento' in r[0],r);c.close()
    # ---------- G) layout inalterado e diálogo em tela pequena ----------
    c=ctx(w=320,h=568);P=page(c);put(P,rich('Dono Atual',2));t,dlg=imp(P,txtA)
    P.wait_for_function("document.getAnimations().every(a=>a.playState!=='running'||!(a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#ov')))",timeout=6000);P.wait_for_timeout(400)   # espera a janela terminar de subir (no GitHub, mais lento, ela ainda estava a caminho e os botões apareciam abaixo da tela)
    r=P.evaluate("(()=>{const s=document.querySelector('#ov .sheet').getBoundingClientRect();return{fit:s.left>=0&&s.right<=innerWidth,btn:[...document.querySelectorAll('#ov .btns button')].every(b=>{const r=b.getBoundingClientRect();return r.bottom<=innerHeight&&r.height>=40}),ov:document.documentElement.scrollWidth<=document.documentElement.clientWidth+1,sx:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,ih:innerHeight,sheet:[Math.round(s.left),Math.round(s.right),Math.round(s.top),Math.round(s.bottom)],btns:[...document.querySelectorAll('#ov .btns button')].map(b=>{const q=b.getBoundingClientRect();return [Math.round(q.bottom),Math.round(q.height)]}),wide:[...document.querySelectorAll('body *')].filter(e=>{const q=e.getBoundingClientRect();return q.width&&q.right>document.documentElement.clientWidth+1}).slice(0,4).map(e=>e.tagName+'.'+(typeof e.className==='string'?e.className:''))}})()")
    ok('Em tela de 320 px a confirmação cabe, sem rolagem lateral, e os botões ficam visíveis',r['fit'] and r['btn'] and r['ov'],r);c.close()
print(sum(R),'/',len(R))
