import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re,os,time
pass
from playwright.sync_api import sync_playwright
from contrast import measure
URL=os.environ.get('URL',FILE_URL)
DATA=open(FIX+'/dados_ficticios.js',encoding='utf-8').read()
VIEWS=['home','rec','des','div','cx','rel','cfg','nt','cc','ntf','news','conq']
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
SRC=open(ROOT+'/index.html',encoding='utf-8').read()
JS_T=r"""(sel)=>{const root=sel?document.querySelector(sel):document;const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!e.closest('[hidden]')&&!e.closest('[inert]')};
 const q='button,a[href],input:not([type=hidden]),select,textarea,summary,[role=button],[data-act],[data-lk]';const small=[],noname=[];
 const desc=e=>e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+(e.className&&typeof e.className==='string'?'.'+e.className.trim().split(/\s+/)[0]:'')+(e.dataset&&e.dataset.act?'['+e.dataset.act+']':'');
 const name=e=>{let n=(e.getAttribute('aria-label')||'').trim();if(n)return n;const lb=e.getAttribute('aria-labelledby');if(lb){n=lb.split(' ').map(i=>(document.getElementById(i)||{}).textContent||'').join(' ').trim();if(n)return n}if(e.id){const l=document.querySelector('label[for="'+e.id+'"]');if(l&&l.textContent.trim())return l.textContent.trim()}const l2=e.closest('label');if(l2&&l2.textContent.trim())return l2.textContent.trim();n=(e.innerText||e.value||'').trim();if(n)return n;return (e.getAttribute('title')||e.getAttribute('placeholder')||'').trim()};
 [...root.querySelectorAll(q)].filter(vis).forEach(e=>{const r=e.getBoundingClientRect();if(e.type==='checkbox'||e.type==='radio'){const l=e.closest('label');if(l){const lr=l.getBoundingClientRect();if(Math.min(lr.width,lr.height)>=43.5)return}}
  if(Math.min(r.width,r.height)<43.5)small.push([desc(e),Math.round(r.width*10)/10,Math.round(r.height*10)/10]);if(!name(e))noname.push(desc(e))});
 return{small,noname}}"""
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
with sync_playwright() as p:
    b=p.chromium.launch()
    def new(w=393,h=851,th='light',rm=False,dev=None,data=DATA,first=False):
        kw=dict(p.devices[dev]) if dev else {'viewport':{'width':w,'height':h},'is_mobile':w<600,'has_touch':w<600}
        c=b.new_context(**kw,timezone_id='America/Sao_Paulo',reduced_motion='reduce' if rm else 'no-preference');c.add_init_script("window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and not any(k in m.text for k in ('404','Failed to load')) else None)
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(URL)
        if first:return c,pg
        pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','T');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(700)
        pg.evaluate("S="+data+";S.pref.theme='%s';applyPref();save();go('home')"%th);pg.wait_for_timeout(700);return c,pg
    # ===== 1) áreas de toque e nomes acessíveis: todas as telas, 4 tamanhos =====
    for (w,h,th) in ((320,568,'light'),(360,740,'light'),(393,851,'dark'),(851,393,'light')):
        c,pg=new(w,h,th);bad=[];nn=[]
        for v in VIEWS:
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(350);r=pg.evaluate(JS_T,None);bad+=[(v,)+x for x in r['small']];nn+=[(v,x) for x in r['noname']]
        ok(f'{w}x{h} [{th}]: nas 12 telas todo botão, campo e controle tem pelo menos 44 px de toque e nome acessível',not bad and not nn,(bad[:4],nn[:3]));c.close()
    # ===== 2) janelas: toque, nomes, foco, teclado, inércia do fundo =====
    c,pg=new()
    def opener(view,sel):
        pg.evaluate(f"go('{view}')");pg.wait_for_timeout(400);pg.focus(sel);return sel
    cases=[('cfg','[data-act=reset]','confirmação (Zerar dados)'),('cfg','#s-cfg [data-act=avs]','seletor de avatar'),('cx','[data-act=addb]','formulário (nova caixinha)'),('rel','[data-act=catlim]','limite de categoria')]
    for view,sel,nm in cases:
        o=opener(view,sel);pg.keyboard.press('Enter');pg.wait_for_timeout(500)
        st=pg.evaluate("""(()=>{const o=document.getElementById('ov'),h=document.getElementById(o.getAttribute('aria-labelledby')||'x');return{vis:!o.hidden,role:o.getAttribute('role'),modal:o.getAttribute('aria-modal'),title:h?h.textContent.trim():'',inside:o.contains(document.activeElement),mainInert:document.getElementById('main').inert===true,navInert:document.getElementById('nav').inert===true,mainHidden:document.getElementById('main').getAttribute('aria-hidden')}})()""")
        ok(f'Janela "{nm}" aberta pelo teclado: é um diálogo modal com título lido por leitor de tela, o foco entra nela e o fundo (conteúdo, navegação) fica inerte',st['vis'] and st['role']=='dialog' and st['modal']=='true' and st['title'] and st['inside'] and st['mainInert'] and st['navInert'] and st['mainHidden']=='true',st)
        t=pg.evaluate(JS_T,'#ov');ok(f'Janela "{nm}": todos os controles dentro dela têm 44 px e nome acessível',not t['small'] and not t['noname'],t)
        inside=[];
        for i in range(30):
            pg.keyboard.press('Tab');inside.append(pg.evaluate("document.getElementById('ov').contains(document.activeElement)"))
        for i in range(6):
            pg.keyboard.press('Shift+Tab');inside.append(pg.evaluate("document.getElementById('ov').contains(document.activeElement)"))
        ok(f'Janela "{nm}": o foco fica preso na janela (30 Tab e 6 Shift+Tab) — não escapa para o fundo',all(inside),inside.count(False))
        pg.evaluate("document.querySelector('#nav button').focus()");ok(f'Janela "{nm}": tentar focar a navegação de trás é ignorado (fundo inerte)',pg.evaluate("document.getElementById('ov').contains(document.activeElement)"))
        pg.keyboard.press('Escape');pg.wait_for_timeout(300)
        after=pg.evaluate("({hid:document.getElementById('ov').hidden,mi:document.getElementById('main').inert,ni:document.getElementById('nav').inert,ah:document.getElementById('main').getAttribute('aria-hidden'),same:document.activeElement===document.querySelector('%s')})"%sel)
        ok(f'Janela "{nm}": Esc fecha, devolve o conteúdo ao teclado e leitor de tela e o foco volta para o botão que abriu',after['hid'] and not after['mi'] and not after['ni'] and after['ah'] is None and after['same'],after)
        pg.focus(sel);pg.keyboard.press('Enter');pg.wait_for_timeout(400)
        cl=pg.locator('#ov [data-act=close]')
        if cl.count():cl.first.click()
        else:pg.keyboard.press('Escape')
        pg.wait_for_timeout(300);ok(f'Janela "{nm}": fechar pelo botão Cancelar também devolve o foco',pg.evaluate("document.activeElement===document.querySelector('%s')"%sel))
    # formulário enviado pelo teclado
    opener('cx','[data-act=addb]');pg.keyboard.press('Enter');pg.wait_for_timeout(400);pg.fill('#f [name=n]','Reserva teste');pg.evaluate("document.getElementById('f').querySelector('[name=n]').focus()");pg.keyboard.press('Enter');pg.wait_for_timeout(700)
    ok('Formulário enviado com Enter: a janela fecha, a caixinha aparece e o foco não se perde (vai para o conteúdo da tela, não para o nada)',pg.evaluate("document.getElementById('ov').hidden")  and pg.evaluate("S.boxes.some(b=>b.n==='Reserva teste')") and pg.evaluate("document.activeElement!==document.body"),pg.evaluate("document.activeElement.tagName"))
    # calculadora
    pg.evaluate("go('home')");pg.focus('#cfab');pg.keyboard.press('Enter');pg.wait_for_timeout(500)
    ok('Calculadora aberta pelo teclado: o foco entra no painel',pg.evaluate("!document.getElementById('cpan').hidden&&document.getElementById('cpan').contains(document.activeElement)"))
    t=pg.evaluate(JS_T,'#cpan');ok('Calculadora: teclas e botões com 44 px e nome acessível',not t['small'] and not t['noname'],t)
    pg.keyboard.press('Escape');pg.wait_for_timeout(300);ok('Calculadora: Esc fecha e o foco volta ao botão da calculadora',pg.evaluate("document.getElementById('cpan').hidden&&document.activeElement===document.getElementById('cfab')"))
    ok('Sem erros no console (janelas)',not pg.errs,pg.errs[:3]);c.close()
    # ===== 3) teclado: pular, anel de foco, navegação =====
    c,pg=new();pg.reload();pg.wait_for_selector('#nav button');pg.wait_for_timeout(700)
    pg.keyboard.press('Tab');pg.wait_for_timeout(350);sk=pg.evaluate("(()=>{const a=document.activeElement,r=a.getBoundingClientRect();return{cls:a.className,top:r.top,txt:a.textContent}})()")
    ok('Primeira tecla Tab: aparece o link "Pular para o conteúdo" (visível, dentro da tela)',sk['cls']=='skip' and sk['top']>=0 and 'Pular' in sk['txt'],sk)
    pg.keyboard.press('Enter');pg.wait_for_timeout(200);ok('Enter no link: o foco vai para o conteúdo principal',pg.evaluate("document.activeElement.id==='main'"))
    ring=[];seq=[]
    pg.evaluate("document.activeElement.blur()")
    for i in range(34):
        pg.keyboard.press('Tab');r=pg.evaluate("(()=>{const e=document.activeElement,s=getComputedStyle(e);return{t:e.tagName+(e.dataset&&e.dataset.act?'['+e.dataset.act+']':''),os:s.outlineStyle,ow:parseFloat(s.outlineWidth),oc:s.outlineColor,sh:s.boxShadow}})()");seq.append(r['t'])
        if r['t']!='BODY' and not(r['os']!='none' and r['ow']>=2 and 'rgba(0, 0, 0, 0)' not in r['oc']):ring.append(r)
    ok('Anel de foco: cada um dos 34 primeiros elementos focados pelo teclado mostra um contorno visível (≥ 2 px, com cor)',not ring and len(set(seq))>3,ring[:3])
    pg.evaluate("document.activeElement.blur()");pg.focus('#nav button[data-id=rec]');pg.keyboard.press('Enter');pg.wait_for_timeout(500)
    st=pg.evaluate("({v:view,act:document.activeElement.tagName,inView:document.querySelector('#s-rec').contains(document.activeElement),title:document.title,cur:[...document.querySelectorAll('#nav button')].filter(b=>b.getAttribute('aria-current')==='page').map(b=>b.dataset.id)})")
    ok('Navegar pelo teclado até Receitas (Enter): a tela muda, o foco vai para o título da tela, o título da página é "Receitas · WALL STREET" e só a aba atual é marcada (aria-current)',st['v']=='rec' and st['act'] in('H1','H2') and st['inView'] and st['title'].startswith('Receitas') and st['cur']==['rec'],st)
    pg.focus('#nav button[data-id=cfg]');pg.keyboard.press('Space');pg.wait_for_timeout(500);ok('A tecla Espaço também aciona as abas',pg.evaluate("view")=='cfg' and pg.evaluate("document.title").startswith('Ajustes'))
    titles={}
    for v in ['home','des','div','cx','rel','cfg']:
        pg.evaluate(f"go('{v}')");titles[v]=pg.evaluate("document.title")
    ok('Cada tela anuncia o próprio nome no título da página (leitores de tela e histórico do navegador)',len(set(titles.values()))==6 and all(t.endswith('WALL STREET') for t in titles.values()),titles)
    # tema por teclado
    pg.evaluate("go('cfg')");pg.focus('[data-act=theme][data-id=dark]');pg.keyboard.press('Enter');pg.wait_for_timeout(500)
    ok('Alternar tema pelo teclado: o botão "Escuro" muda o tema, informa o estado (aria-pressed) e o foco continua em um botão',pg.evaluate("document.documentElement.dataset.theme")=='dark' and pg.evaluate("document.querySelector('[data-act=theme][data-id=dark]').getAttribute('aria-pressed')")=='true' and pg.evaluate("document.querySelector('[data-act=theme][data-id=light]').getAttribute('aria-pressed')")=='false' and pg.evaluate("document.activeElement.tagName")=='BUTTON')
    ok('A cor do tema informa qual está selecionada (aria-pressed) e a lista tem 9 opções',pg.evaluate("document.querySelectorAll('.pal[aria-pressed=true]').length")==1 and pg.evaluate("document.querySelectorAll('.pal').length")==9)
    ok('Sem erros no console (teclado)',not pg.errs,pg.errs[:3]);c.close()
    # ===== 4) leitor de tela: rótulos =====
    c,pg=new();pg.evaluate("go('rel')");pg.wait_for_timeout(500)
    sem=pg.evaluate("""(()=>{const t=document.getElementById('toast'),n=document.getElementById('nav'),m=document.getElementById('main'),sv=[...document.querySelectorAll('#s-rel svg[role=img]')];return{toast:[t.getAttribute('role'),t.getAttribute('aria-live')],nav:n.getAttribute('aria-label'),main:m.tagName,lang:document.documentElement.lang,svgs:sv.length,svNo:sv.filter(s=>!s.getAttribute('aria-label')).length,sample:(sv[0]||{getAttribute:()=>''}).getAttribute('aria-label'),bars:[...document.querySelectorAll('#s-rel .bar,#s-rel .cbar,#s-rel .stk')].every(x=>x.getAttribute('aria-hidden')==='true')}})()""")
    ok('Leitores de tela: avisos (toast) são lidos sozinhos (role=status), navegação e conteúdo principal têm nome/ponto de referência e o idioma é pt-BR',sem['toast']==['status','polite'] and sem['nav']=='Navegação principal' and sem['main']=='MAIN' and sem['lang']=='pt-BR',sem)
    ok('Gráficos têm descrição falada (título + valor de cada mês, com nome do mês por extenso) e as barras decorativas ficam fora da leitura',sem['svgs']>=6 and sem['svNo']==0 and 'R$' in sem['sample'] and 'setembro' in sem['sample'].lower() and sem['bars'] and pg.evaluate("[...document.querySelectorAll('#s-rel svg[role=img]')].some(s=>/Receitas recebidas por mês/.test(s.getAttribute('aria-label')))"),sem['sample'][:200])
    pg.evaluate("S.pref.hide=1;render()");lab=pg.evaluate("document.querySelector('#s-rel svg[role=img]').getAttribute('aria-label')");ok('Com os valores escondidos (olho), a descrição falada dos gráficos também esconde os valores','•••••' in lab and not re.search(r'R\$ \d',lab),lab[:80]);pg.evaluate("S.pref.hide=0;render()")
    ok('Todas as mensagens de erro do código usam role="alert" (lidas na hora)',len(re.findall(r'class="err"(?! role)',SRC))==0 and SRC.count('class="err" role="alert"')>=9)
    pg.evaluate("go('cfg');document.querySelector('[data-act=reset]').focus();document.querySelector('[data-act=reset]').click()");pg.wait_for_timeout(400)
    try:snap=pg.locator('#ov').aria_snapshot()
    except Exception as e:snap=''
    ok('A janela aparece na árvore de acessibilidade como diálogo com o nome do seu título ("Zerar todos os dados")',('dialog' in snap and 'Zerar todos os dados' in snap) if snap else pg.evaluate("document.getElementById('ov').getAttribute('role')")=='dialog',snap[:120]);pg.evaluate("closeOv()")
    ok('Zoom liberado: a tag viewport não bloqueia ampliação (sem user-scalable=no / maximum-scale)','user-scalable' not in SRC.split('<meta name="viewport"')[1].split('>')[0] and 'maximum-scale' not in SRC.split('<meta name="viewport"')[1].split('>')[0]);c.close()
    # ===== 5) redução de animações =====
    JS_ANI="""(()=>document.getAnimations().filter(a=>a.playState==='running').map(a=>{const t=a.effect&&a.effect.getTiming?a.effect.getTiming():{},tg=a.effect&&a.effect.target;return {n:a.animationName||a.transitionProperty||'',it:t.iterations,d:t.duration,el:tg?(tg.id||tg.className&&String(tg.className.baseVal!==undefined?tg.className.baseVal:tg.className)||tg.tagName):''}}))()"""
    c,pg=new(rm=True);bad=[]
    for v in VIEWS:
        pg.evaluate(f"go('{v}')");pg.wait_for_timeout(900);bad+=[(v,x) for x in pg.evaluate(JS_ANI) if x['it'] in(None,'Infinity') or x['it']==float('inf') or (x['d'] or 0)>300]
    pg.evaluate("go('home')");pg.evaluate("form('x',[{k:'a',l:'Campo',v:''}],()=>{})");pg.wait_for_timeout(700);bad+=[('modal',x) for x in pg.evaluate(JS_ANI) if x['it'] in(None,'Infinity') or (x['d'] or 0)>300]
    ok('"Reduzir movimento" do aparelho: nenhuma animação infinita nem longa roda em nenhuma das 12 telas nem nas janelas',not bad,bad[:5]);c.close()
    c,pg=new(rm=False);pg.evaluate("go('home')");pg.wait_for_timeout(900);n=len(pg.evaluate(JS_ANI));ok('Sem essa configuração as animações continuam (nada foi removido): a Home tem animações em andamento',n>0,n);c.close()
    c,pg=new(first=True,rm=True);pg.wait_for_selector('[data-lk=new]');pg.wait_for_timeout(900);bad=[x for x in pg.evaluate(JS_ANI) if x['it'] in(None,'Infinity') or (x['d'] or 0)>300];ok('"Reduzir movimento": a tela de boas-vindas também fica sem animação infinita/longa',not bad,bad[:4]);c.close()
    # ===== 6) rolagem lateral, sobreposição e texto cortado =====
    for (w,h,th) in ((320,568,'light'),(360,740,'dark'),(393,851,'light'),(851,393,'dark')):
        c,pg=new(w,h,th);ov=[];cover=[];clip=[]
        for v in VIEWS:
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(300)
            if not pg.evaluate(OVER):ov.append(v)
            pg.evaluate("window.scrollTo(0,document.body.scrollHeight)");pg.wait_for_timeout(150)
            cv=pg.evaluate("""(()=>{const out=[];document.querySelectorAll('main button,main a,main input,main select,main summary').forEach(e=>{const r=e.getBoundingClientRect();if(r.width<1||r.height<1||r.bottom>innerHeight||r.top<0||e.closest('[hidden]'))return;const t=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);if(t&&!(e.contains(t)||t.contains(e)))out.push((e.dataset.act||e.tagName)+' coberto por '+(t.id||t.className||t.tagName))});return out.slice(0,3)})()""");cover+=[(v,x) for x in cv]
            cl=pg.evaluate("""(()=>{const out=[];document.querySelectorAll('#nav button,main button,main h2,main h3,main .lbl,main .tag').forEach(e=>{if(e.closest('[hidden]')||!e.getClientRects().length)return;if(e.scrollWidth>e.clientWidth+1&&getComputedStyle(e).overflow!=='visible'&&e.clientWidth>0)out.push((e.dataset.act||e.tagName)+':'+(e.innerText||'').trim().slice(0,24))});return out.slice(0,3)})()""");clip+=[(v,x) for x in cl]
        ok(f'{w}x{h} [{th}]: sem rolagem lateral em nenhuma das 12 telas',not ov,ov)
        ok(f'{w}x{h} [{th}]: no fim de cada tela, nenhum botão/campo fica coberto pela barra de navegação ou pela calculadora',not cover,cover[:3])
        ok(f'{w}x{h} [{th}]: nenhum texto de botão, título ou aba fica cortado',not clip,clip[:4])
        c.close()
    # ===== 7) contraste (tema claro e escuro, tudo) =====
    for th in ('light','dark'):
        c,pg=new(393,851,th);bad=[];tot=0
        pg.set_viewport_size({'width':393,'height':9000})
        for v in VIEWS:
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(450)
            for sc in ('content','nav'):
                for x in measure(pg,sc):
                    tot+=1
                    if x[0]<x[1]:bad.append((v,sc)+x)
        for nm,js in (('form',"form('Novo item',[{k:'a',l:'Nome',v:''}],()=>{})"),('ask',"ask('Tem certeza?',()=>{})")):
            pg.evaluate(js);pg.wait_for_timeout(500)
            for x in measure(pg,'sheet'):
                tot+=1
                if x[0]<x[1]:bad.append((nm,'sheet')+x)
            pg.evaluate("closeOv()")
        ok(f'[{th}] Contraste mínimo 4,5:1 em todas as telas e janelas ({tot} textos medidos)',not bad and tot>400,bad[:4]);c.close()
    # ===== 8) telas de entrada (boas-vindas, cadastro) =====
    c,pg=new(first=True);pg.wait_for_selector('[data-lk=new]');pg.wait_for_timeout(700)
    t=pg.evaluate(JS_T,'#lock');ok('Boas-vindas: alvos de 44 px e nomes acessíveis',not t['small'] and not t['noname'],t)
    pg.click('[data-lk=new]');pg.fill('#nf [name=n]','Paul');pg.wait_for_timeout(1300);t=pg.evaluate(JS_T,'#lock');ok('Cadastro (nome): alvos e nomes ok',not t['small'] and not t['noname'],t)
    pg.click('#nf button');pg.wait_for_selector('#mf');pg.wait_for_timeout(1300);t=pg.evaluate(JS_T,'#lock');ok('Escolha do mascote: alvos e nomes ok',not t['small'] and not t['noname'],t)
    pg.click('#mf .b1');pg.wait_for_selector('#cf');pg.wait_for_timeout(1300);t=pg.evaluate(JS_T,'#lock');ok('Escolha da cor: alvos e nomes ok',not t['small'] and not t['noname'],t)
    pg.click('#cf button:not([type=button])');pg.wait_for_selector('#sf');pg.wait_for_timeout(1300);t=pg.evaluate(JS_T,'#lock');ok('Criar usuário e senha: alvos e nomes ok',not t['small'] and not t['noname'],t);c.close()
    # ===== 9) Android (emulação do Chromium: Pixel 5 e Galaxy S9+) =====
    for dev in ('Pixel 5','Galaxy S9+'):
        c,pg=new(dev=dev);bad=[];ov=[]
        for v in VIEWS:
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(300);r=pg.evaluate(JS_T,None);bad+=[(v,)+x for x in r['small']]+[(v,x) for x in r['noname']]
            if not pg.evaluate(OVER):ov.append(v)
        pg.focus('[data-act=reset]') if False else None
        ok(f'Emulação Android ({dev}): 12 telas com alvos de 44 px, nomes acessíveis e sem rolagem lateral (emulação no Chromium — não é aparelho físico)',not bad and not ov,(bad[:3],ov));c.close()
    # ===== 10) nada de cálculo/dados mudou (comparação com a versão anterior) =====
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1");pg=c.new_page();pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','T');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(600)
    out=pg.evaluate("(()=>{S="+DATA+";return JSON.stringify([balance(),flows(),finSit().m,finSit().level,relCommit('2026-11'),relFlow('2026-11'),catSpend('2026-11'),S])})()");c.close()
    ok('Cálculos e dados de teste idênticos à referência guardada (saldo, fluxo, situação financeira, relatórios, categorias): nenhuma lógica financeira foi tocada',check_golden('calculos_dados_ficticios',sha(out)),'se a mudança foi intencional: WS_UPDATE_GOLDEN=1')
print(sum(R),'/',len(R))
