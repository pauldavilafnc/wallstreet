import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json,shutil,threading,http.server,socketserver,functools,pathlib,re
import struct
from playwright.sync_api import sync_playwright
WORK=pathlib.Path(TMP+'/pwa');shutil.rmtree(WORK,ignore_errors=True);SITE=WORK/'wallstreet';SITE.mkdir(parents=True)
SRC=pathlib.Path(REPO)
for f in ['index.html','manifest.webmanifest','sw.js']: shutil.copy(SRC/f,SITE/f)
[shutil.copy(SRC/f,SITE/f) for f in ['icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png','favicon-32.png','favicon-48.png']];shutil.copy(pathlib.Path(FIX)/'noticias_teste.json',SITE/'noticias.json')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(WORK));H.log_message=lambda *a,**k:None
socketserver.TCPServer.allow_reuse_address=True;srv=socketserver.TCPServer(('127.0.0.1',PORT2),H);threading.Thread(target=srv.serve_forever,daemon=True).start()
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:170] if d else ''))
URL=f'http://127.0.0.1:{PORT2}/wallstreet/'
m=json.load(open(SITE/'manifest.webmanifest'))
ok('Manifesto: nome, short_name ≤12, start_url e scope relativos, display standalone',m['name']=='Wolfin – Controle Financeiro' and len(m['short_name'])<=12 and m['start_url']=='./' and m['scope']=='./' and m['display']=='standalone')
ok('Manifesto: cores do tema azul-marinho',m['theme_color']=='#0B1730' and m['background_color']=='#0B1730')
ic={i['purpose']:i for i in m['icons']};sizes=[]
for i in m['icons']:
    d_=open(SITE/i['src'],'rb').read(24);w_,h_=struct.unpack('>II',d_[16:24]);sizes.append((w_,h_));assert d_[:8]==b'\x89PNG\r\n\x1a\n' and f'{w_}x{h_}'==i['sizes'],(i,w_,h_)
ok('Ícones existem com os tamanhos declarados (192, 512, maskable 512)',sorted(sizes)==[(192,192),(512,512),(512,512)] and 'maskable' in ic,sizes)
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,service_workers='allow')
    pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m_:errs.append(m_.text) if m_.type=='error' else None)
    pg.goto(URL);pg.wait_for_function("navigator.serviceWorker.controller||navigator.serviceWorker.ready.then(()=>true)",timeout=10000);pg.wait_for_timeout(800)
    pg.reload();pg.wait_for_timeout(500)
    ok('Service worker registrado, ativo e controlando a página',pg.evaluate("!!navigator.serviceWorker.controller"))
    cdp=ctx.new_cdp_session(pg)
    man=cdp.send('Page.getAppManifest');ok('Chrome lê o manifesto sem erros',not man.get('errors') and man.get('url','').endswith('manifest.webmanifest'),man.get('errors'))
    inst=cdp.send('Page.getInstallabilityErrors');ok('Chrome considera o site instalável (sem erros de instalabilidade)',inst.get('installabilityErrors')==[],inst)
    ok('Ícone do atalho (apple-touch-icon) e favicon declarados',pg.evaluate("[document.querySelector('link[rel=apple-touch-icon]').href,document.querySelector('link[rel=icon]').href].every(u=>u.startsWith('"+URL+"'))"))
    # dados + offline
    pg.evaluate("S.owner='Paul Teste';save()");before=pg.evaluate("localStorage.getItem('wallstreet.v1')")
    ctx.set_offline(True);pg.reload();pg.wait_for_timeout(600)
    ok('OFFLINE: o app abre (cópia guardada) e mostra os dados',pg.evaluate("typeof S!=='undefined'&&S.owner")=='Paul Teste' and pg.locator('#s-home .hello').count()==1,pg.title())
    pg.evaluate("go('news')");pg.wait_for_timeout(300);ok('OFFLINE: notícias mostram a última versão e avisam',pg.locator('#s-news .news').count()>0 and 'Não foi possível atualizar agora' in pg.inner_text('#s-news') or 'Sem internet' in pg.inner_text('#s-news'),pg.inner_text('#s-news')[:140])
    pg.evaluate("go('rec')");ok('OFFLINE: navegar e usar o app continua funcionando',pg.locator('#s-rec .opc').count()==1)
    ctx.set_offline(False)
    # atualização: arquivo novo no servidor chega quando há internet (rede primeiro)
    s=(SITE/'index.html').read_text(encoding='utf-8');(SITE/'index.html').write_text(s.replace('<title>Wolfin – Controle Financeiro</title>','<title>Wolfin – Controle Financeiro v2</title>'),encoding='utf-8')
    pg.reload();pg.wait_for_timeout(500);ok('Com internet, a versão nova do site aparece (sem ficar presa em cópia antiga)',pg.title()=='Wolfin – Controle Financeiro v2',pg.title())
    ok('Dados do app intactos após as recargas',pg.evaluate("localStorage.getItem('wallstreet.v1')")==before)
    ok('Sem erros no console',not errs,errs)
srv.shutdown();print(sum(R),'/',len(R))
