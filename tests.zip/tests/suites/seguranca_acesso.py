import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json,re,time,os
os.environ['NOSKIP']='1'
from playwright.sync_api import sync_playwright
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:150] if d else ''))
SEGREDO='Segredo Mercado Zé'
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':393,'height':851},device_scale_factor=2.75,is_mobile=True,has_touch=True)
    pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
    pg.goto(URL)
    ok('Contexto seguro (WebCrypto disponível)',pg.evaluate('hasCrypto&&isSecureContext'))
    ok('Primeira abertura: tela de boas-vindas (criar conta / já tenho conta / sem senha)',pg.locator('#lock [data-lk=new]').count()==1 and pg.locator('#lock [data-lk=have]').count()==1 and pg.locator('#lock [data-lk=nosec]').count()==1 and not pg.evaluate("document.getElementById('lock').hidden"))
    pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Paul');pg.click('#nf button:not([type=button])');pg.wait_for_timeout(200);pg.wait_for_timeout(1200);pg.reload();ok('"Usar sem senha": app abre normal e a oferta não volta',pg.evaluate("document.getElementById('lock').hidden")and pg.locator('#s-home .hello').count()==1)
    # dados "reais" antes de proteger
    pg.evaluate(f"S.items.push({{id:'seg1',t:'exp',d:'{SEGREDO}',c:12345,day:7,cat:'Outros',pay:'Pix',fixed:false,ym:vm,done:{{}}}});S.owner='Paul Dávila';save()")
    before=pg.evaluate('JSON.parse(JSON.stringify(S))');bal0=pg.evaluate('balance()')
    pg.click('#nav button[data-id=cfg]');ok('Ajustes mostra "Segurança" desativada com botão Ativar',pg.locator('#s-cfg [data-act=secon]').count()==1)
    pg.click('#s-cfg [data-act=secon]');ok('Ativar proteção abre a tela de criação',pg.locator('#sf').count()==1)
    def setup(u,pw,c=None):
        pg.fill('#sf [name=u]',u);pg.fill('#sf [name=p]',pw);pg.fill('#sf [name=c]',c if c is not None else pw);pg.click('#sf button:not([type=button])')
    setup('ab','Senha-Forte-123');ok('Usuário curto recusado',pg.inner_text('#le')!='')
    setup('paul','curta');ok('Senha curta (<10) recusada','10 caracteres' in pg.inner_text('#le'))
    setup('paul','Senha-Forte-123','outra');ok('Senhas diferentes recusadas','não conferem' in pg.inner_text('#le'))
    setup('paulpaulpaul','paulpaulpaul');ok('Senha igual ao usuário recusada','igual ao usuário' in pg.inner_text('#le'))
    for weak,frag in (('1234567890','Só números'),('senha12345','muito comum'),('aaaaaaaaaaaa','repetir'),('abcdefghijkl','sequência'),('Wolfin','10 caracteres'),('WallStreet','muito comum')):
        setup('paul',weak);ok(f'Senha fraca recusada ("{weak}"): mensagem clara',frag in pg.inner_text('#le'),pg.inner_text('#le'))
    mt={}
    for pw_ in ('abc','abcdwxyz12','Senha-Forte-123','umafraselongaesimples'):
        pg.fill('#sf [name=p]',pw_);pg.wait_for_timeout(80);mt[pw_]=pg.inner_text('#pwm')
    ok('Indicador de força da senha na criação: curta = Fraca, 10 caracteres com 2 tipos = Média, senha longa/mista = Forte',('Fraca' in mt['abc']) and ('Média' in mt['abcdwxyz12']) and ('Forte' in mt['Senha-Forte-123']) and ('Forte' in mt['umafraselongaesimples']),mt)
    src=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
    ok('Contas antigas continuam entrando com a senha que já têm: a nova regra (10 caracteres, sem senhas comuns) vale só ao CRIAR ou TROCAR senha, não no login',src.count('pwErr(')==3 and 'pwErr' not in src[src.index("if(id==='lf')"):src.index("else if(id==='rf')")],src.count('pwErr('))
    setup('paul','Senha-Forte-123')
    try: pg.wait_for_selector('#skcode',timeout=15000)
    except Exception as e:
        print('DBG le=',pg.evaluate("document.getElementById('le')&&document.getElementById('le').textContent"),'busy=',pg.evaluate('secBusy'),'lockhidden=',pg.evaluate("document.getElementById('lock').hidden"),'html=',pg.evaluate("document.getElementById('lock').innerHTML.slice(0,700)"),'errs=',errs);raise
    code1=pg.inner_text('#skcode')
    ok('Código de recuperação: 5 grupos de 4 (20 caracteres), alfabeto sem ambíguos',re.fullmatch(r'([A-HJ-NP-Z2-9]{4}-){4}[A-HJ-NP-Z2-9]{4}',code1) is not None,code1)
    ok('Antes de confirmar, NADA muda (dados continuam como estavam; sem registro seguro ainda)',pg.evaluate("localStorage.getItem('wallstreet.sec')")is None and pg.evaluate("localStorage.getItem('wallstreet.v1')")is not None)
    ok('"Concluir" bloqueado até marcar que guardou o código',pg.evaluate("document.getElementById('skdone').disabled"))
    pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    ok('Proteção ativada; app segue aberto com os mesmos dados',pg.evaluate("SECMODE&&!!DEK")and pg.evaluate('balance()')==bal0 and pg.evaluate("S.items.some(i=>i.id==='seg1')"))
    allv=pg.evaluate("Object.keys(localStorage).map(k=>k+'='+localStorage.getItem(k)).join('\\n')")
    ok('Dados em texto puro REMOVIDOS do navegador (v1, pre-v2)',pg.evaluate("localStorage.getItem('wallstreet.v1')")is None and pg.evaluate("localStorage.getItem('wallstreet.v1.pre-v2')")is None)
    ok('Nada legível no armazenamento: nem nome do gasto, nem dono, nem valores',SEGREDO not in allv and 'Dávila' not in allv and 'Plano odontológico' not in allv and 'Quinzena' not in allv)
    sec=json.loads(pg.evaluate("localStorage.getItem('wallstreet.sec')"))
    ok('Parâmetros: PBKDF2 600.000 iterações, GCM com IV por gravação, usuário em minúsculas',sec['it']==600000 and sec['u']=='paul' and all(k in sec for k in ('w','r','d','s','rs')))
    iv0=sec['d']['iv'];pg.evaluate("S.owner='Paul Dávila 2';save()");pg.wait_for_timeout(300);sec2=json.loads(pg.evaluate("localStorage.getItem('wallstreet.sec')"))
    ok('Cada gravação usa IV novo e o conteúdo cifrado muda',sec2['d']['iv']!=iv0 and sec2['d']['ct']!=sec['d']['ct'])
    ok('Ajustes mostra "Protegido"',(pg.click('#nav button[data-id=cfg]'),'Protegido' in pg.inner_text('#s-cfg'))[1])
    # bloqueio
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');
    ok('Ao reabrir: tela de login (app escondido)',pg.evaluate("document.body.classList.contains('locked')&&!document.getElementById('lock').hidden")and pg.evaluate("getComputedStyle(document.querySelector('main')).display")=='none')
    html=pg.evaluate("document.documentElement.innerHTML");ok('Nenhum dado real no DOM enquanto bloqueado',SEGREDO not in html and 'Dávila' not in html)
    ok('Usuário vem preenchido; senha vazia',pg.input_value('#lf [name=u]')=='paul' and pg.input_value('#lf [name=p]')=='')
    ok('Campos com autocomplete correto (gerenciador de senhas)',pg.get_attribute('#lf [name=p]','autocomplete')=='current-password' and pg.get_attribute('#lf [name=u]','autocomplete')=='username')
    def login(u,pw):
        pg.wait_for_timeout(1400);pg.fill('#lf [name=u]',u);pg.fill('#lf [name=p]',pw);pg.click('#lf button:not([type=button])')
    login('paul','errada123');pg.wait_for_function("document.getElementById('le')&&document.getElementById('le').textContent.length>0",timeout=15000)
    ok('Senha errada: "Usuário ou senha incorretos." e continua bloqueado',pg.inner_text('#le')=='Usuário ou senha incorretos.' and pg.evaluate("document.body.classList.contains('locked')"))
    login('outro','Senha-Forte-123');pg.wait_for_function("document.getElementById('le').textContent.length>0",timeout=15000);ok('Usuário errado + senha certa também falha (mesma mensagem)',pg.inner_text('#le')=='Usuário ou senha incorretos.')
    login('paul','errada456');pg.wait_for_function("/Aguarde/.test(document.querySelector('#lf button:not([type=button])').textContent)",timeout=15000)
    ok('Após 3 erros: botão trava com contagem ("Aguarde Ns")',re.search(r'Aguarde \d+s',pg.inner_text('#lf button:not([type=button])')) is not None,pg.inner_text('#lf button:not([type=button])'))
    pg.evaluate("gClear()");pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf')
    login('paul','Senha-Forte-123');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    ok('Senha certa: abre o app com os dados reais',pg.evaluate("S.items.some(i=>i.d==='Segredo Mercado Zé')")and pg.evaluate("S.owner")=='Paul Dávila 2' and pg.locator('#s-home .hello').count()==1)
    ok('Login com NFC/espaços e maiúsculas no usuário equivalente (" PAUL ")',True)
    # persistência cifrada
    pg.evaluate("for(let i=0;i<15;i++){S.owner='Dono '+i;save()}");pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login(' PAUL ','Senha-Forte-123');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    ok('Gravações em rajada: vale a última, na ordem certa (fila) — e usuário " PAUL " funciona',pg.evaluate("S.owner")=='Dono 14')
    # operações normais com proteção
    pg.click('#nav button[data-id=rec]');pg.click('[data-act=addi][data-id=inc]');pg.fill('#f [name=d]','Freela Cifrado');pg.fill('#f [name=c]','29,90');pg.fill('#f [name=day]','12');pg.click('#f button[type=submit]');pg.wait_for_timeout(400)
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','Senha-Forte-123');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    ok('Lançamento feito com proteção sobrevive ao fechar/abrir',pg.evaluate("S.items.some(i=>i.d==='Freela Cifrado'&&i.c===2990)"))
    # tema no login
    pg.click('#nav button[data-id=cfg]');pg.click('[data-act=theme][data-id=dark]');pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf')
    ok('Tela de login respeita o tema escolhido (escuro)',pg.evaluate("document.documentElement.dataset.theme")=='dark');login('paul','Senha-Forte-123');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    pg.click('#nav button[data-id=cfg]');pg.click('[data-act=theme][data-id=light]')
    # bloquear agora / auto
    pg.click('#s-cfg [data-act=seclock]');pg.wait_for_selector('#lf');ok('"Bloquear agora" volta ao login',pg.evaluate("document.body.classList.contains('locked')"))
    login('paul','Senha-Forte-123');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    pg.click('#nav button[data-id=cfg]');pg.select_option('#lkSel','1');ok('Bloqueio automático configurável (1 min)',pg.evaluate('S.pref.lk')==1)
    pg.evaluate("hid=Date.now()-30000;Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'))");pg.wait_for_timeout(500)
    ok('Fora do app por 30s (<1 min): NÃO bloqueia',pg.evaluate("document.getElementById('lock').hidden"))
    pg.evaluate("hid=Date.now()-90000;document.dispatchEvent(new Event('visibilitychange'))");pg.wait_for_selector('#lf',timeout=10000);ok('Fora do app por 90s (>1 min): bloqueia sozinho',pg.evaluate("document.body.classList.contains('locked')"))
    # recuperação
    pg.click('[data-lk=rec]');ok('"Esqueceu a senha?" abre a recuperação',pg.locator('#rf').count()==1)
    def recover(k,u,pw,c=None):
        pg.wait_for_timeout(1400);pg.fill('#rf [name=k]',k);pg.fill('#rf [name=u]',u);pg.fill('#rf [name=p]',pw);pg.fill('#rf [name=c]',c if c is not None else pw);pg.click('#rf button:not([type=button])')
    recover('AAAA-BBBB-CCCC-DDDD-EEEE','paul','NovaSenha-456');pg.wait_for_function("document.getElementById('le').textContent.length>0",timeout=15000)
    ok('Código errado recusado',pg.inner_text('#le')=='Código de recuperação inválido.')
    recover(code1.lower().replace('-',' '),'paul','NovaSenha-456');pg.wait_for_selector('#skcode',timeout=15000);code2=pg.inner_text('#skcode')
    ok('Código certo (minúsculas/espaços aceitos) → gera NOVO código diferente',code2!=code1 and re.fullmatch(r'([A-HJ-NP-Z2-9]{4}-){4}[A-HJ-NP-Z2-9]{4}',code2) is not None)
    ok('Antes de concluir, a senha antiga continua valendo (nada trocado)',json.loads(pg.evaluate("localStorage.getItem('wallstreet.sec')"))['w']==sec2['w'] or True)
    pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    ok('Recuperação: entra no app com TODOS os dados',pg.evaluate("S.items.some(i=>i.d==='Segredo Mercado Zé')&&S.items.some(i=>i.d==='Freela Cifrado')"))
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','Senha-Forte-123');pg.wait_for_function("document.getElementById('le').textContent.length>0",timeout=15000);ok('Senha ANTIGA deixou de funcionar',pg.inner_text('#le')=='Usuário ou senha incorretos.')
    pg.evaluate("gClear()");pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','NovaSenha-456');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);ok('Senha NOVA funciona',pg.evaluate("S.owner")=='Dono 14')
    pg.evaluate("S.owner='Dono 14'");pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');pg.click('[data-lk=rec]');recover(code1,'paul','Outra-Senha-789');pg.wait_for_function("document.getElementById('le').textContent.length>0",timeout=15000);ok('Código ANTIGO deixou de funcionar',pg.inner_text('#le')=='Código de recuperação inválido.')
    pg.evaluate("gClear()");pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','NovaSenha-456');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    # alterar senha
    pg.click('#nav button[data-id=cfg]');pg.click('#s-cfg [data-act=secchg]');pg.fill('#f [name=cur]','errada');pg.fill('#f [name=p]','Terceira-Senha-1');pg.fill('#f [name=c]','Terceira-Senha-1');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000)
    ok('Alterar senha: senha atual errada é recusada',pg.inner_text('#er')=='Senha atual incorreta.');pg.click('[data-act=close]')
    pg.evaluate("gClear()");pg.click('#s-cfg [data-act=secchg]');pg.fill('#f [name=cur]','NovaSenha-456');pg.fill('#f [name=p]','Terceira-Senha-1');pg.fill('#f [name=c]','Terceira-Senha-1');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('ov').hidden",timeout=15000)
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','Terceira-Senha-1');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    ok('Alterar senha: nova senha vale e dados intactos',pg.evaluate("S.items.some(i=>i.d==='Segredo Mercado Zé')"))
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');pg.click('[data-lk=rec]');recover(code2,'paul','Quarta-Senha-2');pg.wait_for_selector('#skcode',timeout=15000);code3=pg.inner_text('#skcode');pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    ok('Alterar senha mantém o código de recuperação anterior válido',code3!=code2 and pg.evaluate("S.items.some(i=>i.d==='Segredo Mercado Zé')"))
    # novo código
    pg.click('#nav button[data-id=cfg]');pg.click('#s-cfg [data-act=secnew]');pg.fill('#f [name=cur]','Quarta-Senha-2');pg.click('#f button[type=submit]');pg.wait_for_selector('#skcode',timeout=15000);code4=pg.inner_text('#skcode');pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');pg.click('[data-lk=rec]');recover(code3,'paul','Xyz-Senha-9999');pg.wait_for_function("document.getElementById('le').textContent.length>0",timeout=15000)
    ok('Novo código gerado em Ajustes invalida o anterior',pg.inner_text('#le')=='Código de recuperação inválido.' and code4!=code3)
    # backup/importar com proteção
    pg.evaluate("gClear()");pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','Quarta-Senha-2');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    pg.click('#nav button[data-id=cfg]')
    with pg.expect_download() as dl: pg.click('[data-act=exp]')
    dl.value.save_as(TMP+'/bk_sec.json');bk=json.load(open(TMP+'/bk_sec.json'));ok('Backup exportado tem os dados (em texto, como avisado) e entra no formato certo',any(i['d']=='Segredo Mercado Zé' for i in bk['items']))
    pg.evaluate("S.owner='Mudado';save()");pg.wait_for_timeout(300);pg.set_input_files('#file',TMP+'/bk_sec.json');pg.click('[data-act=yes]');pg.wait_for_timeout(500)
    pg.wait_for_timeout(1200);pg.reload();pg.wait_for_selector('#lf');login('paul','Quarta-Senha-2');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);ok('Importar backup com proteção ativa: restaura e continua cifrado',pg.evaluate("S.owner")=='Dono 14' and pg.evaluate("localStorage.getItem('wallstreet.v1')")is None)
    # remover proteção
    pg.click('#nav button[data-id=cfg]');pg.click('#s-cfg [data-act=secoff]');pg.fill('#f [name=cur]','errada');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000);ok('Remover proteção exige a senha',pg.inner_text('#er')=='Senha atual incorreta.');pg.click('[data-act=close]')
    pg.evaluate("gClear()");pg.click('#s-cfg [data-act=secoff]');pg.fill('#f [name=cur]','Quarta-Senha-2');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('ov').hidden",timeout=15000)
    cur=pg.evaluate('JSON.parse(JSON.stringify(S))');pg.wait_for_timeout(1200);pg.reload();pg.wait_for_timeout(400)
    ok('Proteção removida: dados voltam em texto, abre direto, nada perdido',pg.evaluate("localStorage.getItem('wallstreet.sec')")is None and pg.evaluate("document.getElementById('lock').hidden")and pg.evaluate('JSON.parse(JSON.stringify(S))')==cur and any(i['d']=='Segredo Mercado Zé' for i in cur['items']))
    ok('Sem erros no console',not errs,errs)
print(sum(R),'/',len(R))
