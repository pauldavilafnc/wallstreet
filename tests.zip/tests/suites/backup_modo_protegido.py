import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,os,json,time
pass
from playwright.sync_api import sync_playwright
URL=os.environ.get('WS_URL',HTTP_URL)
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
PW='Senha-Forte-123'
INSTR=INSTR_JS
RICH="""(n,own)=>{const o=seed();o.owner=own;o.opening={c:100000,d:'2026-01-01'};o.items=[{id:'i1',t:'inc',d:'Salário',c:300000,day:5,fixed:true,from:'2026-01',done:{},cat:'Salário',pay:'Pix'}];for(let i=0;i<n;i++)o.items.push({id:'x'+i,t:'exp',d:'Extra '+i,c:1000*(i+1),day:3,fixed:true,from:'2026-01',done:{},cat:'Outros',pay:'Pix'});o.flags={tour:1};return migrate(o)}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def newctx():
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo');c.add_init_script(INSTR);return c
    def mk(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and not any(k in m.text for k in ('404','Failed to load','bad HTTP','Quota','cheio')) else None);return pg
    def create(pg):
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(400);OB_TO_SETUP(pg,'Paul');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]',PW);pg.fill('#sf [name=c]',PW);pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1200)
    def login(pg):
        pg.wait_for_selector('#lf',timeout=20000);pg.fill('#lf [name=u]','paul');pg.fill('#lf [name=p]',PW);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(800)
    def imp(pg,data):
        pg.evaluate("document.getElementById('toast').className='';closeOv()");pg.set_input_files('#file',files=[{'name':'b.json','mimeType':'application/json','buffer':data.encode()}]);pg.wait_for_timeout(900)
        return pg.inner_text('#toast'),(pg.inner_text('#ov') if pg.evaluate("!document.getElementById('ov').hidden") else '')
    STORED="(async()=>{const o=JSON.parse(localStorage.getItem('wallstreet.sec'));return dec.decode(await unseal(DEK,o.d))})()"
    # gera um backup (outro "aparelho")
    c0=newctx();g=mk(c0);g.goto(URL);g.wait_for_timeout(800);g.evaluate("localStorage.setItem('wallstreet.welcomed','1');localStorage.setItem('wallstreet.secskip','1')");g.reload();g.wait_for_selector('#nav button')
    g.evaluate(f"S=({RICH})(4,'Ana do Backup');save();render()");plain=g.evaluate("bkpExportText()");enc=g.evaluate("(async()=>{const salt=rnd(16),it=600000,sl=await seal(await kdf(np('SenhaBackup1'),salt,it),enc.encode(JSON.stringify(S)));return JSON.stringify({app:'wallstreet-backup',enc:true,v:1,at:todayStr(),it,s:b64(salt),iv:sl.iv,ct:sl.ct},null,1)})()");want=json.loads(plain);c0.close()
    # ===== modo protegido: importar, persistir, recarregar =====
    c=newctx();P=mk(c);create(P);P.evaluate(f"(()=>{{S=({RICH})(1,'Paul');S.flags={{tour:1}};commit('x')}})()");P.wait_for_timeout(3000)
    cur=P.evaluate("JSON.stringify(S)");curst=P.evaluate("localStorage.getItem('wallstreet.sec')")
    t,dlg=imp(P,plain);ok('Modo protegido: confirmação com resumo antes de substituir; nada gravado até confirmar',('Ana do Backup' in dlg) and 'SUBSTITUÍDOS' in dlg and P.evaluate("JSON.stringify(S)")==cur and P.evaluate("localStorage.getItem('wallstreet.sec')")==curst,dlg[:200])
    P.click('[data-act=yes]');P.wait_for_function("!SAVING&&!SNAP",timeout=20000);P.wait_for_timeout(1200)
    st=json.loads(P.evaluate(STORED));ok('Confirmando: o armazenamento CRIPTOGRAFADO já tem os dados importados (conferido descriptografando) e a mensagem de sucesso aparece só depois de gravar',st['owner']=='Ana do Backup' and len(st['items'])==5 and 'Backup importado ✓' in P.inner_text('#toast'),P.inner_text('#toast'))
    ok('A criptografia continua a mesma (mesmas chaves e formato do armazenamento protegido)',sorted(json.loads(P.evaluate("localStorage.getItem('wallstreet.sec')")).keys())==sorted(['v','u','it','s','w','ri','rs','r','d']))
    P.reload();login(P);ok('Fechar e reabrir: depois de entrar com a senha os dados importados estão lá',P.evaluate("S.owner")=='Ana do Backup' and len(P.evaluate("S.items"))==5)
    # ===== falhas durante a gravação protegida: reverte =====
    snapS=P.evaluate("JSON.stringify(S)");snapD=P.evaluate("localStorage.getItem('wallstreet.sec')")
    plain2=P.evaluate("(()=>{const o=JSON.parse(JSON.stringify(S));o.owner='Outra Pessoa';o.items=o.items.slice(0,2);o.flags.imp=[];return JSON.stringify(o)})()")
    for lbl,flag in (('falha na criptografia','__ENC_FAIL'),('gravação recusada (armazenamento cheio)','__SET_FAIL'),('gravação que não passa na conferência','__SET_NOOP')):
        t,dlg=imp(P,plain2);P.evaluate(f"{flag}=1");P.click('[data-act=yes]');P.wait_for_timeout(1500);tt=P.inner_text('#toast');P.evaluate(f"{flag}=0")
        ok(f'Importação com {lbl}: é cancelada, os dados atuais (memória e armazenamento criptografado) ficam exatamente como estavam e a mensagem explica',('cancelada' in tt and 'mantidos' in tt) and P.evaluate("JSON.stringify(S)")==snapS and P.evaluate("localStorage.getItem('wallstreet.sec')")==snapD and P.evaluate("IMPBUSY")==0 and P.evaluate("S.owner")=='Ana do Backup',tt)
    t,dlg=imp(P,plain2);P.click('[data-act=yes]');P.wait_for_function("!SAVING&&!SNAP");P.wait_for_timeout(900);ok('Passado o problema, a importação funciona normalmente',P.evaluate("S.owner")=='Outra Pessoa' and json.loads(P.evaluate(STORED))['owner']=='Outra Pessoa')
    # backup criptografado no modo protegido
    t,dlg=imp(P,enc) if False else (None,None)
    P.set_input_files('#file',files=[{'name':'e.json','mimeType':'application/json','buffer':enc.encode()}]);P.wait_for_selector('#f [name=p]');P.fill('#f [name=p]','SenhaBackup1');P.click('#f button[type=submit]');P.wait_for_timeout(3000)
    ok('Backup criptografado importado dentro do modo protegido: confirmação com resumo e importação corretas','Ana do Backup' in P.inner_text('#ov'),P.inner_text('#ov')[:160])
    P.click('[data-act=yes]');P.wait_for_function("!SAVING&&!SNAP");P.wait_for_timeout(900);ok('...e gravada criptografada',json.loads(P.evaluate(STORED))['owner']=='Ana do Backup')
    # duas janelas: janela desatualizada não importa por cima
    B=c.new_page();B.errs=[];B.goto(URL);login(B);P.evaluate("(()=>{S.limits=S.limits||{};S.limits['Casa']=777;commit('x')})()");P.wait_for_function("!SAVING&&!SNAP");B.wait_for_timeout(1200)
    sB=B.evaluate("localStorage.getItem('wallstreet.sec')");t,dlg=imp(B,plain2)
    if dlg and B.locator('[data-act=yes]').count():B.click('[data-act=yes]');B.wait_for_timeout(1200)
    ok('Janela desatualizada (outra janela gravou depois): a importação NÃO sobrescreve os dados mais novos',B.evaluate("localStorage.getItem('wallstreet.sec')")==sB and json.loads(P.evaluate(STORED))['limits'].get('Casa')==777,B.inner_text('#toast')[:120])
    ok('Sem erros no console (modo protegido)',not P.errs and not B.errs,(P.errs+B.errs)[:3]);c.close()
    # ===== tela de boas-vindas ("Já tenho uma conta") =====
    def have(pg):
        pg.goto(URL);pg.wait_for_selector('[data-lk=enter]');pg.wait_for_timeout(500);pg.click('[data-lk=enter]');pg.wait_for_selector('[data-lk=pickbk]')
    def pick(pg,data):
        with pg.expect_file_chooser() as fc:pg.click('[data-lk=pickbk]')
        fc.value.set_files([{'name':'b.json','mimeType':'application/json','buffer':data.encode()}]);pg.wait_for_timeout(1500)
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True);c.add_init_script(INSTR);W=mk(c);have(W)
    for nm,data,snip in (('arquivo vazio','','vazio'),('texto',"nao e json",'corrompido ou incompleto'),('JSON de outro app','{"a":1}','faltam'),('valor inválido',json.dumps({**{k:want[k] for k in want if k!='__backup'},'items':[{**want['items'][0],'c':'x'}]}),'valor inválido'),('versão futura',json.dumps({**{k:want[k] for k in want if k!='__backup'},'v':9}),'versão mais nova')):
        pick(W,data);err=W.inner_text('#le') if W.locator('#le').count() else '';ok(f'Boas-vindas — arquivo inválido ({nm}): mensagem clara na própria tela e nenhuma conta criada',(snip in err) and W.evaluate("localStorage.getItem('wallstreet.v1')")is None and W.evaluate("localStorage.getItem('wallstreet.sec')")is None,err[:140])
        if W.locator('[data-lk=pickbk]').count()==0:have(W)
    pick(W,plain);ok('Boas-vindas — backup comum válido: segue para criar usuário e senha já com os dados do backup',W.locator('#sf').count()==1 and W.evaluate("S.owner")=='Ana do Backup' and len(W.evaluate("S.items"))==5)
    c.close()
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True);c.add_init_script(INSTR);W=mk(c);have(W);pick(W,enc);W.wait_for_selector('#bf')
    W.fill('#bf [name=p]','errada!!');W.click('#bf button:not([type=button])');W.wait_for_timeout(2500);e1=W.inner_text('#le')
    ok('Boas-vindas — backup criptografado com senha errada: "Senha incorreta ou arquivo corrompido" e nada é criado','incorreta' in e1 and W.evaluate("localStorage.getItem('wallstreet.sec')")is None,e1)
    W.fill('#bf [name=p]','SenhaBackup1');W.click('#bf button:not([type=button])');W.wait_for_selector('#sf',timeout=20000)
    ok('Boas-vindas — backup criptografado com a senha certa: segue para criar o acesso com os dados do backup',W.evaluate("S.owner")=='Ana do Backup' and len(W.evaluate("S.items"))==5)
    W.fill('#sf [name=p]',PW);W.fill('#sf [name=c]',PW);W.click('#sf button:not([type=button])');W.wait_for_selector('#skcode',timeout=30000);W.check('#skok');W.click('#skdone');W.wait_for_function("document.getElementById('lock').hidden",timeout=30000);W.wait_for_timeout(1500)
    ok('...e a conta criada abre com todos os dados do backup, protegida por senha',W.evaluate("S.owner")=='Ana do Backup' and len(W.evaluate("S.items"))==5 and W.evaluate("SECMODE"))
    ok('Sem erros no console (boas-vindas)',not W.errs,W.errs[:3]);c.close()
print(sum(R),'/',len(R))
