"""Verificações estáticas e de carregamento: sintaxe do JavaScript (app e Service Worker), HTML, manifesto, ícones, JSON,
versão, tamanho e erros ao abrir o app. Não usa dados do usuário (abre o app em navegador novo e vazio)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,struct,subprocess,shutil
from html.parser import HTMLParser
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html')
# ---------- arquivos essenciais ----------
need=['index.html','sw.js','manifest.webmanifest','icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png','favicon-32.png','favicon-48.png']
ok('Arquivos essenciais do site existem ('+', '.join(need[:3])+'…)',all(os.path.isfile(os.path.join(ROOT,f)) for f in need),[f for f in need if not os.path.isfile(os.path.join(ROOT,f))])
ok('Tamanho do index.html dentro do esperado (< 1,6 MB, o app é um arquivo único)',len(html.encode('utf-8'))<1_600_000,len(html)//1024)
# ---------- HTML ----------
class P(HTMLParser):
    VOID={'meta','link','br','img','input','hr','source','area','base','col','embed','param','track','wbr'}
    def __init__(s):super().__init__();s.stack=[];s.ids={};s.dups=[];s.err=[];s.scripts=[];s._s=None;s.meta={}
    def handle_starttag(s,t,a):
        d=dict(a)
        if 'id' in d:
            if d['id'] in s.ids:s.dups.append(d['id'])
            s.ids[d['id']]=1
        if t=='meta' and d.get('name'):s.meta[d['name']]=d.get('content','')
        if t=='script' and 'src' not in d:s._s=[]
        if t not in s.VOID:s.stack.append(t)
    def handle_startendtag(s,t,a):pass
    def handle_endtag(s,t):
        if t=='script' and s._s is not None:s.scripts.append(''.join(s._s));s._s=None
        if t in s.VOID:return
        if not s.stack or s.stack[-1]!=t:s.err.append(f'</{t}> inesperado (aberto: {s.stack[-1] if s.stack else None})');
        else:s.stack.pop()
    def handle_data(s,d):
        if s._s is not None:s._s.append(d)
p=P();p.feed(html)
ok('HTML: tags equilibradas (cada abertura tem seu fechamento)',not p.err and not p.stack,(p.err[:3],p.stack[:3]))
ok('HTML: nenhum id repetido',not p.dups,p.dups[:5])
ok('HTML: idioma pt-BR, viewport sem bloqueio de zoom e cor do tema definidos','lang="pt-BR"' in html[:200] and 'width=device-width' in html and 'user-scalable' not in html.split('name="viewport"')[1].split('>')[0] and 'theme-color' in p.meta)
ok('HTML: o app registra o Service Worker "sw.js" e liga o manifesto',"serviceWorker.register" in html and 'sw.js' in html and 'rel="manifest"' in html)
ok('Versão (BUILD) no formato "N.N · descrição · dd/mm/aaaa"',bool(re.search(r"BUILD='\d+\.\d+ · [^']+ · \d\d/\d\d/\d{4}'",html)),re.findall(r"BUILD='[^']*'",html)[:1])
ok('Sem sobras de depuração no app (debugger, console.log)','debugger' not in ' '.join(p.scripts) and 'console.log(' not in ' '.join(p.scripts))
# ---------- sintaxe JS ----------
tmp=os.path.join(TMP,'js');os.makedirs(tmp,exist_ok=True)
def check_js(name,code):
    f=os.path.join(tmp,name);open(f,'w',encoding='utf-8').write(code)
    if shutil.which('node'):
        r=subprocess.run(['node','--check',f],capture_output=True,text=True);return r.returncode==0,(r.stderr or '')[:400]
    return None,'node não encontrado'
res=[]
for i,sc in enumerate(p.scripts):
    if sc.strip():res.append((f'index.html <script> nº {i+1} ({len(sc)//1024} KB)',)+check_js(f'inline{i}.js',sc))
res.append(('sw.js',)+check_js('sw.js',rd('sw.js')))
if any(r[1] is None for r in res):   # sem Node: confere a sintaxe no próprio navegador (sem executar)
    with sync_playwright() as pw:
        br=pw.chromium.launch();pg=br.new_page();out=[]
        for nm,_,_ in res:pass
        for (nm,_,_),code in zip(res,[s for s in p.scripts if s.strip()]+[rd('sw.js')]):
            try:pg.evaluate("c=>{new Function(c)}",code);out.append((nm,True,''))
            except Exception as e:out.append((nm,False,str(e)[:300]))
        res=out;br.close()
for nm,good,msg in res:ok(f'Sintaxe JavaScript válida: {nm}',good,msg)
ok('sw.js: usa o prefixo exclusivo "wallstreet::" e só apaga caches próprios (meuCache)','wallstreet::' in rd('sw.js') and 'meuCache(k)' in rd('sw.js'))
# ---------- manifesto, ícones, JSON ----------
m=json.loads(rd('manifest.webmanifest'))
ok('Manifesto: nome, ícones 192/512/maskable, atalhos, standalone, start_url relativo',m['name']=='Wolfin – Controle Financeiro' and m['display']=='standalone' and m['start_url']=='./' and len(m.get('shortcuts',[]))>=3 and {i['sizes'] for i in m['icons']}>={'192x192','512x512'} and any('maskable' in i.get('purpose','') for i in m['icons']))
bad=[]
for i in m['icons']:
    d=open(os.path.join(ROOT,i['src']),'rb').read(24)
    if d[:8]!=b'\x89PNG\r\n\x1a\n' or '%dx%d'%struct.unpack('>II',d[16:24])!=i['sizes']:bad.append(i['src'])
ok('Ícones do manifesto existem, são PNG e têm o tamanho declarado',not bad,bad)
if os.path.isfile(os.path.join(ROOT,'noticias.json')):
    try:j=json.loads(rd('noticias.json'));good=isinstance(j,(dict,list))
    except Exception as e:good=False
    ok('noticias.json é um JSON válido',good)
for fx in ('dados_ficticios.js','legacy_seed.js'):ok(f'Dados de teste existem (fictícios): tests/fixtures/{fx}',os.path.isfile(os.path.join(FIX,fx)))
# ---------- abrir o app sem erros ----------
with sync_playwright() as pw:
    br=pw.chromium.launch()
    for nm,url in (('file://',FILE_URL),('http://',HTTP_URL)):
        c=br.new_context(viewport={'width':393,'height':851},is_mobile=True);pg=c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        pg.goto(url);pg.wait_for_selector('#lock [data-lk=enter]',timeout=15000);pg.wait_for_timeout(600)
        ok(f'Abrir o app ({nm}) em navegador novo: tela de boas-vindas aparece, sem erro de JavaScript nem no console',not errs and pg.title()!='' ,errs[:3]);c.close()
    br.close()
print(sum(R),'/',len(R))
