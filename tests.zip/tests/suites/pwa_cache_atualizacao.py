import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,os,re,json,time,shutil,threading,tempfile,subprocess
pass
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.sync_api import sync_playwright
OUT=ROOT;SITE=ROOT
NEWSW=open(SITE+'/sw.js',encoding='utf-8').read();OLDSW=open(FIX+'/legacy/sw_v2.js',encoding='utf-8').read()
NEWIDX=open(SITE+'/index.html',encoding='utf-8').read();OLDIDX=NEWIDX
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
FLAGS={'delay':0,'fail_install':False};LOG=[]
class H(SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
    def end_headers(self):
        self.send_header('Cache-Control','max-age=3600');super().end_headers()    # como o GitHub Pages: o cache HTTP do navegador pode servir arquivo velho
    def do_GET(self):
        path=self.path.split('?')[0];LOG.append((path,self.headers.get('Pragma'),self.headers.get('Cache-Control')))
        if path.endswith('/index.html') or path.endswith('/wallstreet/'):
            if FLAGS['fail_install'] and self.headers.get('Pragma')=='no-cache':     # pedido da instalação do SW (cache:'reload')
                self.send_response(500);self.send_header('Content-Length','0');self.end_headers();return
            if FLAGS['delay'] and not self.headers.get('Pragma'):time.sleep(FLAGS['delay'])
        super().do_GET()
def mkroot():
    d=tempfile.mkdtemp(prefix='swroot_')
    for sub in ('wallstreet','outro'):os.makedirs(d+'/'+sub)
    for f in os.listdir(SITE):
        if f in('scripts','.github','LEIA-ME.md','tests','.git') or not os.path.isfile(SITE+'/'+f):continue
        shutil.copy(SITE+'/'+f,d+'/wallstreet/'+f)
    open(d+'/outro/index.html','w').write('<!doctype html><title>Outro projeto</title><script>navigator.serviceWorker.register("sw.js");caches.open("outro-projeto-v1").then(c=>c.put("/outro/dado.json",new Response("{\\"x\\":1}")));caches.open("blog-cache-v7").then(c=>c.put("/outro/blog.html",new Response("blog")));caches.open("workbox-precache-v2-http://127.0.0.1/outro/").then(c=>c.put("/outro/p.js",new Response("p")))</script>')
    open(d+'/outro/sw.js','w').write('self.addEventListener("install",e=>self.skipWaiting());self.addEventListener("activate",e=>self.clients.claim());self.addEventListener("fetch",e=>{});')
    open(d+'/outro/dado.json','w').write('{"x":1}')
    return d
def setsw(d,txt):open(d+'/wallstreet/sw.js','w',encoding='utf-8').write(txt)
def setidx(d,txt):open(d+'/wallstreet/index.html','w',encoding='utf-8').write(txt)
srv=None
def serve(d):
    global srv
    if srv:srv.shutdown();srv.server_close()
    srv=ThreadingHTTPServer(('127.0.0.1',PORT2),partial(H,directory=d));threading.Thread(target=srv.serve_forever,daemon=True).start()
BASE=f'http://127.0.0.1:{PORT2}'
CK="(async()=>{const o={};for(const k of await caches.keys()){const c=await caches.open(k);o[k]=(await c.keys()).map(r=>new URL(r.url).pathname)}return o})()"
REG="(async()=>(await navigator.serviceWorker.getRegistrations()).map(r=>new URL(r.scope).pathname).sort())()"
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(offline=False):
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,service_workers='allow',timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1");return c
    def page(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return pg
    def outro(c):
        o=page(c);o.goto(BASE+'/outro/');o.wait_for_function("navigator.serviceWorker.controller||true");o.wait_for_timeout(1500);return o
    def app(c,path='/wallstreet/',create=True):
        pg=page(c);pg.goto(BASE+path)
        if create:
            pg.wait_for_selector('[data-lk=nosec]');pg.wait_for_timeout(400);pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Paul');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(800)
        return pg
    def waitcache(pg,name,gone=None,t=15000):
        end=time.time()+t/1000
        while time.time()<end:
            k=pg.evaluate("caches.keys()")
            if name in k and (not gone or gone not in k):return
            time.sleep(.2)
        raise TimeoutError('cache '+name)
    def ctrl(pg):
        pg.wait_for_function("navigator.serviceWorker.ready.then(()=>true)",timeout=15000)
    FOREIGN=['blog-cache-v7','outro-projeto-v1','workbox-precache-v2-http://127.0.0.1/outro/']
    # ============ A) CONTROLE: o SW antigo apagava os caches dos outros projetos ============
    d=mkroot();setsw(d,OLDSW);setidx(d,OLDIDX);serve(d);c=ctx();pg=app(c);waitcache(pg,'wallstreet-v2');o=outro(c)
    k0=pg.evaluate(CK)
    ok('Controle (versão antiga): antes da atualização os caches dos outros projetos existem ao lado do do Wolfin',all(f in k0 for f in FOREIGN) and 'wallstreet-v2' in k0,list(k0))
    setsw(d,OLDSW.replace("'wallstreet-v2'","'wallstreet-v3'"));pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>r.update())");waitcache(pg,'wallstreet-v3','wallstreet-v2');pg.wait_for_timeout(500)
    k1=pg.evaluate(CK);ok('Controle: uma atualização de rotina do SW antigo APAGAVA os caches dos outros projetos (o defeito relatado fica reproduzido)',not any(f in k1 for f in FOREIGN),list(k1));c.close()
    # ============ B) instalação nova ============
    d=mkroot();setsw(d,NEWSW);setidx(d,NEWIDX);serve(d);c=ctx();o=outro(c);pg=app(c);NAME='wallstreet::/wallstreet/::v3';waitcache(pg,NAME)
    k=pg.evaluate(CK);yp=lambda L:sorted(L)
    ok('Instalação: o cache do app tem identificação exclusiva e organizada ("wallstreet::/wallstreet/::v3") — escopo + versão',NAME in k,list(k))
    ok('O cache guarda o essencial: index.html, a raiz, o manifesto e os ícones',all(x in k[NAME] for x in ['/wallstreet/index.html','/wallstreet/','/wallstreet/manifest.webmanifest','/wallstreet/icon-192.png','/wallstreet/icon-512.png','/wallstreet/apple-touch-icon.png']),k[NAME])
    ok('Os caches dos outros projetos continuam intactos, com todo o conteúdo, depois da instalação',all(f in k for f in FOREIGN) and k['outro-projeto-v1']==['/outro/dado.json'],{f:k.get(f) for f in FOREIGN})
    ok('O registro do app tem o escopo só do app (/wallstreet/) e o do outro projeto continua registrado',pg.evaluate(REG)==['/outro/','/wallstreet/'],pg.evaluate(REG))
    # guarda dado financeiro para checar integridade
    pg.evaluate("(()=>{S.items.push({id:'sw1',t:'inc',d:'Teste SW',c:123400,day:5,fixed:true,from:'2026-11',done:{},cat:'Salário',pay:'Pix'});commit('x')})()");pg.wait_for_timeout(500)
    ls0=pg.evaluate("localStorage.getItem('wallstreet.v1')")
    # ============ C) offline ============
    pg.reload();ctrl(pg);pg.wait_for_timeout(1000);c.set_offline(True)
    pg.reload();pg.wait_for_selector('#s-home',timeout=15000);ok('Offline: o app abre normalmente a partir do cache (reabre sem internet), com os dados',pg.evaluate("S.items.some(i=>i.id==='sw1')") and pg.evaluate("document.title")!='' )
    pg.goto(BASE+'/wallstreet/?atalho=despesa');pg.wait_for_selector('#s-home',timeout=15000);ok('Offline: o atalho do ícone (?atalho=despesa) também abre (cai no index.html guardado)',pg.evaluate("location.search")=='?atalho=despesa')
    r=pg.evaluate("(async()=>{const o={};for(const f of ['manifest.webmanifest','icon-192.png','apple-touch-icon.png','index.html']){try{const x=await fetch(f);o[f]=x.status}catch(e){o[f]='erro'}}return o})()")
    ok('Offline: manifesto, ícones e index.html carregam do cache',all(v==200 for v in r.values()),r)
    r2=pg.evaluate("(async()=>{try{const x=await fetch('/outro/dado.json');return x.status}catch(e){return 'erro'}})()")
    ok('Offline: o SW do app não responde por arquivos de OUTRO projeto (fora do escopo) — nada de outro projeto é servido pelo cache do app',r2=='erro' or r2!=200,r2)
    c.set_offline(False);pg.reload();pg.wait_for_selector('#s-home');k=pg.evaluate(CK)
    ok('Nenhum arquivo de outro projeto entrou no cache do app',all(x.startswith('/wallstreet/') for x in k[NAME]),k[NAME])
    # ============ D) atualização do SW (versão nova → apaga só os caches do app) ============
    pg.evaluate("localStorage.setItem('x_outro_projeto','1')")
    setsw(d,NEWSW.replace("VERSAO = '3'","VERSAO = '4'"));pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>r.update())");NAME4='wallstreet::/wallstreet/::v4';waitcache(pg,NAME4,NAME);pg.evaluate("fetch('index.html')");pg.wait_for_timeout(1500)
    k=pg.evaluate(CK)
    ok('Atualização v3→v4: a versão antiga do cache do app é removida e a nova tem o essencial',NAME not in k and '/wallstreet/index.html' in k[NAME4],list(k))
    ok('...e os caches dos outros projetos continuam intactos (nomes e conteúdo)',all(f in k for f in FOREIGN) and k['blog-cache-v7']==['/outro/blog.html'] and k['outro-projeto-v1']==['/outro/dado.json'],{f:k.get(f) for f in FOREIGN})
    ok('...e o registro do outro projeto continua ativo',pg.evaluate(REG)==['/outro/','/wallstreet/'])
    ok('Os dados financeiros do navegador não mudam com a atualização (nem o que é de outros projetos)',pg.evaluate("localStorage.getItem('wallstreet.v1')")==ls0 and pg.evaluate("localStorage.getItem('x_outro_projeto')")=='1')
    ok('Sem erros no console (instalação, offline e atualização; ignorando o aviso normal de rede desligada)',not [e for e in pg.errs if 'ERR_INTERNET_DISCONNECTED' not in e],pg.errs[:3]);c.close()
    # ============ E) migração: instalação ANTIGA (wallstreet-v2) → nova ============
    d=mkroot();setsw(d,OLDSW);setidx(d,OLDIDX);serve(d);c=ctx();pg=app(c);waitcache(pg,'wallstreet-v2');o=outro(c)
    setsw(d,NEWSW);setidx(d,NEWIDX);pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>r.update())");waitcache(pg,NAME,'wallstreet-v2');pg.evaluate("fetch('index.html')");pg.wait_for_timeout(1500);k=pg.evaluate(CK)
    ok('Quem já tem o app instalado (cache antigo "wallstreet-v2"): a atualização troca pelo novo nome e apaga só o antigo do app',NAME in k and 'wallstreet-v2' not in k,list(k))
    ok('...sem tocar nos caches dos outros projetos e sem tirar o registro deles',all(f in k for f in FOREIGN) and pg.evaluate(REG)==['/outro/','/wallstreet/'])
    c.close()
    # ============ F) nunca mostrar arquivo velho depois de atualizar ============
    BUILDV=lambda t:re.search(r"BUILD='([^']*)'",t).group(1)
    d=mkroot();setsw(d,NEWSW);setidx(d,NEWIDX);serve(d);c=ctx();pg=app(c);waitcache(pg,NAME);pg.reload();ctrl(pg);pg.wait_for_timeout(800)
    novo=NEWIDX.replace(BUILDV(NEWIDX),'9.9 · versão de teste');setidx(d,novo);time.sleep(1.1)
    pg.goto(BASE+'/wallstreet/');pg.wait_for_selector('#s-home');b1=pg.evaluate("BUILD")
    ok('Depois que o arquivo é atualizado no servidor (que manda Cache-Control: max-age=3600), a próxima abertura já mostra a versão NOVA — nada de arquivo velho do cache HTTP',b1.startswith('9.9'),b1)
    c.set_offline(True);pg.reload();pg.wait_for_selector('#s-home');b2=pg.evaluate("BUILD");c.set_offline(False)
    ok('E a cópia guardada para o modo offline também foi atualizada (offline abre a versão nova)',b2.startswith('9.9'),b2);c.close()
    d2=mkroot();setsw(d2,OLDSW);setidx(d2,NEWIDX);serve(d2);c=ctx();pg=app(c);waitcache(pg,'wallstreet-v2');pg.reload();ctrl(pg);pg.wait_for_timeout(800)
    setidx(d2,novo);time.sleep(1.1);pg.goto(BASE+'/wallstreet/');pg.wait_for_selector('#s-home');b0=pg.evaluate("BUILD")
    print('  (controle: SW antigo mostra',b0[:12],'— com cache HTTP de 1 h)',flush=True);c.close()
    # ============ G) falha durante a atualização não deixa o app inutilizável ============
    d=mkroot();setsw(d,NEWSW);setidx(d,NEWIDX);serve(d);c=ctx();o=outro(c);pg=app(c);waitcache(pg,NAME);pg.reload();ctrl(pg);pg.wait_for_timeout(800)
    FLAGS['fail_install']=True;setsw(d,NEWSW.replace("VERSAO = '3'","VERSAO = '5'"));pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>r.update().catch(()=>{}))");pg.wait_for_timeout(4000)
    k=pg.evaluate(CK);FLAGS['fail_install']=False
    ok('Atualização que FALHA (servidor devolve erro no index.html durante a instalação): a nova versão não se instala e não deixa cache pela metade',NAME in k and 'wallstreet::/wallstreet/::v5' not in k,list(k))
    ok('...a versão atual do SW continua ativa e o cache dela íntegro; os caches dos outros projetos intactos',NAME in k and '/wallstreet/index.html' in k[NAME] and all(f in k for f in FOREIGN))
    c.set_offline(True);pg.reload();pg.wait_for_selector('#s-home',timeout=15000);ok('...e o app continua abrindo offline normalmente',True);c.set_offline(False)
    pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>r.update())");waitcache(pg,'wallstreet::/wallstreet/::v5',NAME);pg.evaluate("fetch('index.html')");pg.wait_for_timeout(1500);k=pg.evaluate(CK)
    ok('Passado o problema, a atualização seguinte conclui normalmente e limpa só a versão anterior do app','wallstreet::/wallstreet/::v5' in k and NAME not in k and all(f in k for f in FOREIGN),list(k));c.close()
    # ============ H) rede lenta: usa a cópia guardada ============
    d=mkroot();setsw(d,NEWSW);setidx(d,NEWIDX);serve(d);c=ctx();pg=app(c);waitcache(pg,NAME);pg.reload();ctrl(pg);pg.wait_for_timeout(800)
    FLAGS['delay']=9;t=time.time();pg.goto(BASE+'/wallstreet/',wait_until='domcontentloaded',timeout=30000);pg.wait_for_selector('#s-home',timeout=15000);dt=time.time()-t;FLAGS['delay']=0
    ok('Rede muito lenta (9 s): o app abre em ~6 s com a cópia guardada, em vez de ficar pendurado',5<dt<8.5,round(dt,1));c.close()
    # ============ I) botão "Atualizar agora" do app: só limpa o que é do app ============
    d=mkroot();setsw(d,NEWSW);setidx(d,NEWIDX);serve(d);c=ctx();o=outro(c);pg=app(c);waitcache(pg,NAME);pg.reload();ctrl(pg)
    pg.evaluate("(()=>{S.items.push({id:'sw2',t:'exp',d:'Dado SW',c:5000,day:9,fixed:true,from:'2026-11',done:{},cat:'Casa',pay:'Pix'});commit('x')})()");pg.wait_for_timeout(600);ls=pg.evaluate("localStorage.getItem('wallstreet.v1')")
    pg.evaluate("ACT.updnow()");pg.wait_for_load_state();pg.wait_for_selector('#s-home',timeout=20000);pg.wait_for_timeout(1500);k=pg.evaluate(CK)
    ok('"Atualizar agora": os caches e o registro dos outros projetos continuam (só o app é limpo e refeito)',all(f in k for f in FOREIGN) and '/outro/' in pg.evaluate(REG),(list(k),pg.evaluate(REG)))
    ok('...o app recria o próprio cache e o registro depois de recarregar, e os dados continuam idênticos',NAME in k and '/wallstreet/' in pg.evaluate(REG) and pg.evaluate("localStorage.getItem('wallstreet.v1')")==ls and pg.evaluate("S.items.some(i=>i.id==='sw2')"),pg.evaluate(REG));c.close()
    # ============ J) arquivos de outros projetos fora do escopo ============
    d=mkroot();setsw(d,NEWSW);setidx(d,NEWIDX);serve(d);c=ctx();pg=app(c);waitcache(pg,NAME);pg.reload();ctrl(pg);pg.wait_for_timeout(800)
    pg.evaluate("fetch('/outro/dado.json').then(r=>r.text())");pg.wait_for_timeout(800);k=pg.evaluate(CK)
    ok('Uma requisição da página para outro projeto do mesmo domínio NÃO é interceptada nem guardada no cache do app',not any('/outro/' in x for x in k.get(NAME,[])),k.get(NAME));c.close()
    # ============ K) sintaxe e conteúdo do SW ============
    ok('sw.js tem sintaxe válida e não chama caches.delete em nome genérico (só dentro de meuCache/CACHE)',subprocess.run(['node','--check',SITE+'/sw.js']).returncode==0 and 'caches.delete(k)' in NEWSW and 'meuCache(k)' in NEWSW)
print(sum(R),'/',len(R))
