import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,random,re
pass
from playwright.sync_api import sync_playwright
NEW=FILE_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''))
NOW='2026-11-15T10:00:00-03:00'
def rnd_state(rs):
    cm='2026-11';mo=['2026-08','2026-09','2026-10','2026-11','2026-12','2027-01','2027-02']
    it=[]
    for k in range(rs.randint(0,8)):
        t=rs.choice(['inc','exp','exp']);fx=rs.random()<.7;c=rs.randint(2,120)*1000+rs.choice([0,0,500,990]);day=rs.randint(1,28);fr=rs.choice(mo[:4])
        o={'id':'i%d'%k,'t':t,'d':'Item %d'%k,'c':c,'day':day,'fixed':fx,'cat':'Outros','pay':'Pix','done':{}}
        if fx:o['from']=fr
        else:o['dt']=cm+'-%02d'%day
        if rs.random()<.5:o['done'][cm]=c
        it.append(o)
    de=[]
    for k in range(rs.randint(0,4)):
        o=rs.randint(5,300)*1000;pays=[{'id':'p%d'%j,'c':rs.randint(1,o//2000)*1000,'d':'2026-1%d-05'%rs.randint(0,1)} for j in range(rs.randint(0,2))]
        de.append({'id':'d%d'%k,'n':'Dívida %d'%k,'o':o,'due':rs.choice(['','2026-10-20','2026-12-10']),'pays':pays})
    ins=[{'id':'n1','n':'Celular','c':None,'np':None,'day':5,'paid':False}];pa=[]
    for k in range(rs.randint(0,6)):
        ym=rs.choice(mo);paid=rs.random()<.4
        o={'id':'q%d'%k,'iid':'n1','ym':ym,'c':rs.randint(5,40)*1000,'paid':1 if paid else 0}
        if rs.random()<.4:o['due']=ym+'-%02d'%rs.randint(1,28)
        pa.append(o)
    return {'v':2,'owner':'T','opening':rs.choice([None,{'c':rs.randint(0,600)*1000,'d':'2026-01-01'}]),'limits':{},'ntf':{'read':{}},'pref':{'theme':'light','pal':'perola','av':{'v':2,'m':0,'an':1,'set':0},'ms':'terno','ma':0,'mt':0},'items':it,'inst':ins,'parc':pa,'debts':de,'boxes':[]}
with sync_playwright() as p:
    b=p.chromium.launch()
    def page(url):
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None)
        pg.clock.set_fixed_time(NOW);pg.goto(url);pg.wait_for_selector('[data-lk=nosec]');pg.wait_for_timeout(500);pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','T');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(900);return c,pg
    cn,pn=page(NEW)
    run="(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};const r=finSit();delete r.m.hc;delete r.m.cc;return JSON.stringify({r:r,h:sitCard(),b:balance()})}"
    # ===== A) quem não tem cartões: resultado e tela idênticos à versão anterior =====
    rs=random.Random(20261110);hs=[];N=300
    for i in range(N):
        hs.append(sha(pn.evaluate(run,json.dumps(rnd_state(rs)))))
    ok(f'Sem cartões, o resultado é estável: em {N} cenários aleatórios (receitas, despesas, dívidas e parcelas) o nível, os motivos, os valores e o HTML da seção batem com a referência guardada (golden)',check_golden('situacao_sem_cartoes',hs),'se a mudança foi intencional: WS_UPDATE_GOLDEN=1 python3 tests/suites/calculos_situacao.py')
    ok('Sem erros no console (comparação)',not pn.errs,pn.errs[:2])
    # ===== B) cenários com cartões (só na versão nova) =====
    J=lambda js:pn.evaluate(js)
    BASE="""(()=>{const o=seed();o.owner='T';o.opening={c:300000,d:'2026-01-01'};o.items=[{id:'i1',t:'inc',d:'Salário',c:500000,day:5,fixed:true,from:'2026-01',done:{'2026-11':500000},cat:'Salário',pay:'Pix'},{id:'e1',t:'exp',d:'Aluguel',c:150000,day:10,fixed:true,from:'2026-01',done:{'2026-11':150000},cat:'Casa',pay:'Pix'}];o.flags={tour:1};return o})()"""
    def setup(cards_js,extra=''):
        pn.evaluate(f"(()=>{{S=migrate({BASE});S.cards={cards_js};{extra}}})()")
    def sit():return pn.evaluate("(()=>{const r=finSit();return{level:r.level,m:r.m,flags:r.flags.map(f=>f.code),why:r.why}})()")
    CARD=lambda buys='[]',pays='[]',cl=10,dd=25,id='k1',lim=1000000:"{id:'%s',n:'Cartão %s',lim:%d,cl:%d,dd:%d,buys:%s,pays:%s}"%(id,id,lim,cl,dd,buys,pays)
    BUY=lambda c,dt='2026-10-20',np=1,id='b1':"{id:'%s',d:'Compra',c:%d,dt:'%s',np:%d,cat:'Outros'}"%(id,c,dt,np)
    setup('[]');s0=sit()
    ok('Base sem cartões: situação saudável (receita 5.000, despesa 1.500, saldo 6.500)',s0['level']=='ok' and s0['m']['R']==500000 and s0['m']['Cm']==150000 and s0['m']['bal']==650000,s0['m'])
    # B1 fatura em aberto
    setup(f"[{CARD('['+BUY(180000)+']')}]");s1=sit()
    ok('Fatura em aberto (R$ 1.800 com vencimento neste mês): entra nos compromissos do mês (1.500 → 3.300), no total a pagar e nas despesas do mês',s1['m']['Cm']==330000 and s1['m']['Pun']==180000 and s1['m']['O']==180000 and s1['m']['E']==330000 and s1['m']['Epaid']==150000,s1['m'])
    ok('...e a situação deixa de ser "Saudável": os compromissos (66% da receita) passam a pesar (antes ignorava a fatura)',s1['level']=='est' and 'comp60' in s1['flags'],(s1['level'],s1['flags']))
    # B2 fatura gigante => crítica
    setup(f"[{CARD('['+BUY(450000)+']')}]");s2=sit()
    ok('Fatura de R$ 4.500: compromissos (6.000) passam da receita (5.000) → situação Crítica, com o motivo explicando',s2['level']=='crt' and 'comp100' in s2['flags'] and any('faturas' in w for w in s2['why']),(s2['level'],s2['flags'],s2['why'][:2]))
    # B3 pagamento parcial
    setup(f"[{CARD('['+BUY(180000)+']','[{id:\"p1\",ym:\"2026-11\",c:80000,d:\"2026-11-12\"}]')}]");s3=sit()
    ok('Pagamento parcial de R$ 800: o pendente cai de 1.800 para 1.000 (total a pagar e dívidas), o saldo cai os mesmos 800 e o compromisso do mês continua 3.300 (sem contar duas vezes)',s3['m']['O']==100000 and s3['m']['Pun']==100000 and s3['m']['bal']==s0['m']['bal']-80000 and s3['m']['Cm']==330000 and s3['m']['Epaid']==150000+80000 and s3['m']['E']==330000,(s3['m']['O'],s3['m']['bal'],s3['m']['Cm'],s3['m']['Epaid']))
    ok('Só o pendente (1.000) pesa como dívida; os 800 pagos viraram "despesa paga do mês" e não aparecem de novo como pendência',s3['m']['O']==100000 and s3['m']['Epaid']+ (s3['m']['O']) == s3['m']['E']-150000+150000+0 or s3['m']['E']-s3['m']['Epaid']==100000,(s3['m']['E'],s3['m']['Epaid'],s3['m']['O']))
    # B4 quitada
    setup(f"[{CARD('['+BUY(180000)+']','[{id:\"p1\",ym:\"2026-11\",c:180000,d:\"2026-11-12\"}]')}]");s4=sit()
    ok('Fatura quitada: nada pendente (O = 0), o saldo caiu 1.800 e o mês mostra tudo pago (despesas pagas = 3.300 de 3.300)',s4['m']['O']==0 and s4['m']['Pun']==0 and s4['m']['bal']==s0['m']['bal']-180000 and s4['m']['Epaid']==s4['m']['E']==330000,(s4['m']['O'],s4['m']['bal'],s4['m']['Epaid']))
    ok('Quitada: sem atraso e a avaliação reconhece que não há faturas pendentes',s4['m']['L']==0 and s4['m']['Lc']==0)
    # B5 pagamento maior que a fatura (crédito) nunca deixa pendente negativo
    setup(f"[{CARD('['+BUY(180000)+']','[{id:\"p1\",ym:\"2026-11\",c:250000,d:\"2026-11-12\"}]')}]");s5=sit()
    ok('Pagou a mais que a fatura: o pendente nunca fica negativo (≥ 0) e as despesas pagas do mês não passam do total da fatura',s5['m']['O']>=0 and s5['m']['Pun']>=0 and s5['m']['Epaid']<=s5['m']['E'],(s5['m']['O'],s5['m']['Epaid'],s5['m']['E']))
    # B6 múltiplos cartões
    two=f"[{CARD('['+BUY(100000,id='a1')+']','[]',id='k1')},{CARD('['+BUY(60000,id='b1')+','+BUY(40000,dt='2026-11-12',id='b2')+']','[{id:\"q1\",ym:\"2026-11\",c:20000,d:\"2026-11-10\"}]',id='k2')}]"
    setup(two);s6=sit()
    ok('Dois cartões: soma as faturas dos dois (1.000 + 600 = 1.600 no mês) e abate o pagamento parcial só do cartão certo; futuro de dezembro (compra de 12/11, após o fechamento do dia 10) entra nos meses seguintes',s6['m']['E']-150000==160000 and s6['m']['Pun']==100000+60000+40000-20000 and s6['m']['Pf']==40000,(s6['m']['E'],s6['m']['Pun'],s6['m']['Pf']))
    # B7 atraso (fatura vencida e não paga)
    setup(f"[{CARD('['+BUY(120000,'2026-09-20')+']','[]',cl=10,dd=5)}]");s7=sit()
    ok('Fatura vencida e não paga (venceu em 05/11): conta como atraso (R$ 1.200, 1 item), aparece no motivo e pesa na situação',s7['m']['L']==120000 and s7['m']['Lc']==1 and ('atraso' in s7['flags'] or 'atraso50' in s7['flags']) and s7['level']!='ok',(s7['m']['L'],s7['m']['Lc'],s7['flags'],s7['level']))
    setup(f"[{CARD('['+BUY(120000,'2026-09-20')+']','[{id:\"p1\",ym:\"2026-10\",c:120000,d:\"2026-11-12\"}]',cl=10,dd=5)}]");s7b=sit()
    ok('Pagando a fatura atrasada o atraso some',s7b['m']['L']==0 and s7b['m']['Lc']==0,(s7b['m']['L'],s7b['m']['Lc']))
    # B8 parcelas futuras no cartão
    setup(f"[{CARD('['+BUY(300000,'2026-10-20',6)+']')}]");s8=sit()
    ok('Compra de R$ 3.000 em 6x no cartão: 500 pesam este mês e os 2.500 restantes entram como "a pagar nos próximos meses" (total pendente 3.000)',s8['m']['E']-150000==50000 and s8['m']['Pun']==300000 and s8['m']['Pf']==250000,(s8['m']['E'],s8['m']['Pun'],s8['m']['Pf']))
    # B9 compatibilidade e pureza
    setup('[]','delete S.cards;');s9=sit();ok('Dados antigos (sem a lista de cartões) funcionam normalmente e dão o mesmo resultado da base',s9['level']==s0['level'] and s9['m']['Cm']==s0['m']['Cm'] and s9['m']['O']==0)
    setup(f"[{CARD('['+BUY(180000)+']','[{id:\"p1\",ym:\"2026-11\",c:80000,d:\"2026-11-12\"}]')}]")
    same=pn.evaluate("(()=>{const a=JSON.stringify(S);finSit();sitCard();ccFin(todayStr());return JSON.stringify(S)===a})()")
    ok('A avaliação só lê: calcular a situação não altera nenhum dado (receitas, despesas, dívidas, cartões, pagamentos)',same)
    # B10 coerência entre telas
    setup(two)
    t=pn.evaluate("""(()=>{const r=finSit(),m=r.m,sc=document.createElement('div');sc.innerHTML=sitCard();const kv={};sc.querySelectorAll('.fk').forEach(e=>kv[e.children[0].textContent]=e.children[1].textContent);
      const owed=(S.cards||[]).reduce((a,k)=>a+ccOwed(k),0),home=(go('home'),document.querySelector('#s-home .hero').innerText);return{bal:balance(),mbal:m.bal,kvbal:kv['Saldo disponível'],kvparc:kv['Parcelas e faturas a pagar'],owed,cc:m.cc.owed,pun:m.Pun,kvdeb:kv['Dívidas pendentes'],debts:brl(S.debts.reduce((a,x)=>a+balOf(x),0)),homebal:home,brlbal:brl(balance()),labels:Object.keys(kv)}})()""")
    ok('Coerência entre telas: o saldo da Situação = saldo da Home = balance(); o total pendente dos cartões na Situação = soma do "usado" da tela Cartões; "Dívidas pendentes" continua só com as dívidas',t['bal']==t['mbal'] and t['kvbal']==t['brlbal'] and t['brlbal'] in t['homebal'] and t['owed']==t['cc'] and t['pun']==t['cc'] and t['kvdeb']==t['debts'],t)
    ok('Com cartões, o rótulo passa a "Parcelas e faturas a pagar" (sem cartões continua "Parcelas a pagar"); nenhum outro texto ou elemento da seção muda','Parcelas e faturas a pagar' in t['labels'] and len(t['labels'])==8,t['labels'])
    # B11 relatórios: pagamento de fatura aparece nas saídas pagas do mês (mesma regra do saldo)
    setup(f"[{CARD('['+BUY(180000)+']','[{id:\"p1\",ym:\"2026-11\",c:80000,d:\"2026-11-12\"}]')}]")
    fl=pn.evaluate("(()=>{const f=flows()['2026-11'];return{exp:f.exp,expected:150000+80000,bal:balance(),opening:300000+500000-f.exp}})()")
    ok('Relatórios/saldo: o pagamento da fatura entra nas despesas pagas do mês (1.500 + 800) e é a mesma conta do saldo disponível',fl['exp']==fl['expected'] and fl['bal']==fl['opening'],fl)
    # B12 texto de ajuda
    h=pn.evaluate("(setup=>{S=migrate("+BASE+");S.cards=[{id:'k1',n:'N',lim:1,cl:10,dd:25,buys:[{id:'b',d:'x',c:100,dt:'2026-10-20',np:1,cat:''}],pays:[]}];return sitCard()})()")
    ok('O "Como a avaliação é feita" explica que as faturas entram pelo valor pendente e não são contadas duas vezes (só para quem tem cartões)','não são contados duas vezes' in h)
    ok('Sem erros no console (cenários com cartões)',not pn.errs,pn.errs)
print(sum(R),'/',len(R))
