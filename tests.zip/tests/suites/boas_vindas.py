import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json
os.environ['NOSKIP']='1'
from playwright.sync_api import sync_playwright
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:170] if d else ''))
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(**k):
        c=b.new_context(viewport={'width':393,'height':851},device_scale_factor=2.75,is_mobile=True,has_touch=True,**k);pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return c,pg
    hid=lambda pg:pg.evaluate("document.getElementById('lock').hidden")
    ls=lambda pg:pg.evaluate("Object.keys(localStorage).map(k=>k+'='+localStorage.getItem(k)).join('\\n')")
    # ===== S1: primeira abertura =====
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=new]')
    t=pg.inner_text('#lock')
    ok('Primeira abertura: boas-vindas com nome WALL STREET, slogan e 3 opções','Boas-vindas' in t and 'WALL STREET' in t and 'Seu dinheiro, sob controle.' in t and 'Criar minha conta' in t and 'Já tenho uma conta' in t and 'Usar sem senha por enquanto' in t,t[:160])
    ok('Lobo 2D na tela de boas-vindas',pg.locator('#lock .wolf').count()==1 and pg.locator('#lock .mq').count()==0)
    ok('Nada é gravado antes de concluir (sem dados salvos)',pg.evaluate("localStorage.getItem('wallstreet.v1')")is None and pg.evaluate("localStorage.getItem('wallstreet.welcomed')")is None)
    pg.reload();pg.wait_for_selector('[data-lk=new]');ok('Recarregar no meio das boas-vindas: volta ao começo (nada ficou pela metade)',pg.locator('#lock [data-lk=have]').count()==1)
    for w,h in ((393,851),(320,568),(851,393)):
        pg.set_viewport_size({'width':w,'height':h});pg.wait_for_timeout(100)
        r=pg.evaluate("({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth||document.getElementById('lock').scrollWidth>document.getElementById('lock').clientWidth,minb:Math.min(...[...document.querySelectorAll('#lock button')].map(b=>b.getBoundingClientRect().height))})")
        ok(f'Boas-vindas {w}x{h}: sem rolagem lateral e botões ≥ 40px',not r['ov'] and r['minb']>=40,r)
    pg.set_viewport_size({'width':393,'height':851});pg.click('[data-lk=have]');ok('"Já tenho uma conta" explica que é preciso importar o backup',pg.locator('[data-lk=pickbk]').count()==1 and 'backup' in pg.inner_text('#lock'));pg.click('[data-lk=back0]');ok('Voltar leva às boas-vindas',pg.locator('[data-lk=new]').count()==1)
    ok('Sem erros no console (boas-vindas)',not pg.errs,pg.errs);c.close()
    # ===== S2: criar conta =====
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=new]')
    ok('Criar conta: primeiro pergunta o nome',pg.locator('#nf').count()==1 and 'Como podemos te chamar?' in pg.inner_text('#lock'))
    pg.click('#nf button');ok('Nome vazio recusado',pg.inner_text('#le')=='Digite seu nome.')
    pg.evaluate("document.querySelector('#nf [name=n]').removeAttribute('maxlength')");pg.fill('#nf [name=n]','A'*31);pg.click('#nf button');ok('Nome com mais de 30 caracteres recusado','no máximo 30' in pg.inner_text('#le'))
    pg.fill('#nf [name=n]','  Ana    Maria  ');pg.click('#nf button');pg.wait_for_selector('#mf');pg.click('#mf .b1');pg.wait_for_selector('#cf');pg.click('#cf button:not([type=button])');pg.wait_for_selector('#sf')
    ok('Nome normalizado ("Ana Maria") e tela "Crie seu acesso" com usuário sugerido "ana"','Crie seu acesso' in pg.inner_text('#lock') and pg.input_value('#sf [name=u]')=='ana' and pg.evaluate('S.owner')=='Ana Maria')
    pg.click('[data-lk=backcolor]');pg.wait_for_selector('#cf');pg.click('[data-lk=backmasc]');pg.wait_for_selector('#mf');pg.click('[data-lk=backname]');ok('Voltar mantém o nome digitado',pg.input_value('#nf [name=n]')=='Ana Maria');pg.click('#nf button');pg.wait_for_selector('#mf');pg.click('#mf .b1');pg.wait_for_selector('#cf');pg.click('#cf button:not([type=button])');pg.wait_for_selector('#sf')
    pg.fill('#sf [name=p]','curta');pg.fill('#sf [name=c]','curta');pg.click('#sf button:not([type=button])');ok('Senha curta recusada','8 caracteres' in pg.inner_text('#le'))
    pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','outra');pg.click('#sf button:not([type=button])');ok('Senhas diferentes recusadas','não conferem' in pg.inner_text('#le'))
    pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=15000)
    ok('Mostra o código de recuperação (uma vez) e ainda não gravou nada',re.fullmatch(r'([A-HJ-NP-Z2-9]{4}-){4}[A-HJ-NP-Z2-9]{4}',pg.inner_text('#skcode')) is not None and pg.evaluate("localStorage.getItem('wallstreet.sec')")is None)
    pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    ok('Conta criada: app abre, nome "Ana Maria", proteção ativa, boas-vindas marcadas como feitas',pg.evaluate("S.owner")=='Ana Maria' and pg.evaluate("SECMODE&&!!DEK") and pg.evaluate("localStorage.getItem('wallstreet.welcomed')")=='1' and 'Conta criada' in pg.inner_text('#toast'),pg.inner_text('#toast'))
    pg.wait_for_timeout(400);ok('Dados cifrados: nenhum nome legível no armazenamento',pg.evaluate("localStorage.getItem('wallstreet.v1')")is None and 'Ana Maria' not in ls(pg))
    pg.reload();pg.wait_for_selector('#lf');ok('Ao reabrir: vai direto para o login (não repete boas-vindas) com usuário preenchido',pg.input_value('#lf [name=u]')=='ana' and pg.locator('[data-lk=new]').count()==0)
    pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);ok('Login funciona e o nome persistiu',pg.evaluate('S.owner')=='Ana Maria')
    ok('Sem erros no console (criar conta)',not pg.errs,pg.errs);c.close()
    # ===== nome com HTML =====
    c,pg=ctx();pg.on('dialog',lambda d:(pg.errs.append('DIALOG'),d.dismiss()));pg.goto(URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','<img src=x onerror=alert(1)>');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(300)
    ok('Nome com HTML/script é mostrado como texto (sem executar nada)',pg.locator('#s-home img[src=x]').count()==0 and 'DIALOG' not in pg.errs and '<img' in pg.inner_text('#s-home .hello')+pg.evaluate('S.owner'));c.close()
    # ===== S3: sem senha =====
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.wait_for_selector('#nf');ok('"Usar sem senha": também pergunta o nome (botão "Começar")','Começar' in pg.inner_text('#nf'))
    pg.fill('#nf [name=n]','Bia');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden")
    ok('Sem senha: app abre em branco com o nome "Bia" e dados salvos neste aparelho',pg.evaluate('S.owner')=='Bia' and pg.evaluate('S.items.length')==0 and pg.evaluate("localStorage.getItem('wallstreet.v1')")is not None and not pg.evaluate('SECMODE'))
    pg.reload();pg.wait_for_timeout(400);ok('Reabrir: sem boas-vindas e sem nova oferta de senha',hid(pg) and pg.evaluate('S.owner')=='Bia')
    pg.click('#nav button[data-id=cfg]');ok('Dá para ativar a proteção depois, em Ajustes',pg.locator('#s-cfg [data-act=secon]').count()==1);c.close()
    # ===== S4: já tenho conta (backup) =====
    c0,p0=ctx();p0.goto(URL);p0.wait_for_selector('[data-lk=nosec]');p0.click('[data-lk=nosec]');p0.fill('#nf [name=n]','Carla Souza');p0.click('#nf button');p0.wait_for_function("document.getElementById('lock').hidden")
    p0.evaluate("""(()=>{const cm=vm;S.items.push({id:'i1',t:'inc',d:'Salário Carla',c:250000,day:5,cat:'Salário',pay:'Pix',fixed:true,from:cm,done:{}});S.debts.push({id:'d1',n:'Cartão X',o:98765,due:'',pays:[]});S.boxes.push({id:'b1',n:'Viagem',g:500000,m:null,dl:'',moves:[]});S.pref.theme='dark';save()})()""")
    plain=p0.evaluate('JSON.stringify(S)');open(TMP+'/bk_w_plain.json','w').write(plain)
    encs=p0.evaluate("""(async()=>{const salt=rnd(16),sl=await seal(await kdf(np('Backup-Pw-456'),salt,600000),enc.encode(JSON.stringify(S)));return JSON.stringify({app:'wallstreet-backup',enc:true,v:1,at:todayStr(),it:600000,s:b64(salt),iv:sl.iv,ct:sl.ct})})()""");open(TMP+'/bk_w_enc.json','w').write(encs);c0.close()
    open(TMP+'/bk_w_txt.json','w').write('isto nao e json');open(TMP+'/bk_w_bad.json','w').write(json.dumps({'owner':'x','items':'nao'}))
    e=json.loads(encs);e['it']=5;open(TMP+'/bk_w_t1.json','w').write(json.dumps(e))
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=have]');pg.click('[data-lk=have]')
    def pick(path):
        pg.click('[data-lk=pickbk]');pg.set_input_files('#file',path);pg.wait_for_timeout(400)
    pick(TMP+'/bk_w_txt.json');ok('Arquivo que não é JSON: mensagem na própria tela e continua nela','corrompido ou incompleto' in pg.inner_text('#lock') and pg.locator('[data-lk=pickbk]').count()==1)
    pick(TMP+'/bk_w_bad.json');ok('Arquivo que não é backup: recusado','não é um backup do WALL STREET' in pg.inner_text('#lock'))
    pick(TMP+'/bk_w_t1.json');ok('Backup criptografado danificado (parâmetro fraco): recusado','danificado' in pg.inner_text('#lock'))
    pick(TMP+'/bk_w_plain.json');pg.wait_for_selector('#sf',timeout=15000)
    ok('Backup válido: restaura e pergunta se quer proteger (título "Proteger seus dados?", usuário sugerido "carla")','Proteger seus dados?' in pg.inner_text('#lock') and pg.input_value('#sf [name=u]')=='carla' and pg.evaluate('S.owner')=='Carla Souza')
    ok('Ainda não gravou nada (decisão pendente)',pg.evaluate("localStorage.getItem('wallstreet.v1')")is None)
    pg.click('[data-lk=skip]');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(300)
    s=pg.evaluate('JSON.parse(JSON.stringify(S))')
    ok('"Agora não": dados restaurados (receita, dívida, caixinha, tema escuro) e salvos neste aparelho',[i['d'] for i in s['items']]==['Salário Carla'] and s['debts'][0]['o']==98765 and s['boxes'][0]['n']=='Viagem' and s['pref']['theme']=='dark' and pg.evaluate("localStorage.getItem('wallstreet.v1')")is not None)
    ok('Backup restaurado conta como backup de hoje (lembrete zerado)',bool(s['flags'].get('bkpAt')));c.close()
    # protegendo após importar
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=have]');pg.click('[data-lk=have]');pick(TMP+'/bk_w_plain.json');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=15000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    pg.wait_for_timeout(400);ok('Importar + criar proteção: dados protegidos e nada legível no armazenamento','Carla' not in ls(pg) and 'Cartão X' not in ls(pg) and pg.evaluate("SECMODE"))
    pg.reload();pg.wait_for_selector('#lf');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);ok('Depois de reabrir e entrar, os dados importados estão lá',pg.evaluate("S.debts.length")==1 and pg.evaluate("S.owner")=='Carla Souza');c.close()
    # backup criptografado
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=have]');pg.click('[data-lk=have]');pick(TMP+'/bk_w_enc.json');pg.wait_for_selector('#bf');ok('Backup criptografado: pede a senha do backup','Senha do backup' in pg.inner_text('#lock'))
    pg.fill('#bf [name=p]','errada-1234');pg.click('#bf button:not([type=button])');pg.wait_for_function("document.getElementById('le')&&document.getElementById('le').textContent.length>0",timeout=15000);ok('Senha do backup errada: mensagem e nada é restaurado','Senha incorreta' in pg.inner_text('#lock') and pg.evaluate('S.items.length')==0)
    pg.fill('#bf [name=p]','Backup-Pw-456');pg.click('#bf button:not([type=button])');pg.wait_for_selector('#sf',timeout=15000);ok('Senha certa: restaura e oferece proteção',pg.evaluate('S.owner')=='Carla Souza' and pg.evaluate('S.boxes.length')==1)
    pg.click('[data-lk=skip]');pg.wait_for_function("document.getElementById('lock').hidden");ok('Concluído: app aberto com os dados do backup criptografado',pg.evaluate("S.items[0].d")=='Salário Carla')
    ok('Sem erros no console (importar)',not pg.errs,pg.errs);c.close()
print(sum(R),'/',len(R))
