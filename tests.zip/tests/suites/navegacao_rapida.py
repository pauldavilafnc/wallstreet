import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re
from playwright.sync_api import sync_playwright
URL=FILE_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:170] if d else ''))
with sync_playwright() as p:
    b=p.chromium.launch()
    for scheme in ('light','dark'):
        ctx=b.new_context(viewport={'width':393,'height':851},device_scale_factor=2.75,is_mobile=True,has_touch=True,color_scheme=scheme);pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None);pg.goto(URL);pg.wait_for_selector('#nav button');pg.wait_for_timeout(900)
        if pg.evaluate("!document.getElementById('lock').hidden") and pg.locator('#mf').count():
            OB_NOSEC(pg,'Paul')
        pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000)
        if pg.evaluate("S.items.length===0&&S.debts.length===0&&S.boxes.length===0&&S.inst.length===0"):
            pg.evaluate("(()=>{"+open(FIX+'/legacy_seed.js',encoding='utf-8').read()+";const o=legacySeed();o.pref=S.pref;o.owner=S.owner;S=o;migrate(S);S.pref.ma=0;S.pref.ms='terno';save();render()})()")
        pg.wait_for_timeout(1500)
        if scheme=='dark': pg.evaluate("S.pref.theme='dark';save();render()")
        btn=pg.locator('#nav button');ok(f'[{scheme}] 7 botões, cada um com ícone SVG (sem setas/símbolos de texto)',btn.count()==7 and pg.locator('#nav button svg').count()==7 and pg.locator('#nav button span').count()==0)
        labels=pg.evaluate("[...document.querySelectorAll('#nav button')].map(b=>b.innerText.trim())");ok(f'[{scheme}] Rótulos mantidos',labels==['Home','Receitas','Despesas','Dívidas','Caixinhas','Relat.','Ajustes'],labels)
        paths=pg.evaluate("[...document.querySelectorAll('#nav button svg')].map(s=>[...s.querySelectorAll('path,rect,circle')].map(e=>e.outerHTML).join(''))");ok(f'[{scheme}] 7 ícones distintos',len(set(paths))==7)
        pg.wait_for_timeout(1500)
        st=pg.evaluate("[...document.querySelectorAll('#nav button svg')].map(s=>{const c=getComputedStyle(s);return [c.fill,c.strokeLinecap,c.strokeLinejoin,parseFloat(c.strokeWidth)>=1.8,Math.round(s.getBoundingClientRect().width)]})")
        ok(f'[{scheme}] Estilo único: só contorno, pontas arredondadas, mesma espessura e tamanho',all(x[0]=='none' and x[1]=='round' and x[2]=='round' and x[3] and x[4]==25 for x in st),st[:2])
        ok(f'[{scheme}] Cor segue o tema (cinza; azul no ativo)',pg.evaluate("getComputedStyle(document.querySelector('#nav button:not(.on) svg')).stroke")!=pg.evaluate("getComputedStyle(document.querySelector('#nav button.on svg')).stroke"))
        ok(f'[{scheme}] Botão ativo destaca (traço mais grosso e leve preenchimento)',pg.evaluate("parseFloat(getComputedStyle(document.querySelector('#nav button.on svg')).strokeWidth)")>pg.evaluate("parseFloat(getComputedStyle(document.querySelector('#nav button:not(.on) svg')).strokeWidth)") and float(pg.evaluate("getComputedStyle(document.querySelector('#nav button.on svg .fl')).fillOpacity"))>0)
        ok(f'[{scheme}] Alvos de toque ≥ 48px e sem estourar a largura',pg.evaluate("[...document.querySelectorAll('#nav button')].every(b=>b.getBoundingClientRect().height>=48&&b.getBoundingClientRect().width>=40)") and pg.evaluate("document.getElementById('nav').scrollWidth<=document.getElementById('nav').clientWidth"))
        for v in ['rec','des','div','cx','rel','cfg','home']:
            pg.click(f'#nav button[data-id={v}]')
        ok(f'[{scheme}] Navegação continua funcionando em todas as abas e destaca a atual',pg.evaluate("document.querySelector('#nav button.on').dataset.id")=='home' and not pg.evaluate("document.querySelectorAll('#nav button.on').length>1"))
        pg.screenshot(path=f'{TMP}/shots/nav_{scheme}.png',clip={'x':0,'y':851-70,'width':393,'height':70})
        ok(f'[{scheme}] Sem erros no console',not errs,errs);ctx.close()
    ctx=b.new_context(viewport={'width':1280,'height':800});pg=ctx.new_page();pg.goto(URL);pg.wait_for_selector('#nav button');ok('Desktop: barra lateral com os mesmos ícones',pg.locator('#nav button svg').count()==7 and pg.evaluate("getComputedStyle(document.getElementById('nav')).flexDirection")=='column');ctx.close()
    ctx=b.new_context(viewport={'width':320,'height':568},is_mobile=True,has_touch=True);pg=ctx.new_page();pg.goto(URL);pg.wait_for_selector('#nav button');ok('Tela de 320px: rótulos e ícones cabem sem rolagem',pg.evaluate("document.getElementById('nav').scrollWidth<=document.getElementById('nav').clientWidth")and pg.evaluate("[...document.querySelectorAll('#nav button')].every(b=>b.scrollWidth<=b.clientWidth+1)"));ctx.close()
print(sum(R),'/',len(R))
