"""Mascotes oficiais do Wolfin (10 personagens) = avatares. Estrutura, criação de conta, Ajustes → Meu mascote, avatar único em todo o app,
migração de contas/backups antigos (sem perda de dados), animações individuais, tema claro/escuro, telas pequenas, offline e console limpo."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
EXP=[('wolfin','Wolfin','Lobo','CEO'),('leonidas','Leônidas','Leão','Rei'),('vito','Don Vito','Raposa','Magnata'),('oraculo','Oráculo','Coruja','Analista'),('brutus','Brutus','Touro','Investidor'),('mako','Mako','Tubarão','Negociador'),('bento','Bento','Castor','Planejador'),('penny','Penny','Esquilo','Poupador'),('nyx','Nyx','Pantera','Hacker'),('elliot','Elliot','Guaxinim','Detetive')]
IDS=[e[0] for e in EXP]
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th=None,reduce=False,state=None,sw=False):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=w<600,timezone_id='America/Sao_Paulo',reduced_motion='reduce' if reduce else 'no-preference',storage_state=state,service_workers='allow' if sw else 'block');c.add_init_script("window.__WS_NOTOUR=1")
        return c
    def page(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None);return pg
    def newapp(w=393,h=851,th='light',reduce=False):
        c=ctx(w,h,reduce=reduce);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Teste');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden",timeout=10000)
        pg.evaluate(f"S.pref.theme='{th}';S.flags={{tour:1}};save();render()");pg.wait_for_timeout(300);return c,pg
    ev=lambda pg,js,*a:pg.evaluate(js,*a) if a else pg.evaluate(js)
    # ===== A) estrutura dos 10 mascotes =====
    c,pg=newapp()
    r=ev(pg,"(()=>MC.map(m=>[m.id,m.n,m.a,m.t,!!m.d,!!m.main,m.e.length]))()")
    ok('Exatamente 10 mascotes oficiais, com os nomes, animais e funções definidos (Wolfin primeiro, como mascote principal)',[x[:4] for x in r]==[list(e) for e in EXP] and [x[5] for x in r]==[True]+[False]*9 and all(x[4] for x in r),r)
    r=ev(pg,"""async()=>{const out=[];for(const m of MC){const im=new Image();im.src=mcUrl(m.id);await im.decode();out.push([m.id,im.naturalWidth,im.naturalHeight,MCB[m.id].length])}return out}""")
    ok('As 10 imagens são WebP válidas (PNG originais convertidos, 544 px de largura) e leves (< 80 KB cada)',all(x[1]==544 and x[2]>400 and x[3]<108000 for x in r),r)
    ok('Mascotes e avatares antigos foram removidos do código: nada de avatares independentes, roupas do lobo, imagens antigas ou troca automática',ev(pg,"typeof avSvg==='undefined'&&typeof AVN==='undefined'&&typeof AVD==='undefined'&&typeof SKB==='undefined'&&typeof SKN==='undefined'&&typeof SKIDS==='undefined'&&typeof WOLFB==='undefined'&&typeof WU==='undefined'&&typeof skCfgCard==='undefined'&&typeof avSheet==='undefined'"))
    ok('Padrão de uma conta nova: mascote Wolfin (sem obrigar) e o seed já traz mc="wolfin"',ev(pg,"S.pref.mc")=='wolfin' and ev(pg,"seed().pref.mc")=='wolfin')
    sk=ev(pg,"MCIDS.map(i=>[i,Object.keys(SKV[i]||{}).sort().join(',')])")
    ok('Cada personagem tem falas próprias (gen, tap, late, neg, debt, goal, okall, empty) para o balão da Home',all(x[1]=='debt,empty,gen,goal,late,neg,okall,tap' or (x[0] in('wolfin',) and 'gen' in x[1] and 'tap' in x[1]) or x[1].startswith('debt') for x in sk) and len(sk)==10,sk)
    # ===== B) Home: avatar do cabeçalho e cartão do mascote usam o MESMO personagem =====
    res=[]
    for i in IDS:
        ev(pg,f"S.pref.mc='{i}';render()");pg.wait_for_timeout(60)
        h=ev(pg,"""(()=>{const a=document.querySelector('#avh .mcav img'),m=document.querySelector('#s-home .mqc .mc');return {av:a&&a.src,mc:m&&m.dataset.mc,u:mcUrl(mcCur()),cur:mcCur(),lbl:document.getElementById('avh').getAttribute('aria-label')}})()""")
        res.append((i,h['av']==h['u'] and h['mc']==i and h['cur']==i))
    ok('Home: o avatar do cabeçalho e o mascote do cartão são sempre o personagem escolhido (mesma imagem), para os 10',all(x[1] for x in res),res)
    ev(pg,"S.pref.mc='nyx';render()");pg.wait_for_timeout(100)
    ok('O avatar é um recorte do rosto da MESMA imagem do mascote (nenhuma imagem de avatar separada) e tem 44 px (alvo de toque)',ev(pg,"(()=>{const i=document.querySelector('#avh .mcav img');const r=document.getElementById('avh').getBoundingClientRect();return i.src===mcUrl('nyx')&&r.width>=44&&r.height>=44&&document.querySelectorAll('img').length>0})()"))
    t=ev(pg,"(()=>[...new Set(MCIDS.map(i=>{S.pref.mc=i;return mqSay()[1]}))].length)()")
    ok('O balão da Home fala com a personalidade do mascote (frases diferentes por personagem)',t>=4,t)
    ev(pg,"S.pref.mc='wolfin'");c.close()
    # ===== C) criação de conta: etapa de escolha =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=new]');pg.fill('#nf [name=n]','Teste');pg.click('#nf button');pg.wait_for_selector('#mf',timeout=8000);pg.wait_for_timeout(500)
    rows=ev(pg,"[...document.querySelectorAll('#mf .mcrow')].map(r=>({id:r.dataset.id,nome:r.querySelector('b').firstChild.textContent,sub:r.querySelector('small').textContent,desc:r.querySelector('.mcd').textContent,img:!!r.querySelector('.mcav img'),on:r.classList.contains('on'),badge:!!r.querySelector('em'),h:r.getBoundingClientRect().height}))")
    ok('Etapa do mascote na criação da conta: 10 opções, cada uma com imagem, nome, "animal · função" e descrição curta',len(rows)==10 and all(x['img'] and x['nome'] and ' · ' in x['sub'] and len(x['desc'])>=20 for x in rows) and [x['id'] for x in rows]==IDS and [x['nome'] for x in rows]==[e[1] for e in EXP] and [x['sub'] for x in rows]==[f'{e[2]} · {e[3]}' for e in EXP],rows[:2])
    ok('O Wolfin aparece primeiro e identificado como "Principal", mas não é obrigatório (todos são selecionáveis)',rows[0]['id']=='wolfin' and rows[0]['badge'] and sum(x['badge'] for x in rows)==1 and rows[0]['on'] and sum(x['on'] for x in rows)==1)
    ok('Destaque elegante do selecionado (borda azul + marca ✓) e linhas compactas (≤ 110 px)',ev(pg,"(()=>{const s=getComputedStyle(document.querySelector('#mf .mcrow.on'));return s.borderTopWidth==='2px'&&getComputedStyle(document.querySelector('#mf .mcrow.on .mcck')).opacity==='1'})()") and max(x['h'] for x in rows)<=110,max(x['h'] for x in rows))
    sel=[]
    for i in IDS:
        pg.click(f'#mf .mcrow[data-id={i}]');pg.wait_for_timeout(120)
        s=ev(pg,"""()=>({pref:S.pref.mc,prev:document.querySelector('#lock .wolf').dataset.mc,on:[...document.querySelectorAll('#mf .mcrow.on')].map(x=>x.dataset.id),aria:[...document.querySelectorAll('#mf .mcrow[aria-checked=true]')].length,look:JSON.parse(localStorage.getItem('wallstreet.look')||'{}').m,name:document.getElementById('mname').textContent})""")
        sel.append((i,s['pref']==i and s['prev']==i and s['on']==[i] and s['aria']==1 and s['look']==i))
    ok('Escolher cada um dos 10: a prévia animada, a seleção, o texto, a conta (S.pref.mc) e a aparência do login são atualizados na hora',all(x[1] for x in sel),sel)
    # escolhe a Nyx e conclui a criação (com senha) para testar persistência
    pg.click('#mf .mcrow[data-id=nyx]');pg.wait_for_timeout(150);pg.click('#mf button.b1')
    for _ in range(3):
        pg.wait_for_timeout(400)
        if pg.locator('#cf').count():pg.click('#cf button:not([type=button])')
        elif pg.locator('#sf').count():break
    pg.wait_for_selector('#sf',timeout=8000);pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(900)
    ok('Conta criada com a Nyx: o mascote e o avatar são a Nyx no app',ev(pg,"S.pref.mc")=='nyx' and ev(pg,"document.querySelector('#avh .mcav img').src===mcUrl('nyx')") and ev(pg,"document.querySelector('#s-home .mqc .mc').dataset.mc")=='nyx')
    ok('Aparência do login guardada para o mascote escolhido',ev(pg,"JSON.parse(localStorage.getItem('wallstreet.look')).m")=='nyx')
    st=c.storage_state();pg.wait_for_timeout(2500);c.close()
    c2=ctx(state=st);pg=page(c2);pg.goto(HTTP_URL);pg.wait_for_selector('#lf',timeout=20000);pg.wait_for_timeout(500)
    ok('Tela de login (conta com senha, após recarregar): mostra o mascote Nyx escolhido, sem decifrar nada',ev(pg,"document.querySelector('#lock .wolf').dataset.mc")=='nyx')
    # olhos fecham ao digitar a senha; olham para baixo no campo de usuário
    pg.focus('#lf [name=p]');pg.wait_for_timeout(200);cl=ev(pg,"document.querySelector('#lock .wolf').classList.contains('cl')")
    pg.focus('#lf [name=u]');pg.wait_for_timeout(200);dn=ev(pg,"document.querySelector('#lock .wolf').classList.contains('dn')")
    sc=ev(pg,"getComputedStyle(document.querySelector('#lock .wolf .slid')).transform")
    ok('Login: o personagem fecha os olhos no campo de senha e baixa o olhar no campo de usuário (pálpebras animadas)',cl and dn,(cl,dn,sc))
    pg.fill('#lf [name=u]','teste');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(900)
    ok('Persistência: depois de entrar de novo, o mascote continua a Nyx (avatar e cartão)',ev(pg,"S.pref.mc")=='nyx' and ev(pg,"document.querySelector('#avh .mcav img').src===mcUrl('nyx')"))
    c2.close()
    # ===== D) Ajustes → Meu mascote (única seção) =====
    c,pg=newapp();pg.evaluate("go('cfg')");pg.wait_for_timeout(400);tx=pg.inner_text('#s-cfg')
    ok('Ajustes tem UMA seção "Meu mascote" e nenhuma opção antiga (sem "Avatar", sem "Escolher avatar", sem "Mascote" com roupas, sem "troca automática")',tx.count('Meu mascote')==1 and 'Escolher avatar' not in tx and 'Roupa de agora' not in tx and 'automaticamente' not in tx.split('Meu mascote')[1].split('Backup')[0] and pg.locator('#s-cfg .skb, #s-cfg .avcd, #s-cfg .av').count()==0 and not re.search(r'(?m)^Avatar$',tx))
    pg.click('#s-cfg [data-act=avs]');pg.wait_for_selector('#ov .sheet .mcrow');pg.wait_for_timeout(300)
    ok('"Trocar de mascote" abre a lista dos 10 (com o atual destacado e prévia animada); dá para conhecer cada um antes de confirmar',pg.locator('#ov .mcrow').count()==10 and pg.locator('#ov .mcrow.on').count()==1 and pg.locator('#ov .mcpv .mc').count()==1)
    pg.click('#ov .mcrow[data-id=leonidas]');pg.wait_for_timeout(200);pv=ev(pg,"document.querySelector('#ov .mcpv .mc').dataset.mc");before=ev(pg,"S.pref.mc")
    ok('Tocar num personagem mostra a prévia dele sem trocar ainda (Cancelar não altera nada)',pv=='leonidas' and before=='wolfin')
    pg.click('#ov [data-act=close]');pg.wait_for_timeout(200);ok('Cancelar fecha sem alterar o mascote',ev(pg,"S.pref.mc")=='wolfin' and pg.locator('#ov .sheet').count()==0)
    ok_all=[]
    for i in IDS[1:]:
        pg.click('#s-cfg [data-act=avs]');pg.wait_for_selector('#ov .mcrow');pg.click(f'#ov .mcrow[data-id={i}]');pg.wait_for_timeout(100);pg.click('#ov [data-act=mcok]');pg.wait_for_timeout(250)
        s=ev(pg,"""()=>({mc:S.pref.mc,av:document.querySelector('#avh .mcav img').src,u:mcUrl(S.pref.mc),card:document.querySelector('#s-cfg .mcnow .mc').dataset.mc,set:S.pref.av.set,sv:JSON.parse(localStorage.getItem('wallstreet.v1')).pref.mc,look:JSON.parse(localStorage.getItem('wallstreet.look')).m})""")
        ok_all.append((i,s['mc']==i and s['av']==s['u'] and s['card']==i and s['set']==1 and s['sv']==i and s['look']==i))
    ok('Trocar nas Configurações atualiza na hora o avatar, o cartão e a aparência do login, e salva a escolha, para os 9 outros personagens',all(x[1] for x in ok_all),ok_all)
    ok('A conquista "Cara própria" (escolher o seu mascote) é concedida ao trocar',ev(pg,"ACH.find(a=>a.id==='av').ok()")==True and 'mascote' in ev(pg,"ACH.find(a=>a.id==='av').d"))
    pg.reload();pg.wait_for_selector('#nav');pg.wait_for_timeout(700)
    ok('Persistência após recarregar o site: continua o último escolhido (Elliot)',ev(pg,"S.pref.mc")=='elliot' and ev(pg,"document.querySelector('#avh .mcav img').src===mcUrl('elliot')"))
    c.close()
    # ===== E) migração de contas e backups antigos =====
    c,pg=newapp()
    cases=[('avatar tigre escolhido → Leônidas',{'av':{'v':2,'m':3,'an':1,'set':1},'ms':'terno'},'leonidas'),('avatar coruja escolhido → Oráculo',{'av':{'v':2,'m':8,'an':1,'set':1},'ms':'terno'},'oraculo'),('avatar raposa → Don Vito',{'av':{'v':2,'m':4,'an':1,'set':1},'ms':'terno'},'vito'),('avatar gato preto → Nyx',{'av':{'v':2,'m':2,'an':1,'set':1},'ms':'terno'},'nyx'),('avatar panda-vermelho → Elliot',{'av':{'v':2,'m':9,'an':1,'set':1},'ms':'terno'},'elliot'),('avatar lobo (Alfa) → Wolfin',{'av':{'v':2,'m':0,'an':1,'set':1},'ms':'terno'},'wolfin'),
        ('roupa Rei (avatar não escolhido) → Leônidas',{'av':{'v':2,'m':0,'an':1,'set':0},'ms':'rei'},'leonidas'),('roupa Detetive → Elliot',{'av':{'v':2,'m':0,'an':1,'set':0},'ms':'detetive'},'elliot'),('roupa Hacker → Nyx',{'av':{'v':2,'m':0,'an':1,'set':0},'ms':'hacker'},'nyx'),('roupa Magnata → Don Vito',{'av':{'v':2,'m':0,'an':1,'set':0},'ms':'ostentacao'},'vito'),
        ('avatar sem equivalente (urso polar) + roupa Rei → Leônidas (a roupa decide)',{'av':{'v':2,'m':1,'an':1,'set':1},'ms':'rei'},'leonidas'),('avatar sem equivalente (sapo) e roupa comum → Wolfin (padrão)',{'av':{'v':2,'m':6,'an':1,'set':1},'ms':'praia'},'wolfin'),('dados sem nada reconhecível → Wolfin',{},'wolfin'),('valor corrompido em mc → refeito (Wolfin)',{'mc':'xyz','ms':'jazz'},'wolfin'),('mc válido é respeitado',{'mc':'brutus','ms':'rei','av':{'v':2,'m':3,'an':1,'set':1}},'brutus')]
    bad=[]
    for nm,pref,exp in cases:
        got=ev(pg,"""pf=>{const o=JSON.parse(JSON.stringify(S));o.pref=Object.assign({theme:'light',pal:'blue'},pf);const r=migrate(o);return {mc:r.pref.mc,items:r.items.length,keep:JSON.stringify(r.pref.av)+'|'+r.pref.ms}}""",pref)
        if got['mc']!=exp:bad.append((nm,got['mc'],exp))
    ok('Migração: avatar e roupa antigos viram o mascote equivalente; sem correspondência usa o Wolfin; escolha nova é respeitada (15 cenários)',not bad,bad)
    ev(pg,"""()=>{S.items.push({id:'t1',t:'inc',d:'Salário',c:300000,day:5,fixed:true,from:'2026-01',done:{},cat:'Salário'});S.debts.push({id:'d1',n:'Dívida',o:50000,due:'',pays:[]});save()}""")
    mig=ev(pg,"""()=>{const o=JSON.parse(JSON.stringify(S));delete o.pref.mc;o.pref.av={v:2,m:3,an:0,set:1};o.pref.ms='jazz';const r=migrate(o);return {mc:r.pref.mc,items:r.items.length,debts:r.debts.length,an:r.pref.av.an,av:r.pref.av.m,ms:r.pref.ms,bal:balance()}}""")
    ok('A migração preserva TUDO: dados financeiros, configurações (animações dos ícones), e os campos antigos (av, ms) não são apagados',mig['items']==1 and mig['debts']==1 and mig['an']==0 and mig['av']==3 and mig['ms']=='jazz' and mig['mc']=='leonidas',mig)
    # backups antigos (fixtures de versões anteriores) → mascote definido, nada perdido
    ix=json.load(open(os.path.join(FIX,'backups','index.json'),encoding='utf-8'));badb=[]
    for e in [x for x in ix['arquivos'] if not x['enc']]:
        txt=open(os.path.join(FIX,'backups',e['file']),encoding='utf-8').read()
        r=ev(pg,"""t=>{const o=migrate(JSON.parse(t));return {mc:o.pref&&o.pref.mc,ok:MCIDS.includes(o.pref&&o.pref.mc),items:o.items.length,debts:o.debts.length,boxes:o.boxes.length,owner:o.owner}}""",txt)
        if not(r['ok'] and r['items']==3 and r['debts']==1 and r['boxes']==1):badb.append((e['file'],r))
    ok('Backups de 13 versões anteriores (fixtures) abrem no sistema novo: mascote definido e receitas, despesas, dívidas e caixinhas intactas',not badb and len([x for x in ix['arquivos'] if not x['enc']])>=10,badb[:2])
    ev(pg,"S.pref.mc='penny';save()")
    exp=ev(pg,"(async()=>{const t=await bkpExportText();return t})()")
    ok('Backup novo guarda o mascote (pref.mc) e continua com o marcador compatível "wallstreet-backup"',json.loads(exp)['pref']['mc']=='penny' and json.loads(exp)['__backup']['app']=='wallstreet-backup',json.loads(exp)['pref'].get('mc'))
    c.close()
    # ===== F) animações individuais =====
    c,pg=newapp()
    ev(pg,"""()=>{document.getElementById('lock').hidden=true;const d=document.createElement('div');d.id='dbg';d.style.cssText='position:fixed;left:0;top:0;width:900px;z-index:999;display:flex;flex-wrap:wrap';d.innerHTML=MC.map(m=>'<div style="width:170px">'+mascotHtml(m.id,'bust')+'</div>').join('');document.body.appendChild(d)}""")
    pg.wait_for_timeout(400)
    info=ev(pg,"""()=>MC.map(m=>{const el=document.querySelector('#dbg .mc[data-mc='+m.id+']');const an=n=>el.querySelectorAll(n).length;const cs=getComputedStyle(el);const names=new Set([...el.querySelectorAll('*'),el].flatMap(e=>e.getAnimations().map(a=>a.animationName)));return {id:m.id,lids:an('.slid'),ears:an('.wear'),gl:an('.mcg'),sw:an('.mcsw'),sm:an('.mcsm'),ng:an('.mcng'),hp:cs.getPropertyValue('--hp'),ha:cs.getPropertyValue('--ha'),bk:cs.getPropertyValue('--bk'),bz:el.dataset.bz,anims:[...names].sort(),n:el.getAnimations({subtree:true}).length}})""")
    byid={x['id']:x for x in info}
    ok('Olhos: cada personagem pisca com as pálpebras certas (1 ou 2 olhos visíveis) e ritmo próprio; o Mako tem um olho visível',all(x['lids']==ex for x,ex in zip(info,[2,2,2,2,2,1,2,2,2,2])) and len({x['bk'] for x in info})>=7,[(x['id'],x['lids'],x['bk']) for x in info])
    ok('Piscar individual: Leônidas e Mako piscam devagar; Don Vito tem olhar de sorriso confiante (meia pálpebra); os demais piscam normalmente',byid['leonidas']['bz']=='s' and byid['mako']['bz']=='s' and byid['vito']['bz']=='h' and all(byid[i]['bz']=='n' for i in IDS if i not in('leonidas','mako','vito')),{k:v['bz'] for k,v in byid.items()})
    ok('Orelhas se mexem (clones recortados) em Wolfin, Don Vito, Brutus, Penny, Nyx e Elliot; nos demais não forçamos',all(byid[i]['ears']>0 for i in ('wolfin','vito','brutus','penny','nyx','elliot')) and all(byid[i]['ears']==0 for i in ('leonidas','oraculo','mako','bento')),{k:v['ears'] for k,v in byid.items()})
    ok('Efeitos próprios: coroa e cetro de Leônidas, moeda da Penny, correntes/relógios, abotoaduras do Mako com brilhos; óculos do Oráculo e do Bento e a lupa do Elliot com reflexo; fumaça discreta do Brutus; neon da Nyx',byid['leonidas']['gl']>=4 and byid['penny']['gl']>=1 and byid['vito']['gl']>=3 and byid['mako']['gl']>=2 and byid['oraculo']['sw']==2 and byid['bento']['sw']==2 and byid['elliot']['sw']==1 and byid['brutus']['sm']==2 and byid['nyx']['ng']>=4,{k:(v['gl'],v['sw'],v['sm'],v['ng']) for k,v in byid.items()})
    ok('Cada personagem tem movimento de cabeça e respiração próprios (períodos e amplitudes diferentes)',len({(x['hp'],x['ha']) for x in info})>=9 and byid['oraculo']['anims'].count('mcswp')==1 and byid['elliot']['anims'].count('mcsws')==1,[(x['id'],x['hp'],x['ha']) for x in info])
    # quadros: pálpebra fecha no momento do piscar; fumaça aparece; neon pulsa
    fr=ev(pg,"""()=>{const out={};for(const id of ['wolfin','brutus','nyx']){const el=document.querySelector('#dbg .mc[data-mc='+id+']');for(const a of el.getAnimations({subtree:true})){try{a.pause()}catch(e){}}const lid=el.querySelector('.slid');const bl=lid.getAnimations()[0];const d=bl.effect.getComputedTiming().duration;bl.currentTime=d*.935+(parseFloat(getComputedStyle(lid).getPropertyValue('--bd'))*0);const closed=new DOMMatrix(getComputedStyle(lid).transform).d;bl.currentTime=d*.3;const open=new DOMMatrix(getComputedStyle(lid).transform).d;out[id]={closed:+closed.toFixed(2),open:+open.toFixed(2)};}
     const sm=document.querySelector('#dbg .mc[data-mc=brutus] .mcsm'),sa=sm.getAnimations()[0];sa.pause();sa.currentTime=2400+sa.effect.getComputedTiming().duration*.7;out.fumaca=+getComputedStyle(sm).opacity;
     const ng=document.querySelector('#dbg .mc[data-mc=nyx] .mcng'),na=ng.getAnimations()[0];na.pause();na.currentTime=na.effect.getComputedTiming().duration*.5;out.neon=+getComputedStyle(ng).opacity;return out}""")
    ok('Quadros: a pálpebra fecha por inteiro no instante do piscar e reabre; a fumaça do Brutus aparece e some; o neon da Nyx pulsa',all(fr[i]['closed']>0.9 and fr[i]['open']<0.1 for i in('wolfin','brutus','nyx')) and fr['fumaca']>0.3 and fr['neon']>0.6,fr)
    ev(pg,"""()=>{const out=[];document.querySelectorAll('#dbg .mc').forEach(el=>el.getAnimations({subtree:true}).forEach(a=>{(a.effect.getKeyframes()||[]).forEach(k=>Object.keys(k).forEach(p=>{if(!['offset','easing','composite','computedOffset'].includes(p))out.push(p)}))}));window.__props=[...new Set(out)]}""")
    props=ev(pg,"window.__props")
    ok('Desempenho: as animações usam só transform e opacidade (e máscara estática), poucas por personagem (≤ 14)',set(props)<={'transform','opacity'} and max(x['n'] for x in info)<=14,(props,max(x['n'] for x in info)))
    c.close()
    c,pg=newapp(reduce=True);ev(pg,"""()=>{document.getElementById('lock').hidden=true;const d=document.createElement('div');d.id='dbg';d.innerHTML=mascotHtml('brutus','bust')+mascotHtml('nyx','bust');document.body.appendChild(d)}""");pg.wait_for_timeout(300)
    ok('Movimento reduzido: nenhuma animação roda nos mascotes (versão estática)',ev(pg,"document.querySelectorAll('#dbg .mc').length===2&&[...document.querySelectorAll('#dbg .mc')].every(el=>el.getAnimations({subtree:true}).length===0)")==True)
    c.close()
    # ===== G) temas, telas pequenas, rolagem =====
    ovf=[]
    for (w,h,th) in ((393,851,'light'),(393,851,'dark'),(360,740,'light'),(320,568,'dark')):
        c=ctx(w,h);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=new]');pg.evaluate(f"S.pref.theme='{th}';applyPref()");pg.click('[data-lk=new]');pg.fill('#nf [name=n]','T');pg.click('#nf button');pg.wait_for_selector('#mf');pg.wait_for_timeout(400)
        g=ev(pg,"""()=>{const L=document.getElementById('lock'),rs=[...document.querySelectorAll('#mf .mcrow')].map(r=>r.getBoundingClientRect()),b=document.querySelector('#mf button.b1');return {sx:document.documentElement.scrollWidth,W:innerWidth,rowW:Math.max(...rs.map(r=>r.right))-Math.min(...rs.map(r=>r.left)),over:rs.some(r=>r.right>innerWidth+1||r.left<-1),imgs:[...document.querySelectorAll('#mf .mcav img')].every(i=>i.naturalWidth>0),scrollable:L.scrollHeight>L.clientHeight,th:document.documentElement.dataset.theme}}""")
        pg.evaluate("document.querySelector('#mf button.b1').scrollIntoView()");pg.wait_for_timeout(150);vis=ev(pg,"(()=>{const r=document.querySelector('#mf button.b1').getBoundingClientRect();return r.bottom<=innerHeight+1&&r.top>=0})()")
        if g['sx']>g['W'] or g['over'] or not g['imgs'] or not vis or g['th']!=th:ovf.append((w,h,th,g,vis))
        c.close()
    ok('Seleção na criação de conta em telas de 320 a 393 px, claro e escuro: sem rolagem lateral, imagens carregadas, botão Continuar alcançável com a rolagem',not ovf,ovf[:1])
    c,pg=newapp(320,568,'dark');pg.evaluate("go('cfg')");pg.wait_for_timeout(300);pg.click('#s-cfg [data-act=avs]');pg.wait_for_selector('#ov .mcrow');pg.wait_for_timeout(300)
    sh=ev(pg,"""()=>{const s=document.querySelector('#ov .sheet').getBoundingClientRect(),bt=[...document.querySelectorAll('#ov .btns button')].map(b=>b.getBoundingClientRect());return {fits:s.bottom<=innerHeight+1&&s.top>=0,btns:bt.every(b=>b.bottom<=innerHeight+1&&b.height>=44),sx:document.documentElement.scrollWidth<=innerWidth,list:document.querySelector('#ov .mclist').scrollHeight>document.querySelector('#ov .mclist').clientHeight}}""")
    ok('Janela de troca em tela de 320×568 (escuro): cabe na tela, botões visíveis (44 px), lista rola por dentro, sem rolagem lateral',sh['fits'] and sh['btns'] and sh['sx'] and sh['list'],sh)
    ok('Console sem erros em toda a suíte (criação, ajustes, troca, migração, animações)',not pg.errs,pg.errs[:2]);c.close()
    # ===== H) offline / PWA: imagens embutidas =====
    reqs=[];c=ctx(sw=True);pg=page(c);pg.on('request',lambda r:reqs.append(r.url.split('/')[-1]) if re.search(r'\.(webp|png|jpe?g|svg)(\?|$)',r.url) and 'icon' not in r.url and 'favicon' not in r.url and 'apple' not in r.url else None)
    pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','T');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_function("navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))",timeout=15000);pg.reload();pg.wait_for_function("!!navigator.serviceWorker.controller",timeout=15000);pg.wait_for_selector('#avh');pg.wait_for_timeout(500)
    c.set_offline(True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#avh',timeout=10000);pg.wait_for_timeout(500)
    imgs=ev(pg,"[...document.querySelectorAll('#avh img,#s-home .mqc img')].map(i=>i.complete&&i.naturalWidth>0)")
    ok('Offline (PWA): o avatar e o mascote aparecem sem internet, e nenhum arquivo de imagem de mascote é baixado da rede (estão embutidos)',len(imgs)>=2 and all(imgs) and not reqs and not pg.errs,(imgs,reqs[:3],pg.errs[:2]));c.close()
print(sum(R),'/',len(R))
