"""Intro animada do Wolfin: logo do lobo (icon-512.png, sem alteração), nome WOLFIN e slogan; ~1,5 s; temas claro/escuro;
só ao abrir/recarregar (nunca na navegação interna); reduced-motion; toque pula; não atrasa o login; offline/PWA; sem mexer em dados."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,io,statistics
from PIL import Image
from contrast import ratio,parse
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
SPY="(()=>{window.__i={};const mo=new MutationObserver(()=>{const e=document.getElementById('intro');if(e&&!window.__i.seen)window.__i.seen=performance.now();if(!e&&window.__i.seen&&!window.__i.gone){window.__i.gone=performance.now();mo.disconnect()}});mo.observe(document,{childList:true,subtree:true})})()"
PAUSE="t=>document.getAnimations().forEach(a=>{try{a.pause();a.currentTime=t}catch(e){}})"
CSS_NOTEXT="#intro .in,#intro .is{color:transparent!important;-webkit-text-fill-color:transparent!important}"
html=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,reduce=False,state=None,spy=True,hook=False,sw=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=True,reduced_motion='reduce' if reduce else 'no-preference',storage_state=state,service_workers='allow' if sw else 'block',timezone_id='America/Sao_Paulo')
        if hook:c.add_init_script("window.__WS_NOTOUR=1")
        if spy:c.add_init_script(SPY)
        return c
    def page(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None);return pg
    def themed_state(theme):   # estado de navegador de um usuário que já usa o app (sem senha) no tema escolhido
        c=ctx(spy=False,hook=True);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Teste');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref();S.flags={tour:1};save()"%theme);pg.wait_for_timeout(500);st=c.storage_state();c.close();return st
    # ===== A) a logo é o arquivo original, sem alteração; estrutura =====
    sha_logo=sha(open(os.path.join(ROOT,'icon-512.png'),'rb').read().hex())
    ok('A logo usada é o arquivo original icon-512.png, sem alteração (conferido por impressão digital guardada)',check_golden('logo_icon512',sha_logo),'se trocar a logo de propósito: WS_UPDATE_GOLDEN=1 python3 tests/suites/intro_wolfin.py')
    ok('Intro no HTML: primeiro elemento da página, escondida de leitores de tela, com a logo, "WOLFIN" e "Domine seu dinheiro.", sem marca antiga',bool(re.search(r'<body>\s*<div id="intro" aria-hidden="true">',html)) and 'src="icon-512.png"' in html.split('id="intro"')[1].split('</div></div>')[0] and '<b class="in">WOLFIN</b>' in html and '<span class="is">Domine seu dinheiro.</span>' in html and 'WALL STREET' not in html.split('id="intro"')[1].split('</script>')[0])
    ok('Sem dependências externas: a intro só usa a logo do próprio projeto (nenhuma URL externa no CSS/HTML da intro)',not re.search(r'https?://',html.split('id="intro"')[1].split('</script>')[0]) and 'https://' not in open(os.path.join(ROOT,'index.html'),encoding='utf-8').read().split('/* ===== intro animada')[1].split('</style>')[0])
    # ===== B) linha do tempo =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_function("window.__i&&window.__i.gone",timeout=8000);i=pg.evaluate("window.__i");dur=i['gone']-i['seen']
    ok('Duração: a intro aparece e termina em cerca de 1,5 s (entre 1,3 s e 2,2 s, incluindo o carregamento)',1300<=dur<=2200,round(dur))
    ok('Depois da intro o app está ali, sem erros: tela de boas-vindas/entrada utilizável',pg.locator('#lock [data-lk=new]').is_visible() and not pg.errs,pg.errs[:2]);c.close()
    # ===== C) quadros: entrada suave, logo, nome, slogan, saída =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');ST="(()=>{if(!document.getElementById('intro'))return {removed:true,root:0,vis:'hidden'};const g=s=>{const e=document.querySelector(s);return e?+getComputedStyle(e).opacity:null};const m=new DOMMatrix(getComputedStyle(document.querySelector('#intro .ib')).transform);return {logo:g('#intro .ib'),name:g('#intro .in'),slogan:g('#intro .is'),root:g('#intro'),scale:m.a,vis:getComputedStyle(document.getElementById('intro')).visibility}})()"
    anims=pg.evaluate("document.getAnimations().filter(a=>a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#intro')).map(a=>[a.animationName,[...new Set(a.effect.getKeyframes().flatMap(k=>Object.keys(k)))].filter(k=>!['offset','easing','composite','computedOffset'].includes(k))])")
    props={x for a in anims for x in a[1]}
    F={}
    for t in (0,520,1100,1380,1560):pg.evaluate(PAUSE,t);pg.wait_for_timeout(60);F[t]=pg.evaluate(ST)
    ok('Quadro 0 ms: logo e textos ainda invisíveis (entrada suave, sem pulo)',F[0]['logo']<0.06 and F[0]['name']<0.06 and F[0]['slogan']<0.06 and F[0]['root']==1,F[0])
    ok('Logo surge com escala e opacidade (≈0,5 s: opaca e com escala entre 0,95 e 1,05); o nome ainda está entrando',F[520]['logo']>0.97 and 0.95<=F[520]['scale']<=1.05 and F[520]['name']<0.7,F[520])
    ok('Nome WOLFIN e slogan aparecem em sequência (a ≈1,1 s ambos visíveis)',F[1100]['name']>0.97 and F[1100]['slogan']>0.9,F[1100])
    ok('Saída gradual: a ≈1,38 s a intro está desaparecendo; no fim fica invisível e deixa de bloquear toques',0<F[1380]['root']<0.95 and F[1560]['root']==0 and F[1560]['vis']=='hidden',(F[1380],F[1560]))
    ok('Desempenho: a intro anima só transform, opacidade e visibilidade (sem layout nem pintura pesada) e usa poucas animações',props<={'transform','opacity','visibility'} and 5<=len(anims)<=12,(sorted(props),len(anims)));c.close()
    # ===== D) temas claro e escuro + contraste =====
    for th in ('light','dark'):
        st=themed_state(th);c=ctx(state=st);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.evaluate(PAUSE,1100);pg.wait_for_timeout(150)
        info=pg.evaluate("({tema:document.documentElement.dataset.theme,intro:getComputedStyle(document.getElementById('intro')).backgroundColor,body:getComputedStyle(document.documentElement).backgroundColor})")
        lum=lambda col:(0.2126*parse(col)[0][0]+0.7152*parse(col)[0][1]+0.0722*parse(col)[0][2])/255
        pg.add_style_tag(content=CSS_NOTEXT);pg.wait_for_timeout(120);bg=Image.open(io.BytesIO(pg.screenshot())).convert('RGB');sx=bg.size[0]/pg.evaluate('innerWidth');res=[]
        pg.evaluate("document.querySelectorAll('style').forEach(s=>{if(s.textContent.startsWith('#intro .in,#intro .is{color:transparent'))s.remove()})");pg.wait_for_timeout(80)
        for sel,need in (('#intro .in',3.0),('#intro .is',4.5)):
            r=pg.evaluate("s=>{const e=document.querySelector(s),b=e.getBoundingClientRect();return {x0:b.left,y0:b.top,x1:b.right,y1:b.bottom,c:getComputedStyle(e).color}}",sel)
            reg=bg.crop((int(r['x0']*sx),int(r['y0']*sx),int(r['x1']*sx),int(r['y1']*sx)));px=list(reg.getdata());med=tuple(statistics.median(q[i] for q in px) for i in range(3));fg=parse(r['c'])[0];res.append((sel,round(ratio(fg,med),2),need))
        ok(f'Tema {"claro" if th=="light" else "escuro"}: o fundo da intro é o mesmo do app (tema atual) e o texto tem contraste suficiente (nome ≥ 3:1, slogan ≥ 4,5:1)',info['tema']==th and info['intro']==info['body'] and (lum(info['intro'])>0.7 if th=='light' else lum(info['intro'])<0.25) and all(x[1]>=x[2] for x in res),(info,res));c.close()
    # ===== E) pular com toque e não atrasar o login (conta protegida criada pela versão anterior) =====
    fx=json.load(open(os.path.join(FIX,'legacy','conta_protegida_v55.json'),encoding='utf-8'));init="".join(f"localStorage.setItem({json.dumps(k)},{json.dumps(v)});" for k,v in fx['chaves'].items())
    c=ctx();c.add_init_script(init);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.wait_for_timeout(250);t0=pg.evaluate("performance.now()");pg.mouse.click(196,425);pg.wait_for_function("!document.getElementById('intro')",timeout=3000);skip=pg.evaluate("performance.now()")-t0
    ok('Toque na intro a pula na hora (some em menos de 0,5 s) e o login fica disponível',skip<500 and pg.locator('#lf').is_visible(),round(skip))
    pg.fill('#lf [name=u]',fx['usuario']);pg.fill('#lf [name=p]',fx['senha']);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(800)
    ok('Login funciona depois da intro, com a mesma senha da conta antiga (autenticação e criptografia intactas), e os dados continuam lá',pg.evaluate("balance()")==fx['esperado']['balance'] and pg.evaluate("S.owner")=='Paul',pg.evaluate("balance()"));c.close()
    c=ctx();c.add_init_script(init);pg=page(c);t0=__import__('time').time();pg.goto(HTTP_URL,wait_until='commit');pg.fill('#lf [name=u]',fx['usuario'],timeout=6000);tf=__import__('time').time()-t0
    ok('Sem toque: o login pode ser usado logo que a intro termina (≤ 2,6 s da abertura) — a intro não segura o app além do necessário',tf<=2.6,round(tf,2));c.close()
    # ===== F) só ao abrir/recarregar; nunca na navegação interna =====
    st=themed_state('light');c=ctx(state=st,spy=False);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_function("!document.getElementById('intro')",timeout=6000);pg.wait_for_timeout(500)
    pg.evaluate("window.__n=0;new MutationObserver(m=>{m.forEach(x=>x.addedNodes.forEach(n=>{if(n.id==='intro'||(n.querySelector&&n.querySelector('#intro')))window.__n++}))}).observe(document,{childList:true,subtree:true})")
    for v in ['home','rec','des','div','cx','rel','cfg','nt','cc','ntf','conq','home']:pg.evaluate(f"go('{v}')");pg.wait_for_timeout(150)
    pg.evaluate("ask('Teste?',()=>{})");pg.wait_for_timeout(200);pg.evaluate('closeOv()');pg.evaluate("document.dispatchEvent(new Event('visibilitychange'));history.pushState({},'','#x');dispatchEvent(new PopStateEvent('popstate'))");pg.wait_for_timeout(600)
    ok('Navegação interna (12 trocas de tela, janela, visibilidade, histórico): a intro NUNCA reaparece',pg.evaluate("window.__n")==0 and pg.locator('#intro').count()==0)
    pg.reload();pg.wait_for_selector('#intro .ib img',timeout=4000);ok('Ao recarregar a página a intro aparece de novo',pg.locator('#intro').count()==1);c.close()
    # ===== G) prefers-reduced-motion =====
    c=ctx(reduce=True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.wait_for_timeout(120)
    s=pg.evaluate("({anim:document.getAnimations().filter(a=>a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#intro')).length,ops:['.ib','.in','.is'].map(s=>+getComputedStyle(document.querySelector('#intro '+s)).opacity),ears:getComputedStyle(document.querySelector('#intro .ie')).display,sw:getComputedStyle(document.querySelector('#intro .sw')).display})")
    pg.wait_for_function("window.__i&&window.__i.gone",timeout=5000);dur=pg.evaluate("window.__i.gone-window.__i.seen")
    ok('Movimento reduzido: entrada estática (sem animações, tudo já visível, sem orelhas/reflexo) e some em menos de 1 s',s['anim']==0 and all(o==1 for o in s['ops']) and s['ears']=='none' and s['sw']=='none' and dur<1000,(s,round(dur)));c.close()
    # ===== H) responsividade =====
    bad=[]
    for (w,h) in ((320,568),(360,740),(393,851),(412,915),(851,393),(1280,800)):
        c=ctx(w,h);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.evaluate(PAUSE,1100);pg.wait_for_timeout(120)
        g=pg.evaluate("(()=>{const r=s=>document.querySelector(s).getBoundingClientRect(),l=r('#intro .ib'),n=r('#intro .in'),s=r('#intro .is'),W=innerWidth,H=innerHeight;return {cx:l.left+l.width/2,W,H,lw:l.width,lh:l.height,top:l.top,bot:s.bottom,ncx:n.left+n.width/2,sw:s.width,sl:s.left,sr:s.right,nl:n.left,nr:n.right,sx:document.documentElement.scrollWidth,sy:document.documentElement.scrollHeight}})()")
        mid=(g['top']+g['bot'])/2
        if not(abs(g['cx']-g['W']/2)<=1.5 and abs(g['ncx']-g['W']/2)<=1.5 and abs(g['lw']-g['lh'])<=0.6 and 0.38*g['H']<=mid<=0.56*g['H'] and g['top']>=0 and g['bot']<=g['H'] and g['nl']>=0 and g['nr']<=g['W'] and g['sl']>=0 and g['sr']<=g['W'] and g['sx']<=g['W']):bad.append((w,h,g))
        c.close()
    ok('Responsivo (320, 360, 393, 412 px, paisagem 851×393 e 1280×800): logo e textos centralizados, proporção 1:1 da logo preservada, nada cortado e sem barra de rolagem',not bad,bad[:1])
    # ===== I) offline / PWA =====
    c=ctx(sw=True);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    pg.wait_for_function("navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))",timeout=15000);pg.reload();pg.wait_for_function("!!navigator.serviceWorker.controller",timeout=15000)
    pg.wait_for_function("caches.keys().then(async ks=>{for(const k of ks){const c=await caches.open(k);if(await c.match('icon-512.png'))return true}return false})",timeout=15000);pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    c.set_offline(True);pg.reload(wait_until='commit');pg.wait_for_selector('#intro .ib img',timeout=8000);pg.wait_for_timeout(300)
    li=pg.evaluate("(()=>{const i=document.querySelector('#intro .ib img');return {w:i.naturalWidth,done:i.complete,online:navigator.onLine}})()")
    pg.wait_for_function("!document.getElementById('intro')",timeout=6000);pg.wait_for_selector('#lock [data-lk=new], #lock #lf',timeout=8000)
    ok('Offline (PWA com Service Worker): a intro aparece com a logo vinda do cache (512 px), termina e o app abre normalmente sem internet',li['w']==512 and li['done'] and not li['online'] and not pg.errs,(li,pg.errs[:2]));c.close()
    # ===== J) não mexe em dados, nem causa mudança de layout =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');h1=pg.evaluate("document.documentElement.scrollHeight");pg.wait_for_function("!document.getElementById('intro')",timeout=6000);h2=pg.evaluate("document.documentElement.scrollHeight")
    keys=pg.evaluate("Object.keys(localStorage).concat(Object.keys(sessionStorage))")
    ok('A intro não grava nada no armazenamento e não altera o layout (a altura da página é a mesma antes e depois)',not any('intro' in k.lower() for k in keys) and h1==h2,(keys,h1,h2));c.close()
    # ===== K) fluidez =====
    c=ctx();pg=page(c);pg.add_init_script("window.__f=[];(function loop(t){window.__f.push(performance.now());if(!window.__stop)requestAnimationFrame(loop)})(0)") if False else None
    pg.goto(HTTP_URL,wait_until='commit');pg.evaluate("window.__f=[];(function l(){window.__f.push(performance.now());if(document.getElementById('intro'))requestAnimationFrame(l)})()");pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    fr=pg.evaluate("window.__f");gaps=[fr[i+1]-fr[i] for i in range(len(fr)-1)]
    ok('Fluidez: quadros regulares durante a intro (mediana ≤ 34 ms e nenhum travamento acima de 250 ms)',len(gaps)>=15 and statistics.median(gaps)<=34 and max(gaps)<=250,(len(gaps),round(statistics.median(gaps),1),round(max(gaps))));c.close()
print(sum(R),'/',len(R))
