"""Intro animada do Wolfin: logo do lobo (icon-512.png, sem alteração), nome WOLFIN e slogan; ~1,5 s; temas claro/escuro;
só ao abrir/recarregar (nunca na navegação interna); reduced-motion; toque pula; não atrasa o login; offline/PWA; sem mexer em dados."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,io,statistics
from PIL import Image
from contrast import ratio,parse
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
SPY="(()=>{window.__i={};const mo=new MutationObserver(()=>{const e=document.getElementById('intro');if(e&&!window.__i.seen)window.__i.seen=performance.now();if(!e&&window.__i.seen&&!window.__i.gone){window.__i.gone=performance.now();mo.disconnect()}});mo.observe(document,{childList:true,subtree:true})})()"
PAUSE="t=>document.getAnimations().forEach(a=>{try{a.pause();a.currentTime=t}catch(e){}})"
CSS_NOTEXT="#intro .in,#intro .is{color:transparent!important;-webkit-text-fill-color:transparent!important}"
html=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    ba=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])          # navegador que PERMITE som automático (ex.: app instalado)
    bb=p.chromium.launch(args=['--autoplay-policy=document-user-activation-required'])  # navegador que BLOQUEIA som automático (padrão da maioria)
    def ctx(w=393,h=851,reduce=False,state=None,spy=True,hook=False,sw=False,video=False,br=None):
        c=(br or b).new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=True,reduced_motion='reduce' if reduce else 'no-preference',storage_state=state,service_workers='allow' if sw else 'block',timezone_id='America/Sao_Paulo')
        if hook:c.add_init_script("window.__WS_NOTOUR=1")
        if not video:c.add_init_script("window.__WS_INTRO='css'")   # as verificações A–K testam a intro em CSS (a de vídeo tem a seção L)
        if spy:c.add_init_script(SPY)
        return c
    def page(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None);return pg
    def themed_state(theme):   # estado de navegador de um usuário que já usa o app (sem senha) no tema escolhido
        c=ctx(spy=False,hook=True);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Teste');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref();S.flags={tour:1};save()"%theme);pg.wait_for_timeout(500);st=c.storage_state();c.close();return st
    # ===== A) a logo é o arquivo original, sem alteração; estrutura =====
    sha_logo=sha(open(os.path.join(ROOT,'icon-512.png'),'rb').read().hex())
    ok('A logo usada é o arquivo original icon-512.png, sem alteração (conferido por impressão digital guardada)',check_golden('logo_icon512',sha_logo),'se trocar a logo de propósito: WS_UPDATE_GOLDEN=1 python3 tests/suites/intro_wolfin.py')
    ok('Intro no HTML: primeiro elemento da página, escondida de leitores de tela, com a logo, "WOLFIN" e "Domine seu dinheiro.", sem marca antiga',bool(re.search(r'<body>\s*<div id="intro" aria-hidden="true">',html)) and 'src="icon-512.png"' in html.split('id="intro"')[1].split('</div></div>')[0] and '<b class="in">WOLFIN</b>' in html and '<span class="is">Domine seu dinheiro.</span>' in html and 'WALL STREET' not in html.split('id="intro"')[1].split('</script>')[0])
    ok('Sem dependências externas: a intro só usa a logo do próprio projeto (nenhuma URL externa no CSS/HTML da intro)',not re.search(r'https?://',html.split('id="intro"')[1].split('</script>')[0]) and 'https://' not in open(os.path.join(ROOT,'index.html'),encoding='utf-8').read().split('/* ===== intro animada')[1].split('</style>')[0])
    # ===== B) linha do tempo =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_function("window.__i&&window.__i.gone",timeout=8000);i=pg.evaluate("window.__i");dur=i['gone']-i['seen']
    ok('Duração: a intro aparece e termina em cerca de 1,5 s (entre 1,3 s e 2,2 s, incluindo o carregamento)',1300<=dur<=2200,round(dur))
    ok('Depois da intro o app está ali, sem erros: tela de boas-vindas/entrada utilizável',pg.locator('#lock [data-lk=new]').is_visible() and not pg.errs,pg.errs[:2]);c.close()
    # ===== C) quadros: entrada suave, logo, nome, slogan, saída =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');ST="(()=>{if(!document.getElementById('intro'))return {removed:true,root:0,vis:'hidden'};const g=s=>{const e=document.querySelector(s);return e?+getComputedStyle(e).opacity:null};const m=new DOMMatrix(getComputedStyle(document.querySelector('#intro .ib')).transform);return {logo:g('#intro .ib'),name:g('#intro .in'),slogan:g('#intro .is'),root:g('#intro'),scale:m.a,vis:getComputedStyle(document.getElementById('intro')).visibility}})()"
    anims=pg.evaluate("document.getAnimations().filter(a=>a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#intro')).map(a=>[a.animationName,[...new Set(a.effect.getKeyframes().flatMap(k=>Object.keys(k)))].filter(k=>!['offset','easing','composite','computedOffset'].includes(k))])")
    props={x for a in anims for x in a[1]}
    F={}
    for t in (0,520,1100,1380,1560):pg.evaluate(PAUSE,t);pg.wait_for_timeout(60);F[t]=pg.evaluate(ST)
    ok('Quadro 0 ms: logo e textos ainda invisíveis (entrada suave, sem pulo)',F[0]['logo']<0.06 and F[0]['name']<0.06 and F[0]['slogan']<0.06 and F[0]['root']==1,F[0])
    ok('Logo surge com escala e opacidade (≈0,5 s: opaca e com escala entre 0,95 e 1,05); o nome ainda está entrando',F[520]['logo']>0.97 and 0.95<=F[520]['scale']<=1.05 and F[520]['name']<0.7,F[520])
    ok('Nome WOLFIN e slogan aparecem em sequência (a ≈1,1 s ambos visíveis)',F[1100]['name']>0.97 and F[1100]['slogan']>0.9,F[1100])
    ok('Saída gradual: a ≈1,38 s a intro está desaparecendo; no fim fica invisível e deixa de bloquear toques',0<F[1380]['root']<0.95 and F[1560]['root']==0 and F[1560]['vis']=='hidden',(F[1380],F[1560]))
    ok('Desempenho: a intro anima só transform, opacidade e visibilidade (sem layout nem pintura pesada) e usa poucas animações',props<={'transform','opacity','visibility'} and 5<=len(anims)<=12,(sorted(props),len(anims)));c.close()
    # ===== D) temas claro e escuro + contraste =====
    for th in ('light','dark'):
        st=themed_state(th);c=ctx(state=st);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.evaluate(PAUSE,1100);pg.wait_for_timeout(150)
        info=pg.evaluate("({tema:document.documentElement.dataset.theme,intro:getComputedStyle(document.getElementById('intro')).backgroundColor,body:getComputedStyle(document.documentElement).backgroundColor})")
        lum=lambda col:(0.2126*parse(col)[0][0]+0.7152*parse(col)[0][1]+0.0722*parse(col)[0][2])/255
        pg.add_style_tag(content=CSS_NOTEXT);pg.wait_for_timeout(120);bg=Image.open(io.BytesIO(pg.screenshot())).convert('RGB');sx=bg.size[0]/pg.evaluate('innerWidth');res=[]
        pg.evaluate("document.querySelectorAll('style').forEach(s=>{if(s.textContent.startsWith('#intro .in,#intro .is{color:transparent'))s.remove()})");pg.wait_for_timeout(80)
        for sel,need in (('#intro .in',3.0),('#intro .is',4.5)):
            r=pg.evaluate("s=>{const e=document.querySelector(s),b=e.getBoundingClientRect();return {x0:b.left,y0:b.top,x1:b.right,y1:b.bottom,c:getComputedStyle(e).color}}",sel)
            reg=bg.crop((int(r['x0']*sx),int(r['y0']*sx),int(r['x1']*sx),int(r['y1']*sx)));px=list(reg.getdata());med=tuple(statistics.median(q[i] for q in px) for i in range(3));fg=parse(r['c'])[0];res.append((sel,round(ratio(fg,med),2),need))
        ok(f'Tema {"claro" if th=="light" else "escuro"}: o fundo da intro é o mesmo do app (tema atual) e o texto tem contraste suficiente (nome ≥ 3:1, slogan ≥ 4,5:1)',info['tema']==th and info['intro']==info['body'] and (lum(info['intro'])>0.7 if th=='light' else lum(info['intro'])<0.25) and all(x[1]>=x[2] for x in res),(info,res));c.close()
    # ===== E) pular com toque e não atrasar o login (conta protegida criada pela versão anterior) =====
    fx=json.load(open(os.path.join(FIX,'legacy','conta_protegida_v55.json'),encoding='utf-8'));init="".join(f"localStorage.setItem({json.dumps(k)},{json.dumps(v)});" for k,v in fx['chaves'].items())
    c=ctx();c.add_init_script(init);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.wait_for_timeout(250);t0=pg.evaluate("performance.now()");pg.mouse.click(196,425);pg.wait_for_function("!document.getElementById('intro')",timeout=3000);skip=pg.evaluate("performance.now()")-t0
    ok('Toque na intro a pula na hora (some em menos de 0,5 s) e o login fica disponível',skip<500 and pg.locator('#lf').is_visible(),round(skip))
    pg.fill('#lf [name=u]',fx['usuario']);pg.fill('#lf [name=p]',fx['senha']);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(800)
    ok('Login funciona depois da intro, com a mesma senha da conta antiga (autenticação e criptografia intactas), e os dados continuam lá',pg.evaluate("balance()")==fx['esperado']['balance'] and pg.evaluate("S.owner")=='Paul',pg.evaluate("balance()"));c.close()
    c=ctx();c.add_init_script(init);pg=page(c);t0=__import__('time').time();pg.goto(HTTP_URL,wait_until='commit');pg.fill('#lf [name=u]',fx['usuario'],timeout=6000);tf=__import__('time').time()-t0
    ok('Sem toque: o login pode ser usado logo que a intro termina (≤ 2,6 s da abertura) — a intro não segura o app além do necessário',tf<=2.6,round(tf,2));c.close()
    # ===== F) só ao abrir/recarregar; nunca na navegação interna =====
    st=themed_state('light');c=ctx(state=st,spy=False);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_function("!document.getElementById('intro')",timeout=6000);pg.wait_for_timeout(500)
    pg.evaluate("window.__n=0;new MutationObserver(m=>{m.forEach(x=>x.addedNodes.forEach(n=>{if(n.id==='intro'||(n.querySelector&&n.querySelector('#intro')))window.__n++}))}).observe(document,{childList:true,subtree:true})")
    for v in ['home','rec','des','div','cx','rel','cfg','nt','cc','ntf','conq','home']:pg.evaluate(f"go('{v}')");pg.wait_for_timeout(150)
    pg.evaluate("ask('Teste?',()=>{})");pg.wait_for_timeout(200);pg.evaluate('closeOv()');pg.evaluate("document.dispatchEvent(new Event('visibilitychange'));history.pushState({},'','#x');dispatchEvent(new PopStateEvent('popstate'))");pg.wait_for_timeout(600)
    ok('Navegação interna (12 trocas de tela, janela, visibilidade, histórico): a intro NUNCA reaparece',pg.evaluate("window.__n")==0 and pg.locator('#intro').count()==0)
    pg.reload();pg.wait_for_timeout(700);pg.reload();pg.wait_for_timeout(700);ok('Recarregar a página (duas vezes) NÃO repete a intro: ela é uma vez por sessão',pg.locator('#intro').count()==0)
    pg2=page(c);pg2.goto(HTTP_URL,wait_until='commit');pg2.wait_for_selector('#intro .ib img',timeout=4000);ok('Ao abrir em uma NOVA janela/aba (nova sessão, como fechar e abrir o app de novo) a intro aparece',pg2.locator('#intro').count()==1)
    pg2.reload();pg2.wait_for_timeout(300);ok('Recarregar no meio da intro também não a reinicia',pg2.locator('#intro').count()==0);c.close()
    # navegador que não permite sessionStorage (modo restrito): a intro simplesmente toca, sem erro
    c=ctx(spy=False);c.add_init_script("Object.defineProperty(window,'sessionStorage',{get(){throw new Error('bloqueado')}})");pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img',timeout=4000);pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    ok('Sem sessionStorage (modo restrito): a intro toca normalmente e o app abre sem erros',not pg.errs and pg.locator('#lock [data-lk=new]').is_visible(),pg.errs[:2]);c.close()
    # ===== G) prefers-reduced-motion =====
    c=ctx(reduce=True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.wait_for_timeout(120)
    s=pg.evaluate("({anim:document.getAnimations().filter(a=>a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#intro')).length,ops:['.ib','.in','.is'].map(s=>+getComputedStyle(document.querySelector('#intro '+s)).opacity),ears:getComputedStyle(document.querySelector('#intro .ie')).display,sw:getComputedStyle(document.querySelector('#intro .sw')).display})")
    pg.wait_for_function("window.__i&&window.__i.gone",timeout=5000);dur=pg.evaluate("window.__i.gone-window.__i.seen")
    ok('Movimento reduzido: entrada estática (sem animações, tudo já visível, sem orelhas/reflexo) e some em menos de 1 s',s['anim']==0 and all(o==1 for o in s['ops']) and s['ears']=='none' and s['sw']=='none' and dur<1000,(s,round(dur)));c.close()
    # ===== H) responsividade =====
    bad=[]
    for (w,h) in ((320,568),(360,740),(393,851),(412,915),(851,393),(1280,800)):
        c=ctx(w,h);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');pg.evaluate(PAUSE,1100);pg.wait_for_timeout(120)
        g=pg.evaluate("(()=>{const r=s=>document.querySelector(s).getBoundingClientRect(),l=r('#intro .ib'),n=r('#intro .in'),s=r('#intro .is'),W=innerWidth,H=innerHeight;return {cx:l.left+l.width/2,W,H,lw:l.width,lh:l.height,top:l.top,bot:s.bottom,ncx:n.left+n.width/2,sw:s.width,sl:s.left,sr:s.right,nl:n.left,nr:n.right,sx:document.documentElement.scrollWidth,sy:document.documentElement.scrollHeight}})()")
        mid=(g['top']+g['bot'])/2
        if not(abs(g['cx']-g['W']/2)<=1.5 and abs(g['ncx']-g['W']/2)<=1.5 and abs(g['lw']-g['lh'])<=0.6 and 0.38*g['H']<=mid<=0.56*g['H'] and g['top']>=0 and g['bot']<=g['H'] and g['nl']>=0 and g['nr']<=g['W'] and g['sl']>=0 and g['sr']<=g['W'] and g['sx']<=g['W']):bad.append((w,h,g))
        c.close()
    ok('Responsivo (320, 360, 393, 412 px, paisagem 851×393 e 1280×800): logo e textos centralizados, proporção 1:1 da logo preservada, nada cortado e sem barra de rolagem',not bad,bad[:1])
    # ===== I) offline / PWA =====
    c=ctx(sw=True);pg=page(c);pg.goto(HTTP_URL);pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    pg.wait_for_function("navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))",timeout=15000);pg.reload();pg.wait_for_function("!!navigator.serviceWorker.controller",timeout=15000)
    pg.wait_for_function("caches.keys().then(async ks=>{for(const k of ks){const c=await caches.open(k);if(await c.match('icon-512.png'))return true}return false})",timeout=15000);pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    c.set_offline(True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img',timeout=8000);pg.wait_for_timeout(300)
    li=pg.evaluate("(()=>{const i=document.querySelector('#intro .ib img');return {w:i.naturalWidth,done:i.complete,online:navigator.onLine}})()")
    pg.wait_for_function("!document.getElementById('intro')",timeout=6000);pg.wait_for_selector('#lock [data-lk=new], #lock #lf',timeout=8000)
    ok('Offline (PWA com Service Worker): a intro aparece com a logo vinda do cache (512 px), termina e o app abre normalmente sem internet',li['w']==512 and li['done'] and not li['online'] and not pg.errs,(li,pg.errs[:2]));c.close()
    # ===== J) não mexe em dados, nem causa mudança de layout =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro .ib img');h1=pg.evaluate("document.documentElement.scrollHeight");pg.wait_for_function("!document.getElementById('intro')",timeout=6000);h2=pg.evaluate("document.documentElement.scrollHeight")
    keys=pg.evaluate("Object.keys(localStorage).concat(Object.keys(sessionStorage))")
    ok('A intro só guarda a marca da sessão (sessionStorage "wolfin.intro", some ao fechar a aba/app): nada no armazenamento permanente, e o layout não muda (mesma altura da página antes e depois)',keys.count('wolfin.intro')==1 and h1==h2 and not pg.evaluate("Object.keys(localStorage).some(k=>k.toLowerCase().includes('intro'))"),(keys,h1,h2));c.close()
    # ===== K) fluidez =====
    c=ctx();pg=page(c);pg.add_init_script("window.__f=[];(function loop(t){window.__f.push(performance.now());if(!window.__stop)requestAnimationFrame(loop)})(0)") if False else None
    pg.goto(HTTP_URL,wait_until='commit');pg.evaluate("window.__f=[];(function l(){window.__f.push(performance.now());if(document.getElementById('intro'))requestAnimationFrame(l)})()");pg.wait_for_function("!document.getElementById('intro')",timeout=6000)
    fr=pg.evaluate("window.__f");gaps=[fr[i+1]-fr[i] for i in range(len(fr)-1)]
    ok('Fluidez: quadros regulares durante a intro (mediana ≤ 34 ms e nenhum travamento acima de 250 ms)',len(gaps)>=15 and statistics.median(gaps)<=34 and max(gaps)<=250,(len(gaps),round(statistics.median(gaps),1),round(max(gaps))));c.close()
    # ===== L) intro em vídeo (arquivo enviado pelo dono do app; convertido para 720×1280, 30 fps, sem áudio) =====
    import shutil,subprocess
    mp4=os.path.join(ROOT,'intro-wolfin.mp4');webm=os.path.join(ROOT,'intro-wolfin.webm')
    d4=open(mp4,'rb').read(12);dw=open(webm,'rb').read(4)
    meta=''
    if shutil.which('ffprobe'):
        def probe(f,sel):return subprocess.run(['ffprobe','-v','error','-select_streams',sel,'-show_entries','stream=codec_name,width,height,r_frame_rate','-of','csv=p=0',f],capture_output=True,text=True).stdout.strip()
        meta=(probe(mp4,'v:0'),probe(mp4,'a'),probe(webm,'a'),probe(webm,'v:0'))
        meta_ok=meta[0].startswith('h264,720,1280,30/1') and meta[1].startswith('aac') and meta[2].startswith('opus') and meta[3].startswith('vp9,720,1280')
    else:meta_ok=True
    ok('Arquivos do vídeo da intro: MP4 (H.264) e WebM (VP9), leves (cada um < 1,5 MB), 720×1280, 30 fps e COM o áudio original (AAC no MP4, Opus no WebM)',d4[4:8]==b'ftyp' and dw==b'\x1aE\xdf\xa3' and os.path.getsize(mp4)<1_500_000 and os.path.getsize(webm)<1_500_000 and meta_ok,(os.path.getsize(mp4),os.path.getsize(webm),meta))
    reqs=[]
    c=ctx(video=True,br=ba);pg=page(c);pg.on('request',lambda r:reqs.append(r.url.split('/')[-1]) if 'intro-wolfin' in r.url else None);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro.v #introv',timeout=4000)
    pg.wait_for_function("(()=>{const v=document.getElementById('introv');return v&&v.currentTime>1.4})()",timeout=12000)
    q=pg.evaluate("""async()=>{const v=document.getElementById('introv');const h=()=>{const c=document.createElement('canvas');c.width=36;c.height=64;const x=c.getContext('2d');x.drawImage(v,0,0,36,64);const d=x.getImageData(0,0,36,64).data;let s=0;for(let i=0;i<d.length;i+=4)s+=d[i]+d[i+1]*3+d[i+2]*7;return s};const a=h();await new Promise(r=>setTimeout(r,900));const b=h();const q=v.getVideoPlaybackQuality();return {cls:document.getElementById('intro').className,src:v.currentSrc.split('/').pop(),vw:v.videoWidth,vh:v.videoHeight,dur:v.duration,muted:v.muted,paused:v.paused,frames:q.totalVideoFrames,changed:a!==b,audio:v.webkitAudioDecodedByteCount,rect:(r=>[r.x,r.y,r.width,r.height])(v.getBoundingClientRect()),W:innerWidth,H:innerHeight}}""")
    ok('Retrato: a intro toca o VÍDEO (720×1280, 6,17 s), cobrindo a tela toda, com quadros novos a cada instante (o conteúdo muda)',q['cls'].split()[0]=='v' and q['src'] in('intro-wolfin.mp4','intro-wolfin.webm') and q['vw']==720 and q['vh']==1280 and abs(q['dur']-6.17)<0.1 and not q['paused'] and q['frames']>=35 and q['changed'] and q['rect']==[0,0,q['W'],q['H']],q)
    ok('Com som: quando o navegador permite, o vídeo toca COM áudio (não está mudo, o áudio é decodificado) e o botão "ativar som" não aparece',(not q['muted']) and (q.get('audio') or 0)>0 and 'm' not in q['cls'].split() and not pg.locator('#introsnd').is_visible(),(q['muted'],q.get('audio'),q['cls']))
    ok('Só um dos arquivos de vídeo é baixado (o formato que o aparelho consegue tocar), e só quando a intro é em vídeo',len(set(x.split('?')[0] for x in reqs))==1,reqs[:4])
    # margem do texto no último quadro do vídeo: o recorte lateral (object-fit: cover) em cada proporção de tela não pode cortar WOLFIN
    pg.wait_for_function("(()=>{const v=document.getElementById('introv');return v&&v.currentTime>=5.75})()",timeout=12000)
    bbx=pg.evaluate("""()=>{const v=document.getElementById('introv'),c=document.createElement('canvas');c.width=360;c.height=640;const x=c.getContext('2d');x.drawImage(v,0,0,360,640);const d=x.getImageData(0,0,360,640).data;let x0=1e9,x1=-1;for(let y=Math.floor(640*.56);y<Math.floor(640*.72);y++)for(let i=0;i<360;i++){const k=(y*360+i)*4;if(d[k]>232&&d[k+1]>232&&d[k+2]>232){if(i<x0)x0=i;if(i>x1)x1=i}}return [x0/360,x1/360]}""")
    pg.wait_for_function("!document.getElementById('intro')",timeout=9000);i=pg.evaluate("window.__i");dur=(i['gone']-i['seen'])/1000
    ok('Fim do vídeo: a intro some com fade logo depois do último quadro (≈ 6,2 s do vídeo + ~0,5 s de fade) e revela o app',6.0<=dur<=8.8 and pg.locator('#lock [data-lk=new]').is_visible() and not pg.errs,(round(dur,2),pg.errs[:2]));c.close()
    bad=[]
    for (w,h) in ((320,640),(360,740),(393,851),(393,873),(412,915),(393,900)):
        ar=w/h;vis=min(1,ar/0.5625);m=(1-vis)/2
        if ar>=0.43 and not(bbx[0]-m>=0.005 and (1-bbx[1])-m>=0.005):bad.append((w,h,round(m,3),bbx))
    ok('Recorte lateral (cover) não corta o nome WOLFIN em telas de 320×640 a 393×900 (proporções de 0,44 a 0,5); abaixo de 0,43 usa "contain"',not bad and 'c' in 'v c',(bbx,bad))
    c=ctx(video=True,br=bb);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro.v #introv',timeout=4000);pg.wait_for_function("(()=>{const v=document.getElementById('introv');return v&&v.currentTime>0.6})()",timeout=12000)
    m1=pg.evaluate("(()=>{const v=document.getElementById('introv'),b=document.getElementById('introsnd'),r=b.getBoundingClientRect();return {muted:v.muted,paused:v.paused,cls:document.getElementById('intro').className,vis:getComputedStyle(b).display,txt:b.textContent,h:r.height,inView:r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth}})()")
    ok('Som bloqueado pelo navegador (política padrão): o vídeo toca mudo e aparece o botão "Toque para ativar o som" (44 px, dentro da tela)',m1['muted'] and not m1['paused'] and 'm' in m1['cls'].split() and m1['vis']=='block' and m1['txt']=='Toque para ativar o som' and m1['h']>=44 and m1['inView'],m1)
    pg.click('#introsnd');pg.wait_for_timeout(1200)
    m2=pg.evaluate("(()=>{const v=document.getElementById('introv');return {present:!!document.getElementById('intro'),muted:v.muted,paused:v.paused,audio:v.webkitAudioDecodedByteCount,cls:document.getElementById('intro').className}})()")
    ok('Tocar em "ativar o som" liga o áudio na hora, SEM pular a intro, e o botão some',m2['present'] and not m2['muted'] and not m2['paused'] and (m2['audio'] or 0)>0 and 'm' not in m2['cls'].split(),m2);c.close()
    # pular com toque durante o vídeo
    c=ctx(video=True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_function("(()=>{const v=document.getElementById('introv');return v&&v.currentTime>0.8})()",timeout=12000);t0=pg.evaluate("performance.now()");pg.mouse.click(196,425);pg.wait_for_function("!document.getElementById('intro')",timeout=3000);sk=pg.evaluate("performance.now()")-t0
    ok('Toque durante o vídeo pula na hora (some em menos de 0,6 s) e o app fica utilizável',sk<600 and pg.locator('#lock [data-lk=new]').is_visible(),round(sk));c.close()
    # tela larga: intro em CSS, sem baixar o vídeo
    reqs=[];c=ctx(851,393,video=True);pg=page(c);pg.on('request',lambda r:reqs.append(r.url) if 'intro-wolfin' in r.url else None);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro',timeout=4000);st=pg.evaluate("({cls:document.getElementById('intro').className,src:document.getElementById('introv').getAttribute('src')})")
    pg.wait_for_function("!document.getElementById('intro')",timeout=6000);ok('Tela larga (paisagem/PC): usa a intro em CSS (sem baixar o vídeo)',st['cls']=='' and not st['src'] and not reqs,(st,reqs));c.close()
    # movimento reduzido: sem vídeo
    reqs=[];c=ctx(reduce=True,video=True);pg=page(c);pg.on('request',lambda r:reqs.append(r.url) if 'intro-wolfin' in r.url else None);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro',timeout=4000);pg.wait_for_timeout(300)
    st=pg.evaluate("({cls:document.getElementById('intro').className,vid:getComputedStyle(document.getElementById('introv')).display})");pg.wait_for_function("!document.getElementById('intro')",timeout=4000)
    ok('Movimento reduzido: nada de vídeo (entrada estática em CSS, sem baixar o arquivo)',st['cls']=='' and st['vid']=='none' and not reqs,(st,reqs));c.close()
    # vídeo indisponível (bloqueado/erro de rede): volta para a intro em CSS sem erro
    c=ctx(video=True);pg=page(c);c.route('**/intro-wolfin.*',lambda r:r.abort());pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro',timeout=4000);pg.wait_for_timeout(1000)
    st=pg.evaluate("({cls:document.getElementById('intro')&&document.getElementById('intro').className,nome:!!document.querySelector('#intro .in')&&getComputedStyle(document.querySelector('#intro .in')).display})");pg.wait_for_function("!document.getElementById('intro')",timeout=7000)
    ok('Vídeo indisponível: volta sozinho para a intro em CSS (logo, nome e slogan) e termina sem erros',st['cls']=='' and st['nome']!='none' and not pg.errs,(st,pg.errs[:2]));c.close()
    # offline (PWA): vídeo guardado inteiro pelo Service Worker e servido em trechos (206)
    resp=[];c=ctx(sw=True,video=True);pg=page(c);pg.on('response',lambda r:resp.append((r.status,r.from_service_worker,r.headers.get('content-range','')[:30])) if 'intro-wolfin' in r.url else None)
    pg.goto(HTTP_URL);pg.wait_for_function("navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))",timeout=15000);pg.reload();pg.wait_for_function("!!navigator.serviceWorker.controller",timeout=15000)
    pg.wait_for_function("caches.keys().then(async ks=>{for(const k of ks){const c=await caches.open(k);if((await c.keys()).some(r=>/intro-wolfin\\.(mp4|webm)$/.test(r.url)))return true}return false})",timeout=20000)
    pg.wait_for_function("!document.getElementById('intro')",timeout=12000)
    resp.clear();c.set_offline(True);pg=page(c);pg.on('response',lambda r:resp.append((r.status,r.from_service_worker,r.headers.get('content-range','')[:30])) if 'intro-wolfin' in r.url else None);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#intro.v #introv',timeout=6000);pg.wait_for_function("(()=>{const v=document.getElementById('introv');return v&&v.currentTime>1.2&&v.getVideoPlaybackQuality().totalVideoFrames>25})()",timeout=12000)
    off=pg.evaluate("({cls:document.getElementById('intro').className,online:navigator.onLine,paused:document.getElementById('introv').paused,vw:document.getElementById('introv').videoWidth})");pg.wait_for_function("!document.getElementById('intro')",timeout=12000)
    ok('Offline (PWA): numa nova abertura sem internet, a intro em VÍDEO (com som) toca a partir do cache do Service Worker (respostas 206 de trecho), sem erros',off['cls'].split()[0]=='v' and not off['online'] and not off['paused'] and off['vw']==720 and any(r[0]==206 and r[1] for r in resp) and not pg.errs,(off,resp[:3],pg.errs[:2]));c.close()
print(sum(R),'/',len(R))
