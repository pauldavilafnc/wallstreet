import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json
pass
from playwright.sync_api import sync_playwright
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:220] if d else ''))
with sync_playwright() as p:
    b=p.chromium.launch()
    def new(w=393,h=851,reduce=False):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=w<600,reduced_motion='reduce' if reduce else 'no-preference');pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return c,pg
    th=lambda pg:pg.evaluate("document.documentElement.dataset.theme")
    # ===== sol/lua =====
    c,pg=new();pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(300)
    r=pg.evaluate("(()=>{const b=document.querySelector('.lkth'),r=b.getBoundingClientRect();return{n:document.querySelectorAll('.lkth').length,right:innerWidth-r.right,top:r.top,w:r.width,h:r.height,label:b.getAttribute('aria-label'),pos:getComputedStyle(b).position}})()")
    ok('Boas-vindas: botão de sol/lua no canto superior direito (fixo, ≥ 44px, com rótulo acessível)',r['n']==1 and r['right']<=20 and r['top']<=24 and r['w']>=44 and r['h']>=44 and 'tema' in r['label'] and r['pos']=='fixed',r)
    ok('Começa no tema claro e mostra a lua (para ir ao escuro)',th(pg)=='light' and float(pg.evaluate("getComputedStyle(document.querySelector('.lkth .mn')).opacity"))>.9 and float(pg.evaluate("getComputedStyle(document.querySelector('.lkth .sn')).opacity"))<.1)
    pg.click('.lkth');pg.wait_for_timeout(500)
    ok('Tocar troca para o tema escuro e o ícone vira sol',th(pg)=='dark' and float(pg.evaluate("getComputedStyle(document.querySelector('.lkth .sn')).opacity"))>.9 and pg.evaluate("S.pref.theme")=='dark')
    ok('O tema escuro vale para a própria tela (fundo escuro)',pg.evaluate("(()=>{const c=getComputedStyle(document.getElementById('lock')).backgroundColor.match(/\\d+/g).map(Number);return c[0]+c[1]+c[2]<300})()"))
    pg.click('.lkth');pg.wait_for_timeout(300);ok('Tocar de novo volta ao claro',th(pg)=='light')
    pg.click('.lkth');OB_TO_NAME(pg);ok('O botão também aparece nas outras telas de bloqueio (nome) e o tema escolhido continua',pg.locator('.lkth').count()==1 and th(pg)=='dark')
    pg.fill('#nf [name=n]','Ana');pg.click('#nf button');pg.wait_for_selector('#sf');pg.click('[data-lk=nosec]');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(300)
    ok('Ao entrar no app, o tema escolhido na tela de boas-vindas fica salvo (escuro)',th(pg)=='dark' and pg.evaluate("S.pref.theme")=='dark' and 'dark' in pg.evaluate("localStorage.getItem('wallstreet.v1')"))
    ok('No site (dentro do app) NÃO há botão de sol/lua: o tema só se muda em Ajustes',pg.locator('.lkth').count()==0)
    pg.click('#nav button[data-id=cfg]');ok('Ajustes continua com os botões Claro/Escuro',pg.locator('#s-cfg [data-act=theme][data-id=light],#s-cfg [data-act=theme][data-id=dark]').count()>=0 and 'Escuro' in pg.inner_text('#s-cfg') and 'Claro' in pg.inner_text('#s-cfg'))
    ok('Sem erros no console (sol/lua)',not pg.errs,pg.errs);c.close()
    # ===== login com senha: o tema escolhido na tela de login é guardado =====
    c,pg=new();pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_TO_SETUP(pg,'Paul');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=15000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    pg.reload();pg.wait_for_selector('#lf');ok('Login: botão de sol/lua presente (tema claro)',pg.locator('.lkth').count()==1 and th(pg)=='light')
    pg.click('.lkth');pg.wait_for_timeout(300);ok('Login: tocar muda para escuro na hora',th(pg)=='dark')
    pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(500)
    ok('Depois de entrar: o app abre no tema escolhido no login, e isso fica salvo',th(pg)=='dark' and pg.evaluate("S.pref.theme")=='dark')
    pg.reload();pg.wait_for_selector('#lf');ok('Ao reabrir, a tela de login já aparece escura',th(pg)=='dark');c.close()
    # ===== olho da senha =====
    for (w,h) in ((320,568),(393,851),(851,393)):
        c,pg=new(w,h);pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_TO_SETUP(pg,'Ana');pg.wait_for_selector('#sf')
        g=pg.evaluate("(()=>{const i=document.querySelector('#sf [name=p]'),b=document.querySelector('#sf .eyl'),ri=i.getBoundingClientRect(),rb=b.getBoundingClientRect();return{dy:Math.abs((ri.top+ri.height/2)-(rb.top+rb.height/2)),inside:rb.left>=ri.left&&rb.right<=ri.right&&rb.top>=ri.top&&rb.bottom<=ri.bottom,gapR:ri.right-rb.right,w:rb.width,h:rb.height,pad:parseFloat(getComputedStyle(i).paddingRight)}})()")
        ok(f'{w}x{h}: o olho está alinhado ao centro do campo (diferença ≤ 1px), dentro do campo, com alvo ≥ 40px e sem cobrir o texto',g['dy']<=1 and g['inside'] and g['w']>=40 and g['h']>=40 and g['pad']>=g['w']+g['gapR']+4,g);c.close()
    c,pg=new();pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_TO_SETUP(pg,'Ana');pg.wait_for_selector('#sf')
    eye="#sf .eyl";cs=lambda sel,prop:pg.evaluate(f"getComputedStyle(document.querySelector('{sel}')).{prop}")
    ok('Senha oculta: olho fechado (pálpebra com cílios), sem íris',not pg.evaluate("document.querySelector('#sf .eyl').classList.contains('on')") and float(cs('#sf .eyl .ec','opacity'))>.9 and float(cs('#sf .eyl .eo','opacity'))<.1 and pg.evaluate("document.querySelector('#sf .eyl').getAttribute('aria-pressed')")=='false' and cs('#sf .eyl .pp','animationName')=='none')
    pg.click(eye);pg.wait_for_timeout(400);ok('Senha visível: olho abre (íris, pupila e brilho), e o campo mostra o texto',pg.evaluate("document.querySelector('#sf .eyl').classList.contains('on')") and float(cs('#sf .eyl .eo','opacity'))>.9 and float(cs('#sf .eyl .ec','opacity'))<.1 and pg.evaluate("document.querySelector('#sf [name=p]').type")=='text' and pg.evaluate("document.querySelector('#sf .eyl').getAttribute('aria-pressed')")=='true')
    tx=[]
    for i in range(14):
        tx.append(float(pg.evaluate("getComputedStyle(document.querySelector('#sf .eyl .pp')).transform").replace('matrix(','').split(',')[4]) if pg.evaluate("getComputedStyle(document.querySelector('#sf .eyl .pp')).transform")!='none' else 0.0);pg.wait_for_timeout(300)
    ok('Olho aberto olha de um lado para o outro (a pupila vai à esquerda e à direita, até ±3,4px)',cs('#sf .eyl .pp','animationName')=='eyelook' and min(tx)<=-2.5 and max(tx)>=2.5 and min(tx)>=-3.6 and max(tx)<=3.6,(round(min(tx),1),round(max(tx),1)))
    pg.click(eye);pg.wait_for_timeout(400);ok('Ocultando de novo: fecha o olho e para a animação',not pg.evaluate("document.querySelector('#sf .eyl').classList.contains('on')") and cs('#sf .eyl .pp','animationName')=='none' and pg.evaluate("document.querySelector('#sf [name=p]').type")=='password')
    c0=cs('#sf .eyl','color');pg.evaluate("S.pref.pal='pink';applyPref()");pg.wait_for_timeout(200);c1=cs('#sf .eyl','color')
    ok('O olho segue a identidade visual: a cor acompanha a paleta escolhida',c0!=c1,(c0,c1))
    ok('Design de vidro: fundo em degradê translúcido, borda suave, cantos arredondados e sombra',pg.evaluate("(()=>{const cs=getComputedStyle(document.querySelector('#sf .eyl'));return cs.backgroundImage.includes('gradient')&&parseFloat(cs.borderTopLeftRadius)>=12&&cs.boxShadow!=='none'})()"))
    ok('Sem erros no console (olho)',not pg.errs,pg.errs);c.close()
    c,pg=new(reduce=True);pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_TO_SETUP(pg,'Ana');pg.wait_for_selector('#sf');pg.click('#sf .eyl');pg.wait_for_timeout(300)
    ok('"Reduzir movimento": o olho abre, mas sem animação',pg.evaluate("document.querySelector('#sf .eyl').classList.contains('on')") and pg.evaluate("getComputedStyle(document.querySelector('#sf .eyl .pp')).animationName")=='none');c.close()
print(sum(R),'/',len(R))
