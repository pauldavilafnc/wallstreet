"""Correções da auditoria final (versão 7.1): parcela paga desconta do saldo (e aviso único para contas antigas), rótulos esclarecidos,
reaproveitamento de cálculos só dentro de cada desenho de tela, senha forte no backup, pedido de armazenamento persistente,
workflows (Node 24, notícias sem corrida) e política de conteúdo (verificação estática)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
DATA=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
BASE="""{owner:'T',opening:{c:100000,d:'2026-01-01'},items:[],inst:[{id:'n1',n:'Celular',c:null,np:3,day:5,paid:false}],parc:[{id:'q1',iid:'n1',ym:'2026-10',c:20000,paid:false},{id:'q2',iid:'n1',ym:'2026-11',c:20000,paid:false},{id:'q3',iid:'n1',ym:'2026-12',c:20000,paid:false}],debts:[],boxes:[],cards:[],pref:S.pref,flags:{tour:1}}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(hook=True,persist_spy=False):
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo')
        if hook:c.add_init_script("window.__WS_NOTOUR=1")
        else:c.add_init_script("sessionStorage.setItem('wolfin.intro','1')")
        if persist_spy:c.add_init_script("try{navigator.storage.persist=()=>{window.__persist=(window.__persist||0)+1;return Promise.resolve(true)}}catch(e){}")
        return c
    def app(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500);return pg
    ev=lambda pg,js,*a:pg.evaluate(js,*a) if a else pg.evaluate(js)
    # ===== A) parcela paga desconta do saldo =====
    c=ctx();pg=app(c);ev(pg,"S=migrate("+BASE+");save();render()")
    b0=ev(pg,"balance()");ev(pg,"ACT.tgp('q1')");pg.wait_for_timeout(300)
    s=ev(pg,"({b:balance(),paidOn:S.parc[0].paidOn,exp:relFlow('2026-11').exp,txt:document.querySelector('#s-home .hero').innerText})")
    ok('Marcar uma parcela como paga desconta o valor do saldo disponível (R$ 1.000,00 → R$ 800,00) e registra a data do pagamento',b0==100000 and s['b']==80000 and s['paidOn']=='2026-11-15' and s['exp']==20000 and 'R$ 800,00' in s['txt'],s)
    ev(pg,"ACT.tgp('q1')");pg.wait_for_timeout(200);s=ev(pg,"({b:balance(),paidOn:S.parc[0].paidOn})")
    ok('Desmarcar a parcela devolve o valor ao saldo e apaga a data do pagamento',s['b']==100000 and s['paidOn'] is None,s)
    ev(pg,"ACT.tgp('q2');ACT.tgp('q3')");pg.wait_for_timeout(250)
    ok('Pagar duas parcelas seguidas desconta as duas (sem duplicar nem perder): saldo R$ 600,00',ev(pg,"balance()")==60000 and ev(pg,"flows()['2026-11'].exp")==40000)
    t=ev(pg,"(()=>{rpm='2026-11';render();view='rel';render();return document.getElementById('s-rel').innerText})()")
    ok('Relatórios: "Despesas pagas" inclui as parcelas e o resumo diz quanto são parcelas pagas no mês',('R$ 400,00' in t) and 'Inclui R$ 400,00 de parcelas pagas neste mês' in t,re.findall(r'Inclui[^.]*\.',t)[:1])
    ev(pg,"S.parc[0].paid=true;delete S.parc[0].paidOn;S.parc[0].due='2026-09-10';S.parc[1].paid=true;delete S.parc[1].paidOn;delete S.parc[1].due;S.parc[2].paid=true;delete S.parc[2].paidOn;delete S.parc[2].due;save();render()")
    ok('Dados antigos (parcela paga sem data de pagamento): usa o vencimento e, sem ele, o mês da parcela; o saldo total desconta tudo',ev(pg,"relFlow('2026-09').exp")==20000 and ev(pg,"relFlow('2026-11').exp")==20000 and ev(pg,"relFlow('2026-12').exp")==20000 and ev(pg,"balance()")==40000)
    ok('Console sem erros (parcelas)',not pg.errs,pg.errs[:2]);c.close()
    # ===== B) aviso único + armazenamento persistente (sem o gancho de teste) =====
    c=ctx(hook=False,persist_spy=True);pg=app(c)
    ok('Conta nova: não aparece aviso (não há parcelas pagas) e o marcador da atualização é gravado em silêncio',ev(pg,"!!S.flags.pqv")==True and ev(pg,"document.getElementById('toast').textContent").find('Atualização')<0)
    ok('O app pede ao navegador armazenamento persistente (uma vez) ao abrir, sem erros',ev(pg,"window.__persist||0")==1 and not pg.errs,(ev(pg,"window.__persist||0"),pg.errs[:1]))
    ev(pg,"S=migrate("+BASE+");S.parc[0].paid=true;S.flags={};save();render()");pg.wait_for_timeout(1500)
    tx=ev(pg,"document.getElementById('toast').textContent")
    ok('Conta antiga com parcelas pagas: aparece UM aviso explicando que agora elas descontam do saldo, com o valor (R$ 200,00)','Atualização: parcelas pagas agora são descontadas do saldo (R$ 200,00)' in tx,tx)
    ok('O marcador é gravado (o aviso não se repete)',bool(ev(pg,"S.flags.pqv")) and bool(ev(pg,"JSON.parse(localStorage.getItem('wallstreet.v1')).flags.pqv")))
    pg.reload();pg.wait_for_selector('#nav');pg.wait_for_timeout(1800)
    ok('Depois de recarregar, o aviso NÃO volta',ev(pg,"document.getElementById('toast').textContent").find('Atualização')<0);c.close()
    # ===== C) rótulos =====
    c=ctx();pg=app(c);ev(pg,"S=migrate("+DATA+");S.flags={tour:1};save();render()")
    lab=ev(pg,"(()=>{go('home');const h=[...document.querySelectorAll('#s-home svg[aria-label]')].map(s=>s.getAttribute('aria-label')).join(' | ');go('des');const d=document.getElementById('s-des').innerText;go('rel');const r=document.getElementById('s-rel').innerText;return {h,d:d.includes('Pagas (sem faturas de cartão)'),r:r.includes('Resultado do mês (após dívidas e caixinhas)')}})()")
    ok('Rótulos esclarecidos: Home "Receitas / Despesas / Diferença" (não mais "Saldo"), Despesas "Pagas (sem faturas de cartão)", Relatórios "Resultado do mês (após dívidas e caixinhas)"','Diferença' in lab['h'] and 'Saldo' not in lab['h'].split('Este')[0] and lab['d'] and lab['r'],lab)
    # ===== D) reaproveitamento de cálculos só dentro de um desenho =====
    r=ev(pg,"""()=>{const k=()=>JSON.stringify([relFlow('2026-11'),relCommit('2026-11'),finSit().m,catSpend('2026-11'),flows()]);const a=k();view='rel';render();const memoDepois=MEMO;const b=k();S.items.push({id:'zz',t:'inc',d:'Extra',c:12300,day:1,fixed:false,ym:'2026-11',done:{'2026-11':12300},cat:'Outros'});const c1=k();S.items.pop();const d=k();return {iguais:a===b,limpo:memoDepois===null,mudou:a!==c1,voltou:a===d}}""")
    ok('Reaproveitamento seguro: os resultados são idênticos aos cálculos diretos, nada fica guardado depois do desenho da tela e uma alteração nos dados aparece na hora',r['iguais'] and r['limpo'] and r['mudou'] and r['voltou'],r)
    # ===== E) senha do backup criptografado: mesma regra forte =====
    ev(pg,"go('cfg')");pg.wait_for_timeout(300);pg.click('#s-cfg [data-act=expenc]');pg.wait_for_selector('#f');res={}
    for pw_,fr in (('curta','10 caracteres'),('senha12345','muito comum'),('1234567890','Só números')):
        pg.fill('#f [name=p]',pw_);pg.fill('#f [name=c]',pw_);pg.click('#f button[type=submit]');pg.wait_for_timeout(300);res[pw_]=pg.inner_text('#f .err') if pg.locator('#f .err').count() else pg.inner_text('#f')
    ok('Backup criptografado recusa senha curta, comum ou só numérica (mesma regra da conta)',all(fr in res[k] for k,fr in (('curta','10 caracteres'),('senha12345','muito comum'),('1234567890','Só números'))),{k:v[-90:] for k,v in res.items()});c.close()
    # ===== F) workflows =====
    wf=lambda n:open(os.path.join(ROOT,'.github','workflows',n),encoding='utf-8').read()
    nt,ts=wf('noticias.yml'),wf('tests.yml');MIN={'checkout':6,'setup-python':6,'setup-node':6,'upload-artifact':7};old=[]
    for txt in (nt,ts):
        for m in re.finditer(r'uses:\s*actions/([\w-]+)@v(\d+)',txt):
            if int(m.group(2))<MIN.get(m.group(1),0):old.append(m.group(0))
    ok('Workflows: todas as ações do GitHub usam versões com Node 24 nativo (sem aviso de Node 20)',not old,old)
    ok('Workflow de notícias: servidor fixo, execução única por vez, limite de tempo e envio com reconciliação e repetição (sem corrida com seus envios)','ubuntu-24.04' in nt and 'concurrency:' in nt and 'timeout-minutes' in nt and 'git pull --rebase' in nt and 'for i in 1 2 3 4' in nt and '[ "$ok" = 1 ]' in nt)
    ok('Workflow de testes: servidor fixo, fonte de referência instalada, upload de logs não reprova (continue-on-error)','ubuntu-24.04' in ts and 'fonts-inter' in ts and 'continue-on-error: true' in ts)
    # ===== G) política de conteúdo e referrer (estático) =====
    h=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
    ok('HTML tem referrer "no-referrer" e a política de conteúdo (CSP): rede só para o próprio site, sem plugins, sem <base>, formulários só para o próprio site, e nunca no modo de testes','name="referrer" content="no-referrer"' in h and all(x in h for x in ("connect-src 'self'","object-src 'none'","base-uri 'none'","form-action 'self'","img-src 'self' data: blob:","media-src 'self' blob:")) and '!window.__WS_NOTOUR&&' in h)
print(sum(R),'/',len(R))
