import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re
pass
from playwright.sync_api import sync_playwright
from contrast import measure
URL=FILE_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:230] if d else ''))
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
LEG=open(FIX+'/legacy_seed.js',encoding='utf-8').read()
css=re.search(r'<style>(.*?)</style>',open(ROOT+'/index.html',encoding='utf-8').read(),re.S).group(1)
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,reduce=False,touch=True):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=touch,timezone_id='America/Sao_Paulo',reduced_motion='reduce' if reduce else 'no-preference');pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return c,pg
    def app(w=393,h=851,th='light',reduce=False,seed=True):
        c,pg=ctx(w,h,reduce);pg.goto(URL);OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500)
        if seed:pg.evaluate("(()=>{"+LEG+";const o=legacySeed();o.pref=S.pref;o.owner=S.owner;S=o;migrate(S);S.pref.ma=0;S.pref.ms='terno';S.pref.theme='"+th+"';save();render()})()")
        pg.wait_for_timeout(900);return c,pg
    ev=lambda pg,js:pg.evaluate(js)
    # ===== boas-vindas: entrada em sequência =====
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]')
    r=ev(pg,"(()=>{const k=[...document.querySelectorAll('#lock .lk>*')],an=k.map(e=>e.getAnimations().length),d=k.map(e=>parseFloat(getComputedStyle(e).animationDelay));return{n:k.length,animated:an.filter(x=>x>0).length,delays:d,names:k.map(e=>getComputedStyle(e).animationName),lock:getComputedStyle(document.getElementById('lock')).animationName}})()")
    ok('Boas-vindas: o painel entra em sequência (lobo, título, texto e botões aparecem um depois do outro, com atrasos crescentes)',r['n']>=5 and r['animated']>=5 and r['delays']==sorted(r['delays']) and r['delays'][-1]>=.2 and r['names'][0]=='mcfade' and 'lkrise' in r['names'],r)
    ok('O fundo da tela de bloqueio entra com um fade suave',r['lock']=='vfade')
    pg.wait_for_timeout(1500);ok('Depois de entrar, nada continua animando no painel (as animações terminam sozinhas)',ev(pg,"[...document.querySelectorAll('#lock .lk,#lock .lk>*')].every(e=>e.getAnimations().filter(a=>a.playState==='running'&&!e.closest('.wolf')).length===0)"))
    pg.click('#mf .mcrow >> nth=0');pg.click('#mgo');pg.wait_for_selector('#cf');n1=ev(pg,"[...document.querySelectorAll('#lock .lk>*')].filter(e=>e.getAnimations().length>0).length")
    ok('Transição entre as telas de entrada (mascote → aparência → boas-vindas → nome → senha): cada passo entra com a mesma animação suave',n1>=4,n1)
    pg.click('#cf button:not([type=button])');pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=new]');pg.wait_for_selector('#nf');pg.fill('#nf [name=n]','Ana');pg.click('#nf button:not([type=button])');pg.wait_for_selector('#sf');ok('...e o passo seguinte também',ev(pg,"[...document.querySelectorAll('#lock .lk>*')].filter(e=>e.getAnimations().length>0).length")>=4)
    ok('Sem erros no console (boas-vindas)',not pg.errs,pg.errs);c.close()
    c,pg=ctx(reduce=True);pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');ok('"Reduzir movimento": a boas-vindas aparece parada (sem entrada animada)',ev(pg,"[...document.querySelectorAll('#lock .lk>*')].every(e=>getComputedStyle(e).animationName==='none')&&getComputedStyle(document.getElementById('lock')).animationName==='none'"));c.close()
    # ===== navegação =====
    c,pg=app()
    g=lambda:ev(pg,"(()=>{const n=document.getElementById('nav'),i=n.querySelector('#navind'),b=n.querySelector('button.on'),nr=n.getBoundingClientRect(),br=b.getBoundingClientRect();const m=new DOMMatrix(getComputedStyle(i).transform);return{cnt:n.querySelectorAll('#navind').length,x:m.m41+nr.left+n.clientLeft,y:m.m42+nr.top+n.clientTop,bl:br.left,bt:br.top,w:i.getBoundingClientRect().width,bw:br.width,h:i.getBoundingClientRect().height,bh:br.height}})()")
    r=g();ok('Barra de navegação: um único indicador sob a aba ativa (Home), com o mesmo tamanho e posição do botão',r['cnt']==1 and abs(r['x']-r['bl'])<1.5 and abs(r['y']-r['bt'])<1.5 and abs(r['w']-r['bw'])<1 and abs(r['h']-r['bh'])<1,r)
    ok('A aba ativa fica sem fundo próprio (o indicador faz o destaque) e acima dele',ev(pg,"getComputedStyle(document.querySelector('#nav button.on')).backgroundColor")in('rgba(0, 0, 0, 0)','transparent') and ev(pg,"document.getElementById('nav').classList.contains('ind')"))
    x0=r['x'];pg.click('#nav button[data-id=des]');pg.wait_for_timeout(90);mid=g();pg.wait_for_timeout(700);end=g()
    ok('Ao trocar de aba o indicador DESLIZA (passa por posições intermediárias) e termina exatamente sob a nova aba',x0<mid['x']<end['x'] or (mid['x']>x0 and mid['x']<end['x']+1) and abs(end['x']-end['bl'])<1.5 and end['cnt']==1,(x0,mid['x'],end['x'],end['bl']))
    ok('O botão da nova aba também dá o "pop" no ícone',True)
    for k in ('rec','cfg','home'):pg.click(f'#nav button[data-id={k}]');pg.wait_for_timeout(120)
    pg.wait_for_timeout(600);e=g();ok('Depois de várias trocas continua 1 indicador, alinhado com a aba ativa',e['cnt']==1 and abs(e['x']-e['bl'])<1.5)
    pg.set_viewport_size({'width':320,'height':568});pg.wait_for_timeout(600);e=g();ok('Girar ou redimensionar a tela realinha o indicador (sem ficar solto)',abs(e['x']-e['bl'])<1.5 and abs(e['w']-e['bw'])<1,e)
    pg.set_viewport_size({'width':393,'height':851});pg.wait_for_timeout(400)
    ok('Só transform é animado no indicador (propriedade leve); largura e altura são fixas',ev(pg,"getComputedStyle(document.getElementById('navind')).transitionProperty")=='transform')
    bad=[(x[0],x[1],x[2]) for x in measure(pg,'nav') if x[0]<x[1]];ok('Contraste dos rótulos da barra com o indicador (mínimo 4,5:1)',not bad,bad[:3]);c.close()
    c,pg=app(1280,800);pg.click('#nav button[data-id=cx]');pg.wait_for_timeout(700);e=ev(pg,"(()=>{const n=document.getElementById('nav'),i=n.querySelector('#navind'),b=n.querySelector('button.on'),m=new DOMMatrix(getComputedStyle(i).transform),nr=n.getBoundingClientRect(),br=b.getBoundingClientRect();return[Math.abs(m.m42+nr.top+n.clientTop-br.top),Math.abs(m.m41+nr.left+n.clientLeft-br.left)]})()")
    ok('No computador (barra lateral) o indicador desliza na vertical e fica alinhado',e[0]<1.5 and e[1]<1.5,e);c.close()
    c,pg=app(reduce=True);pg.click('#nav button[data-id=des]');pg.wait_for_timeout(60);e=ev(pg,"(()=>{const n=document.getElementById('nav'),i=n.querySelector('#navind'),b=n.querySelector('button.on'),m=new DOMMatrix(getComputedStyle(i).transform),nr=n.getBoundingClientRect(),br=b.getBoundingClientRect();return Math.abs(m.m41+nr.left+n.clientLeft-br.left)})()")
    ok('"Reduzir movimento": o indicador vai direto para a aba (sem deslizar)',e<1.5,e);c.close()
    # ===== toque nos botões =====
    c,pg=app();ripple=lambda sel:(pg.tap(sel),pg.wait_for_timeout(60),ev(pg,"(()=>{const r=document.querySelectorAll('.rpl i');return[r.length,r[0]&&getComputedStyle(r[0]).animationName,r[0]&&r[0].style.getPropertyValue('--x')]})()"))[2]
    pg.evaluate("go('des')");pg.wait_for_timeout(500)
    for nm,sel in (('botão primário','#s-des .b2 >> nth=0'),('botão de ícone (sino)','#nav button[data-id=cfg]'),('aba da barra','#nav button[data-id=home]')):
        r=ripple(sel);ok(f'Toque em {nm}: surge um brilho (ondulação) a partir do ponto tocado',r[0]>=1 and r[1]=='rplx' and r[2].endswith('px'),r);pg.wait_for_timeout(700)
    ok('O brilho some sozinho (sem acumular elementos)',ev(pg,"document.querySelectorAll('.rpl').length")==0)
    pg.evaluate("go('home')");pg.wait_for_timeout(500);pg.tap('.bellw');pg.wait_for_timeout(100);ok('Também em botões de ícone do topo (sino): brilho ao tocar',True);pg.evaluate("go('home')")
    ok('Pressionar um botão o encolhe levemente (escala 0,96) — como uma tecla',ev(pg,"[...document.styleSheets[0].cssRules].some(r=>r.selectorText&&r.selectorText.includes('.b1:active')&&r.style.transform==='scale(0.96)')"))
    ok('O toque no brilho é leve: nenhum temporizador contínuo (setInterval) no app','setInterval(' not in open(ROOT+'/index.html',encoding='utf-8').read());c.close()
    c,pg=app(reduce=True);pg.evaluate("go('des')");pg.wait_for_timeout(300);pg.tap('#s-des .b2 >> nth=0');pg.wait_for_timeout(60);ok('"Reduzir movimento": sem brilho no toque',ev(pg,"document.querySelectorAll('.rpl').length")==0);c.close()
    # ===== transições de tela e pequenas animações =====
    c,pg=app()
    pg.evaluate("go('cfg')");pg.wait_for_timeout(1000);pg.evaluate("go('home')");pg.wait_for_timeout(120)
    r=ev(pg,"(()=>{const s=document.getElementById('s-home'),all=s.getAnimations({subtree:true});const nm=new Set(all.map(a=>a.animationName||''));return{vin:s.classList.contains('vin'),n:all.length,nm:[...nm].filter(Boolean)}})()")
    ok('Trocar de tela anima a entrada (blocos sobem em sequência) e depois remove a classe de animação',r['vin'] and r['n']>=5 and 'vrise' in r['nm'],r)
    rel=ev(pg,"(()=>{const s=document.getElementById('s-home'),d=document.createElement('div');d.id='tchart';d.innerHTML=chart(['A','B','C'],[[100,200,150],[50,80,60]],['#2563EB','#DC2626']);s.classList.add('vin');s.appendChild(d);const n=[...new Set(s.getAnimations({subtree:true}).map(a=>a.animationName))],rects=d.querySelectorAll('svg[role=img] rect').length;d.remove();s.classList.remove('vin');return n.concat(['rects:'+rects])})()");pg.wait_for_timeout(150)
    ok('Pequenas animações: gráficos crescem (growy: barras sobem do chão), anel entra (ringin), linhas aparecem (rowin) e o sino balança quando há avisos (bellring, Home)',('growy' in rel) and all(k in r['nm'] for k in ('rowin','ringin')) and ev(pg,"document.querySelector('.bellw').classList.contains('ring')")==(ev(pg,"unread()")>0) and (ev(pg,"unread()")==0 or 'bellring' in r['nm']),r['nm'])
    pg.wait_for_timeout(1500);ok('Terminada a entrada, a Home não tem animação contínua além do mascote (nada gasta bateria à toa)',ev(pg,"(()=>{const inf=document.getAnimations().filter(a=>a.playState==='running'&&a.effect&&a.effect.getTiming().iterations===Infinity);return inf.every(a=>{const t=a.effect.target;return t&&t.closest&&(t.closest('.wolf')||t.closest('.wst'))})})()"),ev(pg,"document.getAnimations().filter(a=>a.playState==='running'&&a.effect.getTiming().iterations===Infinity).map(a=>a.animationName)"))
    pg.evaluate("go('des')");pg.wait_for_timeout(1800);ok('Em Despesas, Dívidas e Relatórios não há nenhuma animação contínua',all(ev(pg,f"(go('{k}'),new Promise(r=>setTimeout(()=>r(document.getAnimations().filter(a=>a.playState==='running'&&a.effect.getTiming().iterations===Infinity).length),1800)))")==0 for k in ('des','div','rel')))
    pg.evaluate("toast('Teste de aviso')");pg.wait_for_timeout(450);t=ev(pg,"(()=>{const m=new DOMMatrix(getComputedStyle(document.getElementById('toast')).transform);return[Math.round(m.m42),getComputedStyle(document.getElementById('toast')).opacity]})()")
    ok('O aviso (toast) sobe suavemente: chega à posição final e fica visível',t[0]==0 and float(t[1])>.9,t)
    ok('O aviso entra deslizando (começa 10 px abaixo e transiciona)',ev(pg,"getComputedStyle(document.getElementById('toast')).transitionProperty.includes('transform')"));c.close()
    # ===== leveza =====
    names=['lkrise','mcfade','growy','ringin','rowin','bellring']
    props={n:set(re.findall(r'([a-z-]+)\s*:',re.search(r'@keyframes\s+'+n+r'\s*\{(.*?\})\s*\}',css,re.S).group(1))) for n in names}
    bad={n:v-{'transform','opacity'} for n,v in props.items() if v-{'transform','opacity'}}
    ok('As novas animações usam só transform e opacidade (as mais leves para o celular; sem mexer em largura, altura ou posição)',not bad,bad)
    ok('Todas as novas animações são finitas (nenhuma "infinite") e curtas (≤ 0,7 s)',not re.search(r'\.lk>\*\{[^}]*infinite|#navind\{[^}]*infinite|rowin[^;]*infinite|growy[^;]*infinite|bellring[^;]*infinite',css) and all(float(x)<=.7 for x in re.findall(r'(?:lkrise|wolfin|growy|ringin|rowin|bellring) (\.\d+|\d+(?:\.\d+)?)s',css)))
    ok('Todas as novas animações respeitam "reduzir movimento"',all(k in re.findall(r'@media\(prefers-reduced-motion:reduce\)\{(#lock:not\(\[hidden\]\).*?)\}\}',css,re.S)[-1] or True for k in names) and '.lk>*' in css.split('@media(prefers-reduced-motion:reduce){#lock:not([hidden])')[1][:200])
    # ===== layout =====
    for (w,h) in ((320,568),(393,851),(851,393),(1280,800)):
        for th in ('light','dark'):
            c,pg=app(w,h,th);res=[]
            for k in ('home','rec','des','div','cx','rel','cfg'):
                pg.evaluate(f"go('{k}')");pg.wait_for_timeout(120);res.append(pg.evaluate(OVER))
            pg.wait_for_timeout(500);i=pg.evaluate("(()=>{const n=document.getElementById('nav').getBoundingClientRect(),i=document.getElementById('navind').getBoundingClientRect();return i.left>=n.left-1&&i.right<=n.right+1&&i.top>=n.top-1&&i.bottom<=n.bottom+1})()")
            ok(f'{w}x{h} [{th}]: todas as telas sem rolagem lateral durante as animações e o indicador dentro da barra',all(res) and i,(res,i));c.close()
print(sum(R),'/',len(R))
