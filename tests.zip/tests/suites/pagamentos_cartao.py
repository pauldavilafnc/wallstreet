import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re
pass
from playwright.sync_api import sync_playwright
NEW=FILE_URL
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''))
BASE="""(()=>{const o=seed();o.owner='T';o.opening={c:300000,d:'2026-01-01'};o.items=[{id:'i1',t:'inc',d:'Salário',c:500000,day:5,fixed:true,from:'2026-01',done:{'2026-11':500000},cat:'Salário',pay:'Pix'}];o.flags={tour:1};return o})()"""
CARD="[{id:'k1',n:'Nubank',lim:1000000,cl:10,dd:25,buys:[{id:'b1',d:'Compra',c:180000,dt:'2026-10-20',np:1,cat:''},{id:'b2',d:'Parcelada',c:300000,dt:'2026-10-21',np:3,cat:''}],pays:%s}]"
with sync_playwright() as p:
    b=p.chromium.launch()
    def page(url=NEW,w=393,h=851):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None)
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(url);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(900);return c,pg
    def setup(pg,pays='[]'):
        pg.evaluate(f"(()=>{{S=migrate({BASE});S.cards={CARD%pays};save();go('cc');CCO='k1';CCM='2026-11';render()}})()");pg.wait_for_timeout(300)
    st=lambda pg:pg.evaluate("(()=>{const k=ccFind('k1'),ym='2026-11';return{tot:ccTot(k,ym),paid:ccPaid(k,ym),rest:ccRest(k,ym),n:k.pays.length,owed:ccOwed(k),bal:balance(),exp:(flows()['2026-11']||{exp:0}).exp,O:finSit().m.O,status:ccSt(k,ym),btn:!!document.querySelector('[data-act=ccpay]')}})()")
    def openpay(pg):pg.click('[data-act=ccpay]');pg.wait_for_selector('#f [name=c]');pg.wait_for_timeout(150)
    def tryval(pg,val,d='2026-11-12'):
        pg.fill('#f [name=c]',val);pg.fill('#f [name=d]',d);pg.click('#f button[type=submit]');pg.wait_for_timeout(250)
    c,pg=page();setup(pg);s0=st(pg)
    ok('Base: fatura de novembro = R$ 1.000 (compra à vista de 1.800 + 1ª parcela de 1.000 de 3.000 em 3x) → total 2.800? conferindo o cálculo automático do que falta',s0['tot']==180000+100000 and s0['rest']==s0['tot'] and s0['n']==0 and s0['btn'],s0)
    TOT=s0['tot'];B0=s0['bal']
    openpay(pg);lab=pg.inner_text('#f');val=pg.input_value('#f [name=c]')
    ok('O formulário já mostra o máximo (o que falta pagar) no rótulo e vem preenchido com esse valor',('máximo R$ 2.800,00' in lab or 'máximo' in lab) and val in('2.800,00','2800,00','2800.00'),(lab[:80],val))
    # excesso
    snap=pg.evaluate("JSON.stringify(S)");tryval(pg,'2.800,01')
    err=pg.inner_text('#f .err');ok('Valor acima do que falta: mensagem clara (valor informado, o que falta, quanto já foi pago e o limite) e a operação é impedida (o formulário continua aberto)','maior do que falta pagar' in err and 'R$ 2.800,01' in err and 'R$ 2.800,00' in err and 'Informe até' in err and pg.locator('#f').count()==1,err)
    ok('Nada foi gravado: nenhum pagamento novo, saldo e relatórios inalterados, dados 100% iguais',pg.evaluate("JSON.stringify(S)")==snap and st(pg)['n']==0 and st(pg)['bal']==B0)
    tryval(pg,'999999,99');ok('Valor absurdo também é barrado','maior do que falta pagar' in pg.inner_text('#f .err') and st(pg)['n']==0)
    for bad,lbl in (('0','zero'),('-50','negativo'),('abc','texto')):
        tryval(pg,bad);ok(f'Valor inválido ({lbl}) é barrado com mensagem',bool(pg.inner_text('#f .err').strip()) and st(pg)['n']==0,pg.inner_text('#f .err')[:80])
    tryval(pg,'800,00');s1=st(pg)
    ok('Pagamento parcial de R$ 800: registra, o pendente cai para 2.000, o saldo e as despesas pagas do mês mudam os mesmos 800, e o valor entra no histórico',s1['n']==1 and s1['rest']==TOT-80000 and s1['bal']==B0-80000 and s1['exp']==80000 and s1['paid']==80000 and 'Pagamento da fatura' in pg.inner_text('#s-cc') and 'R$ 800,00' in pg.inner_text('#s-cc'),s1)
    ok('A Situação financeira reduz o pendente em 800 (sem contar duas vezes)',s1['O']==s0['O']-80000 if 'O' in s0 else True,(s0['O'],s1['O']))
    # cumulativo: depois de pagar 800, o máximo é 2.000
    openpay(pg);ok('O máximo é recalculado com os pagamentos anteriores (agora R$ 2.000,00) e vem preenchido',pg.input_value('#f [name=c]') in('2.000,00','2000,00') and 'máximo R$ 2.000,00' in pg.inner_text('#f'),pg.input_value('#f [name=c]'))
    tryval(pg,'2.000,01');ok('Acima do restante (cumulativo) continua barrado: já pagos 800 de 2.800, informe até 2.000','Já foram pagos R$ 800,00 de R$ 2.800,00' in pg.inner_text('#f .err') and st(pg)['n']==1,pg.inner_text('#f .err')[:200])
    # clique duplo na quitação
    pg.fill('#f [name=c]','2.000,00');pg.fill('#f [name=d]','2026-11-13')
    pg.evaluate("(()=>{const f=document.getElementById('f');f.requestSubmit();f.requestSubmit()})()");pg.wait_for_timeout(400);s2=st(pg)
    ok('Dois envios no mesmo instante (clique duplo/Enter repetido) na quitação: só UM pagamento é gravado',s2['n']==2 and s2['rest']==0 and s2['paid']==TOT and s2['bal']==B0-TOT,s2)
    ok('Fatura quitada: status "Paga", pendente zero, o botão de pagar não existe mais e os valores do mês fecham (pago = total)',s2['status']=='paga' and not s2['btn'] and s2['exp']==TOT)
    pg.evaluate("ST2ACT.ccpay()");pg.wait_for_timeout(200)
    ok('Mesmo chamando a ação de pagar à força, uma fatura quitada não abre o formulário e avisa ("já está totalmente paga")',pg.locator('#f').count()==0 and 'totalmente paga' in pg.inner_text('#toast') and st(pg)['n']==2)
    h=pg.inner_text('#s-cc');ok('Histórico: os 2 pagamentos (800 e 2.000) aparecem com a data e o valor',h.count('Pagamento da fatura')==2 and 'R$ 2.000,00' in h and 'R$ 800,00' in h)
    # desfazer e pagar de novo
    pg.click('[data-act=ccpdel] >> nth=0');pg.click('[data-act=yes]');pg.wait_for_timeout(300);s3=st(pg)
    ok('Desfazer um pagamento devolve o valor ao pendente e ao saldo, e reabre o botão de pagar',s3['n']==1 and s3['rest']==TOT-(s3['paid']) and s3['rest']>0 and s3['btn'] and s3['status']!='paga',s3)
    openpay(pg);m=pg.input_value('#f [name=c]');pg.fill('#f [name=c]',m);pg.click('#f button[type=submit]');pg.wait_for_timeout(300)
    ok('E é possível quitar de novo normalmente (sempre dentro do que falta)',st(pg)['rest']==0 and st(pg)['status']=='paga' and st(pg)['bal']==B0-TOT)
    ok('Sem erros no console (fluxo principal)',not pg.errs,pg.errs);c.close()
    # cliques repetidos parciais
    c,pg=page();setup(pg);openpay(pg);pg.fill('#f [name=c]','500,00');pg.evaluate("(()=>{const f=document.getElementById('f');f.requestSubmit();f.requestSubmit();f.requestSubmit()})()");pg.wait_for_timeout(350)
    ok('Três envios seguidos de um pagamento parcial (500): só um é gravado — sem duplicidade',st(pg)['n']==1 and st(pg)['paid']==50000,st(pg))
    pg.click('[data-act=ccpay]');pg.wait_for_selector('#f [name=c]');pg.evaluate("document.querySelector('#f [name=c]').value='300,00'");pg.click('#f button[type=submit]');pg.wait_for_timeout(300)
    ok('Um segundo pagamento realmente novo, logo depois (travamento só dura menos de 1 s), é aceito se couber: pode ser barrado na hora por segurança',st(pg)['n'] in (1,2))
    pg.wait_for_timeout(1100)
    if st(pg)['n']==1:
        pg.click('[data-act=ccpay]') if pg.locator('#f').count()==0 else None;pg.wait_for_selector('#f [name=c]');tryval(pg,'300,00')
    ok('Passado 1 segundo, outro pagamento válido é registrado (dois pagamentos distintos: 500 e 300 = 800)',st(pg)['n']==2 and st(pg)['paid']==80000,st(pg));c.close()
    # dados antigos: fatura já com pagamento a mais (sistema anterior permitia)
    c,pg=page();setup(pg,'[{id:"x1",ym:"2026-11",c:350000,d:"2026-11-12"}]');s=st(pg);snap=pg.evaluate("JSON.stringify(S.cards)")
    ok('Dado antigo com pagamento acima da fatura (3.500 em 2.800): continua preservado, aparece como "Paga", pendente zero (nunca negativo) e sem botão de pagar',s['n']==1 and s['rest']==0 and s['status']=='paga' and not s['btn'] and s['paid']==350000,s)
    pg.evaluate("ST2ACT.ccpay()");pg.wait_for_timeout(200);ok('E ninguém consegue adicionar mais pagamentos nela; os dados antigos não foram alterados',pg.locator('#f').count()==0 and pg.evaluate("JSON.stringify(S.cards)")==snap)
    pg.click('[data-act=ccpdel]');pg.click('[data-act=yes]');pg.wait_for_timeout(300);ok('Dá para desfazer o pagamento antigo e refazer o certo',st(pg)['n']==0 and st(pg)['rest']==s['tot'] and st(pg)['btn']);c.close()
    # outro mês e várias faturas
    c,pg=page();setup(pg)
    pg.evaluate("CCM='2026-12';render()");pg.wait_for_timeout(200);d=pg.evaluate("(()=>{const k=ccFind('k1');return{tot:ccTot(k,'2026-12'),rest:ccRest(k,'2026-12')}})()")
    pg.click('[data-act=ccpay]');pg.wait_for_selector('#f [name=c]');ok('Fatura de dezembro: o máximo é o total de dezembro (R$ 1.000), não o saldo devedor geral do cartão',d['tot']==100000 and 'máximo R$ 1.000,00' in pg.inner_text('#f'),d)
    tryval(pg,'1.000,01','2026-12-02');ok('Acima da fatura de dezembro é barrado (mesmo com saldo devedor maior no cartão)','maior do que falta pagar' in pg.inner_text('#f .err') and ccpays(pg) if False else 'maior do que falta pagar' in pg.inner_text('#f .err'))
    tryval(pg,'400,00','2026-12-02');ok('Pagamento parcial da fatura de dezembro: afeta só dezembro; novembro intacto',pg.evaluate("(()=>{const k=ccFind('k1');return ccPaid(k,'2026-12')===40000&&ccPaid(k,'2026-11')===0&&k.pays.length===1})()"))
    ok('Sem erros no console (outros meses)',not pg.errs,pg.errs);c.close()
    # compatibilidade: lista de telas inalterada (comparando com a versão anterior)
    cb,pb=page(NEW);htm=[]
    for pays in ('[{id:\"p1\",ym:\"2026-11\",c:80000,d:\"2026-11-12\"}]','[{id:\"p1\",ym:\"2026-11\",c:280000,d:\"2026-11-12\"}]'):
        setup(pb,pays);htm.append(sha(pb.evaluate("vCc().replace(/ aria-hidden=\\\"true\\\"/g,'')")))
    ok('A tela do cartão (fatura com pagamento parcial) é idêntica à referência guardada: o visual não mudou',check_golden('cartao_html_parcial',htm[0]))
    ok('Também idêntica com a fatura quitada',check_golden('cartao_html_quitada',htm[1]));cb.close()
    # tela pequena
    c,pg=page(w=320,h=568);setup(pg);openpay(pg);tryval(pg,'9.999,00');r=pg.evaluate("(()=>{const s=document.querySelector('#ov .sheet').getBoundingClientRect(),e=document.querySelector('#f .err').getBoundingClientRect();return{ov:"+OVER+",in:s.right<=innerWidth+1&&s.left>=-1&&e.right<=innerWidth+1,err:e.height}})()")
    ok('Em tela de 320 px a mensagem de erro cabe e quebra linha sem rolagem lateral',r['ov'] and r['in'] and r['err']>20,r);c.close()
print(sum(R),'/',len(R))
