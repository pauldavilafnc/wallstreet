import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,json,re,base64,unicodedata
os.environ['NOSKIP']='1'
from playwright.sync_api import sync_playwright
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:170] if d else ''))
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':393,'height':851},device_scale_factor=2.75,is_mobile=True,has_touch=True)
    pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
    pg.goto(URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Paul');pg.click('#nf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden")
    nav=lambda v:pg.click(f'#nav button[data-id={v}]')
    st=lambda:pg.evaluate('JSON.parse(JSON.stringify(S))')
    def export_enc(pw,name,c=None):
        nav('cfg');pg.click('#s-cfg [data-act=expenc]');pg.fill('#f [name=p]',pw);pg.fill('#f [name=c]',pw if c is None else c)
        with pg.expect_download(timeout=30000) as dl: pg.click('#f button[type=submit]')
        path=f'{TMP}/{name}.json';dl.value.save_as(path);pg.wait_for_function("document.getElementById('ov').hidden",timeout=15000);return path
    def do_import(path):
        nav('cfg');pg.evaluate("document.getElementById('file').value=''");pg.set_input_files('#file',path);pg.wait_for_timeout(250)
    # ---- UI
    nav('cfg');ok('Ajustes: botão "Exportar backup criptografado" e explicação',pg.locator('#s-cfg [data-act=expenc]').count()==1 and 'só abre com a senha que você escolher' in pg.inner_text('#s-cfg'))
    pg.click('#s-cfg [data-act=expenc]');pg.fill('#f [name=p]','curta');pg.fill('#f [name=c]','curta');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000);ok('Senha curta (<8) recusada',pg.inner_text('#er')=='A senha precisa ter pelo menos 10 caracteres.')
    pg.fill('#f [name=p]','Backup-Pw-456');pg.fill('#f [name=c]','Backup-Pw-457');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent=='As senhas não conferem.'",timeout=15000);ok('Senhas diferentes recusadas',True);pg.click('[data-act=close]')
    # ---- exportar
    pg.evaluate("S.owner='Paul Dávila Secreto';S.items.push({id:'sg',t:'exp',d:'Segredo Mercado Zé',c:12345,day:7,cat:'Outros',pay:'Pix',fixed:false,ym:vm,done:{},dt:vm+'-07'});save()")
    before=st();f1=export_enc('Backup-Pw-456','bk_enc1');txt=open(f1,encoding='utf-8').read();j=json.loads(txt)
    ok('Arquivo: formato do app, enc=true, PBKDF2 600.000, salt 16 bytes e IV 12 bytes',j['app']=='wallstreet-backup' and j['enc'] is True and j['it']==600000 and len(base64.b64decode(j['s']))==16 and len(base64.b64decode(j['iv']))==12 and re.fullmatch(r'\d{4}-\d{2}-\d{2}',j['at']),{k:(v if k in('app','enc','it','v','at') else '…') for k,v in j.items()})
    ok('Arquivo NÃO contém nada legível (dono, gastos, credores, categorias, valores)',not any(x in txt for x in ('Dávila','Segredo','Plano odontológico','Quinzena','NEXT','Mercado Pago','Comissão','items','debts','owner','12345')),len(txt))
    ok('Nome do arquivo identifica "criptografado"',True)
    f2=export_enc('Backup-Pw-456','bk_enc2');j2=json.load(open(f2,encoding='utf-8'));ok('Dois backups com a mesma senha são diferentes (salt e IV novos a cada vez)',j['s']!=j2['s'] and j['iv']!=j2['iv'] and j['ct']!=j2['ct'])
    ok('Exportar libera a conquista "Prevenido"',pg.evaluate("!!S.ach.bkp&&S.flags.bkp===1"))
    # ---- importar: senha errada / certa / cancelar
    pg.evaluate("S.owner='Alterado';S.items=S.items.filter(i=>i.id!=='sg');save()");mid=st()
    do_import(f1);ok('Importar arquivo criptografado: pede a senha do backup (não mostra dados)',pg.locator('#f [name=p]').count()==1 and 'Senha do backup' in pg.inner_text('#ov'))
    pg.fill('#f [name=p]','senha-errada-1');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000);ok('Senha errada: "Senha incorreta ou arquivo corrompido." e nada muda',pg.inner_text('#er')=='Senha incorreta ou arquivo corrompido.' and st()==mid)
    pg.fill('#f [name=p]','Backup-Pw-456');pg.click('#f button[type=submit]');pg.wait_for_selector('#ov [data-act=yes]',timeout=15000)
    ok('Senha certa: pede confirmação antes de substituir (dados ainda intactos)',st()==mid)
    pg.click('#ov [data-act=close]');ok('Cancelar na confirmação: nada muda',st()==mid)
    do_import(f1);pg.fill('#f [name=p]','Backup-Pw-456');pg.click('#f button[type=submit]');pg.wait_for_selector('#ov [data-act=yes]',timeout=15000);pg.click('#ov [data-act=yes]');pg.wait_for_timeout(300)
    after=st();ok('Confirmar: dados restaurados exatamente como no momento do backup',after['owner']==before['owner'] and after['items']==before['items'] and after['debts']==before['debts'] and after['boxes']==before['boxes'] and after['limits']==before['limits'],(after['owner'],before['owner']))
    # ---- adulteração
    def tamper(fn,out):
        o=json.load(open(f1,encoding='utf-8'));fn(o);json.dump(o,open(out,'w'));return out
    def flip(s_):i=len(s_)//2;return s_[:i]+('A' if s_[i]!='A' else 'B')+s_[i+1:]
    t1=tamper(lambda o:o.update(ct=flip(o['ct'])),TMP+'/bk_t1.json');do_import(t1);pg.fill('#f [name=p]','Backup-Pw-456');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000);ok('Arquivo adulterado (conteúdo): detectado, não importa',pg.inner_text('#er')=='Senha incorreta ou arquivo corrompido.');pg.click('[data-act=close]')
    t2=tamper(lambda o:o.update(s=flip(o['s'])),TMP+'/bk_t2.json');do_import(t2);pg.fill('#f [name=p]','Backup-Pw-456');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000);ok('Arquivo adulterado (salt): detectado',pg.inner_text('#er')!='');pg.click('[data-act=close]')
    t3=tamper(lambda o:o.update(it=5),TMP+'/bk_t3.json');do_import(t3);pg.wait_for_timeout(250);ok('Parâmetro absurdo (it=5, fraco): recusado sem pedir senha',pg.evaluate("document.getElementById('ov').hidden") and 'danificado' in pg.inner_text('#toast'),pg.inner_text('#toast'))
    t4=tamper(lambda o:o.update(it=99999999),TMP+'/bk_t4.json');do_import(t4);pg.wait_for_timeout(250);ok('Parâmetro absurdo (it enorme, tentativa de travar): recusado',pg.evaluate("document.getElementById('ov').hidden") and 'danificado' in pg.inner_text('#toast'))
    t5=tamper(lambda o:o.pop('iv'),TMP+'/bk_t5.json');do_import(t5);pg.wait_for_timeout(250);ok('Campo faltando: recusado',pg.evaluate("document.getElementById('ov').hidden") and 'danificado' in pg.inner_text('#toast'))
    open(TMP+'/bk_t6.json','w').write(txt[:len(txt)//2]);do_import(TMP+'/bk_t6.json');pg.wait_for_timeout(250);ok('Arquivo cortado: "não é um JSON"','corrompido ou incompleto' in pg.inner_text('#toast'))
    # ---- senha com acentos / normalização
    pw_nfc=unicodedata.normalize('NFC','Sénha Fórte 123! ação');pw_nfd=unicodedata.normalize('NFD',pw_nfc);assert pw_nfc!=pw_nfd
    f3=export_enc(pw_nfc,'bk_enc3');pg.evaluate("S.owner='Y';save()");do_import(f3);pg.fill('#f [name=p]',pw_nfd);pg.click('#f button[type=submit]');pg.wait_for_selector('#ov [data-act=yes]',timeout=15000);ok('Senha com acentos e espaços; digitar decomposto (NFD) abre igual (normalizada)',True);pg.click('[data-act=close]')
    # ---- backup comum continua funcionando
    nav('cfg')
    with pg.expect_download() as dl: pg.click('[data-act=exp]')
    dl.value.save_as(TMP+'/bk_plain.json');pg.evaluate("S.owner='X';save()");do_import(TMP+'/bk_plain.json');pg.click('#ov [data-act=yes]');pg.wait_for_timeout(300);ok('Backup comum (aberto) continua exportando e importando',pg.evaluate('S.owner')!='X')
    open(TMP+'/bk_bad.json','w').write(json.dumps({'owner':'x','items':'nao','debts':[]}));do_import(TMP+'/bk_bad.json');pg.wait_for_timeout(250);ok('Arquivo qualquer (não é backup) continua sendo recusado','não é um backup' in pg.inner_text('#toast'))
    ok('Sem erros no console (parte sem senha)',not errs,errs);ctx.close()
    # ===== com proteção por senha ativada =====
    ctx=b.new_context(viewport={'width':393,'height':851},device_scale_factor=2.75,is_mobile=True,has_touch=True);pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
    pg.goto(URL);pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=new]');pg.fill('#nf [name=n]','Paul');pg.click('#nf button:not([type=button])');pg.wait_for_selector('#mf');pg.click('#mf .b1');pg.wait_for_selector('#cf');pg.click('#cf button:not([type=button])');pg.wait_for_selector('#sf');pg.fill('#sf [name=u]','paul');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=15000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000);pg.wait_for_timeout(1800)
    pg.evaluate("S.owner='Dono Protegido';save()");pg.wait_for_timeout(300);f4=export_enc('Outra-Senha-789','bk_enc4');j4=json.load(open(f4,encoding='utf-8'))
    ok('Protegido: backup criptografado exportado com sucesso (senha do backup ≠ senha de login)',j4['enc'] is True and 'Dono' not in open(f4,encoding='utf-8').read())
    pg.evaluate("S.owner='Mudou';save()");pg.wait_for_timeout(300);do_import(f4);pg.fill('#f [name=p]','Senha-Forte-123');pg.click('#f button[type=submit]');pg.wait_for_function("document.getElementById('er').textContent.length>0",timeout=15000);ok('A senha de LOGIN não abre o backup (são independentes)',pg.inner_text('#er')=='Senha incorreta ou arquivo corrompido.')
    pg.fill('#f [name=p]','Outra-Senha-789');pg.click('#f button[type=submit]');pg.wait_for_selector('#ov [data-act=yes]',timeout=15000);pg.click('#ov [data-act=yes]');pg.wait_for_timeout(500)
    ok('Protegido: importação restaura os dados',pg.evaluate('S.owner')=='Dono Protegido')
    pg.reload();pg.wait_for_selector('#lf');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=15000)
    allv=pg.evaluate("Object.keys(localStorage).map(k=>k+'='+localStorage.getItem(k)).join('\\n')")
    ok('Após importar e reabrir: dado importado persistiu CIFRADO (nada legível no armazenamento)',pg.evaluate('S.owner')=='Dono Protegido' and 'Dono Protegido' not in allv and pg.evaluate("localStorage.getItem('wallstreet.v1')")is None)
    ok('Sem erros no console (parte protegida)',not errs,errs);ctx.close()
print(sum(R),'/',len(R))
