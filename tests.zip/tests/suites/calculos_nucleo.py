"""Cálculos financeiros do núcleo, por PROPRIEDADES: 150 cenários aleatórios (semente fixa) de receitas, despesas, dívidas, caixinhas,
parcelas e cartões; o que o app calcula (saldo, fluxo, dívida, caixinha, fatura, compromissos, situação) é conferido contra o recálculo
independente em Python (tests/lib/oraculo.py). Dados 100% fictícios."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import random,oraculo as O
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def gen(rs):
    mo=['2026-08','2026-09','2026-10','2026-11'];it=[]
    for k in range(rs.randint(1,9)):
        t=rs.choice(['inc','exp','exp']);fx=rs.random()<.6;c=rs.randint(2,120)*1000+rs.choice([0,0,500,990]);day=rs.randint(1,31)
        o={'id':'i%d'%k,'t':t,'d':'Item %d'%k,'c':c,'day':day,'fixed':fx,'cat':rs.choice(['Casa','Lazer','Saúde','Outros']),'pay':'Pix','done':{}}
        if fx:o['from']=rs.choice(mo)
        else:o['ym']=rs.choice(mo)
        for m in mo:
            if rs.random()<.35:o['done'][m]=c if rs.random()<.8 else c+rs.randint(1,900)
        it.append(o)
    de=[]
    for k in range(rs.randint(0,4)):
        o=rs.randint(5,300)*1000;de.append({'id':'d%d'%k,'n':'Dívida %d'%k,'o':o,'due':rs.choice(['','2026-10-20','2026-12-10']),'pays':[{'id':'p%d_%d'%(k,j),'c':rs.randint(1,o//1500)*1000,'d':'%s-%02d'%(rs.choice(mo),rs.randint(1,28))} for j in range(rs.randint(0,3))]})
    bx=[{'id':'b%d'%k,'n':'Caixinha %d'%k,'g':rs.choice([None,500000]),'m':None,'dl':'','moves':[{'id':'m%d_%d'%(k,j),'c':rs.choice([1,1,-1])*rs.randint(1,200)*100,'d':'%s-%02d'%(rs.choice(mo),rs.randint(1,28))} for j in range(rs.randint(0,4))]} for k in range(rs.randint(0,2))]
    ins=[{'id':'n1','n':'Celular','c':None,'np':None,'day':5,'paid':False}];pa=[]
    for k in range(rs.randint(0,5)):
        ym=rs.choice(mo+['2026-12','2027-01']);q={'id':'q%d'%k,'iid':'n1','ym':ym,'c':rs.randint(5,40)*1000,'paid':rs.choice([0,1])}
        if rs.random()<.4:q['due']=ym+'-%02d'%rs.randint(1,28)
        pa.append(q)
    cs=[]
    for k in range(rs.randint(0,2)):
        cl=rs.randint(1,27);dd=rs.choice([x for x in range(1,29) if x!=cl]);bs=[{'id':'u%d_%d'%(k,j),'d':'Compra','c':rs.randint(1,300)*1000+rs.randint(0,999),'dt':'%s-%02d'%(rs.choice(mo),rs.randint(1,28)),'np':rs.choice([1,1,2,3,6]),'cat':'Outros'} for j in range(rs.randint(0,4))]
        cs.append({'id':'k%d'%k,'n':'Cartão %d'%k,'lim':1000000,'cl':cl,'dd':dd,'buys':bs,'pays':[{'id':'y%d_%d'%(k,j),'ym':rs.choice(mo+['2026-12']),'c':rs.randint(1,400)*1000,'d':'%s-%02d'%(rs.choice(mo),rs.randint(1,28))} for j in range(rs.randint(0,3))]})
    return {'v':2,'owner':'T','opening':rs.choice([None,{'c':rs.randint(0,600)*1000,'d':'2026-01-01'}]),'limits':{},'ntf':{'read':{}},'pref':{'theme':'light','pal':'perola','av':{'v':2,'m':0,'an':1,'set':0},'ms':'terno','ma':0,'mt':0},'items':it,'inst':ins,'parc':pa,'debts':de,'boxes':bx,'cards':cs,'flags':{'tour':1}}
MESES=['2026-08','2026-09','2026-10','2026-11','2026-12','2027-01']
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':393,'height':851},timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1");pg=c.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(FILE_URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(600)
    rs=random.Random(20261111);bad={'saldo':[],'fluxo':[],'divida':[],'caixinha':[],'fatura':[],'compromissos':[],'situacao':[]};N=150
    for n in range(N):
        raw=json.dumps(gen(rs));js=pg.evaluate("(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};return JSON.stringify(S)}",raw);S=json.loads(js)
        if pg.evaluate("balance()")!=O.balance(S):bad['saldo'].append(n)
        F=pg.evaluate("flows()");of=O.flows(S)
        if {k:v for k,v in F.items()}!={k:v for k,v in of.items()}:bad['fluxo'].append(n)
        r=pg.evaluate("S.debts.map(d=>[paidOf(d),balOf(d)])");o=[[sum(p['c'] for p in d['pays']),d['o']-sum(p['c'] for p in d['pays'])] for d in S['debts']]
        if r!=o:bad['divida'].append(n)
        r=pg.evaluate("S.boxes.map(x=>savedOf(x))")
        if r!=[sum(m['c'] for m in x['moves']) for x in S['boxes']]:bad['caixinha'].append(n)
        r=pg.evaluate("S.cards.map(k=>[ccOwed(k),"+json.dumps(MESES)+".map(m=>[ccTot(k,m),ccPaid(k,m)])])");o=[[O.cc_owed(k),[[O.cc_tot(k,m),O.cc_paid(k,m)] for m in MESES]] for k in S['cards']]
        if r!=o:bad['fatura'].append(n)
        for m in MESES:
            a=pg.evaluate(f"[relCommit('{m}'),relFlow('{m}')]");oc=O.commit(S,m);of_=O.flow(S,m)
            if any(a[0][k]!=oc[k] for k in ('R','Cm','paid','pend','late')) or any(a[0][pt][kk]!=oc[pt][kk] for pt in('ct','pt','cc') for kk in('tot','paid','pend','late')) or any(a[1][k]!=of_[k] for k in('inc','exp','dp','bx','res','ini','fin')):bad['compromissos'].append((n,m));break
        m=pg.evaluate("finSit().m");oc=O.commit(S,O.CM)
        pun=sum(q['c'] for q in S['parc'] if not q.get('paid'))+sum(O.cc_owed(k) for k in S['cards'])
        if not(m['R']==oc['R'] and m['Cm']==oc['Cm'] and m['bal']==O.balance(S) and m['Epaid']==oc['ct']['paid']+oc['cc']['paid'] and m['Pun']==pun):bad['situacao'].append(n)
    for k,t in (('saldo','Saldo disponível = saldo inicial + (receitas − despesas − dívidas − caixinhas − pagamentos de fatura) de todos os meses'),('fluxo','Fluxo de caixa de cada mês (recebido, pago, dívidas pagas, guardado)'),('divida','Dívidas: valor pago e saldo restante (inicial − pagamentos, inclusive pagamento a maior)'),('caixinha','Caixinhas: valor guardado (depósitos − retiradas)'),('fatura','Cartões: total de cada fatura, valor pago por fatura e saldo devedor (parcelamento, fechamento e arredondamento)'),('compromissos','Compromissos do mês (contas, parcelas, faturas: pago/pendente/vencido) e saldo inicial/final, em 6 meses'),('situacao','Situação financeira: renda, compromissos, saldo, pago e total a pagar do mês atual')):
        ok(f'{t} — {N} cenários aleatórios conferem com o recálculo independente',not bad[k],bad[k][:4])
    ok('Sem erros de JavaScript durante os 150 cenários',not errs,errs[:2]);c.close()
print(sum(R),'/',len(R))
