import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re,os
pass
from playwright.sync_api import sync_playwright
URL=os.environ.get('WS_URL',HTTP_URL)
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''))
PW='Senha-Forte-123'
INSTR="""window.__WS_NOTOUR=1;window.__ENC_DELAY=0;window.__ENC_FAIL=0;window.__SET_FAIL=0;window.__SET_NOOP=0;window.__SETK_FAIL=0;window.__SETLOG=[];
(()=>{const E=crypto.subtle.encrypt.bind(crypto.subtle);crypto.subtle.encrypt=async function(...a){const d=window.__ENC_DELAY;if(d){await new Promise(r=>setTimeout(r,typeof d==='function'?d():d))}if(window.__ENC_FAIL)throw new Error('falha de criptografia simulada');return E(...a)};
const S0=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='wallstreet.sec'){window.__SETLOG.push(v);if(window.__SET_FAIL)throw new DOMException('cheio','QuotaExceededError');if(window.__SET_NOOP)return}
 if(k==='wallstreet.v1'){window.__SETLOG.push(v);if(window.__SETK_FAIL)throw new DOMException('cheio','QuotaExceededError')}return S0.call(this,k,v)}})();"""
STORED="(async()=>{const o=JSON.parse(localStorage.getItem('wallstreet.sec'));return JSON.parse(dec.decode(await unseal(DEK,o.d)))})()"
with sync_playwright() as p:
    b=p.chromium.launch()
    def newctx():
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo');c.add_init_script(INSTR);return c
    def mkpage(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return pg
    def create(pg,pw=True):
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(400)
        if pw:
            OB_TO_SETUP(pg,'Paul');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]',PW);pg.fill('#sf [name=c]',PW);pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone')
        else:
            OB_NOSEC(pg,'Paul')
        pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1500)
    def login(pg):
        pg.wait_for_selector('#lf',timeout=20000);pg.fill('#lf [name=u]','paul');pg.fill('#lf [name=p]',PW);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(800)
    tx=lambda pg:pg.inner_text('#toast')
    stored=lambda pg:pg.evaluate(STORED)
    def settle(pg,ms=1200):pg.wait_for_function("!SAVING&&!SNAP",timeout=20000);pg.wait_for_timeout(ms)
    # ================= MODO PROTEGIDO =================
    c=newctx();pg=mkpage(c);create(pg)
    pg.evaluate("(()=>{S.limits=S.limits||{};S.limits['aquece']=1;commit('x')})()");settle(pg,3500)
    base=stored(pg);n0=len(pg.evaluate("__SETLOG"))
    # --- 1) o "Salvo" só depois de gravar
    pg.evaluate("__ENC_DELAY=600");pg.evaluate("(()=>{S.limits=S.limits||{};S.limits['Casa']=5000;commit('Limite salvo ✓')})()");pg.wait_for_timeout(200)
    mid=stored(pg);t1=tx(pg)
    ok('Antes de terminar a criptografia: o aviso "Salvo" NÃO aparece e o armazenamento ainda tem a versão anterior',('salvo' not in t1.lower()) and not (mid.get('limits') or {}).get('Casa'),(t1,mid.get('limits')))
    pg.wait_for_timeout(800);t2=tx(pg);after=stored(pg)
    ok('Depois que a gravação termina com sucesso: aparece "Limite salvo ✓" e o armazenamento já tem o dado novo (conferido descriptografando)',t2=='Limite salvo ✓' and (after.get('limits') or {}).get('Casa')==5000,(t2,after.get('limits')))
    # --- 1b) aviso que não é de salvar espera junto; mas aparece
    pg.evaluate("__ENC_DELAY=400");pg.evaluate("(()=>{S.limits['Lazer']=1000;save();toast('Aviso qualquer')})()");pg.wait_for_timeout(120);a1=tx(pg);pg.wait_for_timeout(700);a2=tx(pg)
    ok('Qualquer aviso emitido durante uma gravação espera o fim dela (nada de confirmar antes da hora) e depois aparece normalmente',('Aviso' not in a1) and a2=='Aviso qualquer',(a1,a2))
    # --- 2) falhas
    for lbl,flag in (('falha na criptografia','__ENC_FAIL'),('gravação recusada (armazenamento cheio)','__SET_FAIL'),('gravação que "some" (não passa na conferência)','__SET_NOOP')):
        pg.evaluate("__ENC_DELAY=0");pg.evaluate(f"{flag}=1");prev=stored(pg);ds=pg.evaluate("SECOBJ.d.ct")
        pg.evaluate("(()=>{S.limits['Teste_"+flag[2:6]+"']=777;commit('Limite salvo ✓')})()");pg.wait_for_timeout(700);t=tx(pg)
        ok(f'Erro ({lbl}): aviso claro "Não foi possível salvar", sem nenhum "salvo ✓", e o armazenamento continua com a versão anterior íntegra',('Não foi possível salvar' in t) and ('✓' not in t) and stored(pg).get('limits')==prev.get('limits') and pg.evaluate("SECOBJ.d.ct")==ds,(t,))
        pg.evaluate(f"{flag}=0");pg.wait_for_timeout(100)
    pg.evaluate("(()=>{S.limits['Depois']=888;commit('Limite salvo ✓')})()");settle(pg);st=stored(pg)
    ok('Depois que o problema passa, a próxima gravação leva TUDO (as mudanças que tinham falhado também): estado completo e consistente',st['limits'].get('Depois')==888 and st['limits'].get('Teste_ENC_')==777 and st['limits'].get('Teste_SET_')==777 and tx(pg)=='Limite salvo ✓',st['limits'])
    # --- 3) salvamentos consecutivos e ordem
    pg.evaluate("__SETLOG.length=0;__ENC_DELAY=()=>Math.random()<.5?250:15")
    pg.evaluate("(async()=>{for(let i=1;i<=14;i++){S.__seq=i;S.limits['seq']=i*100;save();if(i%3===0)await new Promise(r=>setTimeout(r,20))}})()");settle(pg,500)
    seqs=pg.evaluate("(async()=>{const out=[];for(const v of __SETLOG){const o=JSON.parse(v);out.push(JSON.parse(dec.decode(await unseal(DEK,o.d))).__seq)}return out})()");fin=stored(pg)
    ok('14 salvamentos seguidos com tempos de criptografia embaralhados: as gravações saem sempre em ordem (nunca uma versão antiga depois de uma nova) e a última é a mais recente',all(seqs[i]<=seqs[i+1] for i in range(len(seqs)-1)) and seqs[-1]==14 and fin['__seq']==14 and fin['limits']['seq']==1400,seqs)
    ok('Só grava o que precisa: no máximo uma gravação por salvamento (as intermediárias podem ser agrupadas) e o armazenamento == estado atual',len(seqs)<=14 and pg.evaluate("JSON.stringify(S)")==json.dumps(fin,separators=(',',':'),ensure_ascii=False) or json.loads(pg.evaluate("JSON.stringify(S)"))==fin,(len(seqs)))
    # --- 4) formato preservado
    keys=sorted(pg.evaluate("Object.keys(JSON.parse(localStorage.getItem('wallstreet.sec')))"));ok('A criptografia e o formato guardado são os mesmos de antes (mesmas chaves: v,u,it,s,w,ri,rs,r,d)',keys==sorted(['v','u','it','s','w','ri','rs','r','d']),keys)
    # --- 5) navegação rápida e reabrir
    pg.evaluate("__ENC_DELAY=300");pg.evaluate("(()=>{S.__marca='nav-'+Date.now();window.__M=S.__marca;S.limits['nav']=4242;save()})()")
    for v in ('rel','des','rec','div','cx','cfg','home','rel'):pg.evaluate(f"go('{v}')")
    settle(pg,300);m=pg.evaluate("__M");pg.reload();login(pg)
    ok('Navegar rapidamente entre telas logo após salvar e depois fechar/reabrir: o dado está lá, íntegro',pg.evaluate("S.__marca")==m and pg.evaluate("S.limits.nav")==4242,pg.evaluate("S.__marca"))
    # --- 6) fechar durante o salvamento
    pg.evaluate("__ENC_DELAY=900");pg.evaluate("(()=>{S.__marca='fecha';S.limits['fecha']=1;save()})()");pg.wait_for_timeout(100)
    guard=pg.evaluate("(()=>{const e=new Event('beforeunload',{cancelable:true});window.dispatchEvent(e);return e.defaultPrevented})()")
    ok('Fechar a página enquanto grava dispara o aviso do navegador ("há alterações sendo salvas")',guard is True)
    pg.evaluate("window.dispatchEvent(new Event('pagehide'));document.dispatchEvent(new Event('visibilitychange'))");settle(pg,200)
    g2=pg.evaluate("(()=>{const e=new Event('beforeunload',{cancelable:true});window.dispatchEvent(e);return e.defaultPrevented})()")
    ok('Passou a gravação (mesmo com pagehide/visibilitychange no meio): o aviso de fechar some e o dado foi gravado',g2 is False and stored(pg)['limits'].get('fecha')==1)
    pg.evaluate("__ENC_DELAY=900");pg.evaluate("(()=>{S.limits['abrupto']=2;save()})()");pg.wait_for_timeout(150);pg.reload()   # fecha no meio
    login(pg);ab=pg.evaluate("S.limits.abrupto")
    ok('Fechar de verdade no meio da gravação: o armazenamento continua íntegro (abre com a senha, sem corrupção) — tem a versão nova ou a anterior, nunca algo quebrado',ab in (None,2) and pg.evaluate("S.limits.fecha")==1,ab)
    # --- 7) travar o app (lockNow) e perder a chave durante a gravação
    pg.evaluate("__ENC_DELAY=500");pg.evaluate("(()=>{S.limits['trava']=3;save();lockNow()})()");pg.wait_for_selector('#lf',timeout=20000);login(pg)
    ok('Bloquear o app (lockNow) logo após salvar espera a gravação terminar: nada se perde',pg.evaluate("S.limits.trava")==3)
    pg.evaluate("__ENC_DELAY=400");pg.evaluate("(()=>{S.limits['semchave']=4;save();DEK=null})()");pg.wait_for_timeout(900);t=tx(pg);pg.evaluate("DEK=null") 
    pg.reload();login(pg);ok('Se a chave sair da memória durante a gravação (sair/bloquear), a gravação em andamento termina com a chave capturada: sem erro e sem perda',('Não foi possível' not in t) and pg.evaluate("S.limits.semchave")==4,t)
    ok('Sem erros no console (modo protegido)',not pg.errs,pg.errs[:3]);c.close()
    # ================= MODO NORMAL =================
    c=newctx();pg=mkpage(c);create(pg,pw=False)
    pg.evaluate("__SETLOG.length=0;(()=>{S.limits=S.limits||{};S.limits['Casa']=1500;commit('Limite salvo ✓')})()");t=tx(pg);k=json.loads(pg.evaluate("localStorage.getItem('wallstreet.v1')"))
    ok('Modo normal: a gravação é imediata; aparece "Limite salvo ✓" e o dado já está no armazenamento (1 gravação)',t=='Limite salvo ✓' and k['limits']['Casa']==1500 and len(pg.evaluate("__SETLOG"))==1,(t,))
    pg.evaluate("__SETK_FAIL=1");prev=pg.evaluate("localStorage.getItem('wallstreet.v1')");pg.evaluate("(()=>{S.limits['X']=9;commit('Limite salvo ✓')})()");t=tx(pg)
    ok('Modo normal com falha de gravação: erro claro ("Não foi possível salvar…"), sem "Salvo ✓", e o armazenamento mantém a versão anterior',('Não foi possível salvar' in t) and ('✓' not in t) and pg.evaluate("localStorage.getItem('wallstreet.v1')")==prev,t)
    pg.evaluate("__SETK_FAIL=0;(()=>{S.limits['Y']=10;commit('Limite salvo ✓')})()");k=json.loads(pg.evaluate("localStorage.getItem('wallstreet.v1')"));ok('Passando o problema, o próximo salvamento leva tudo',k['limits'].get('X')==9 and k['limits'].get('Y')==10)
    ok('Aviso normal (sem gravação em andamento) continua imediato',(pg.evaluate("toast('Olá imediato')"),tx(pg))[1]=='Olá imediato')
    ok('Sem erros no console (modo normal)',not pg.errs,pg.errs[:3]);c.close()
    # ================= DUAS JANELAS =================
    c=newctx();A=mkpage(c);create(A);A.evaluate("(()=>{S.limits=S.limits||{};S.limits['aq']=1;commit('x')})()");settle(A,3500);B=c.new_page();B.errs=[];B.on('pageerror',lambda e:B.errs.append(str(e)));B.goto(URL);login(B)
    A.evaluate("(()=>{S.limits=S.limits||{};S.limits['deA']=111;commit('Limite salvo ✓')})()");settle(A,300);B.wait_for_timeout(600)
    ok('Duas janelas (protegido): quando a janela A grava, a janela B é avisada ("alterados em outra janela") e pede para recarregar',B.evaluate("STALE")==True and 'outra janela' in B.inner_text('#ov'),B.evaluate("document.getElementById('ov').innerText")[:100])
    B.evaluate("(()=>{S.limits['deB']=222;const r=save();window.__R=r})()");B.wait_for_timeout(500)
    ok('A janela B (desatualizada) NÃO consegue gravar: nada é sobrescrito e os dados de A continuam',B.evaluate("__R")==False and A.evaluate(STORED).get('limits',{}).get('deA')==111 and 'deB' not in A.evaluate(STORED)['limits'] and len(B.evaluate("__SETLOG"))==0)
    B.click('[data-act=yes]');B.wait_for_load_state();login(B)
    ok('Confirmando o aviso, B recarrega, entra e já vê os dados novos de A; a partir daí consegue salvar normalmente',B.evaluate("S.limits.deA")==111 and B.evaluate("STALE")==False and (B.evaluate("(()=>{S.limits['deB']=222;return save()})()"),settle(B,300),A.evaluate(STORED)['limits'].get('deB'))[2]==222)
    ok('Sem erros no console (duas janelas)',not A.errs and not B.errs,(A.errs+B.errs)[:3])
    # aba na tela de login enquanto outra grava
    C=c.new_page();C.errs=[];C.goto(URL);C.wait_for_selector('#lf',timeout=20000)
    B.evaluate("(()=>{S.limits['deB2']=333;commit('Limite salvo ✓')})()");settle(B,300);C.wait_for_timeout(500)
    login(C);ok('Aba parada na tela de login enquanto outra janela grava: ao entrar ela já abre com os dados MAIS RECENTES (e pode salvar normalmente)',C.evaluate("S.limits.deB2")==333 and C.evaluate("STALE")==False)
    c.close()
    # normal, duas janelas
    c=newctx();A=mkpage(c);create(A,pw=False);A.evaluate("(()=>{S.limits=S.limits||{};S.limits['aq']=1;commit('x')})()");A.wait_for_timeout(3500);B=c.new_page();B.errs=[];B.on('pageerror',lambda e:B.errs.append(str(e)));B.goto(URL);B.wait_for_selector('#s-home',timeout=20000);B.wait_for_timeout(1500)
    A.evaluate("(()=>{S.limits=S.limits||{};S.limits['deA']=1;commit('Limite salvo ✓')})()");B.wait_for_timeout(600)
    B.evaluate("(()=>{S.limits=S.limits||{};S.limits['deB']=2;window.__R=save()})()");B.wait_for_timeout(300);kk=json.loads(A.evaluate("localStorage.getItem('wallstreet.v1')"))
    ok('Duas janelas (modo normal): a desatualizada não sobrescreve os dados novos',B.evaluate("__R")==False and kk['limits'].get('deA')==1 and 'deB' not in kk['limits'],(kk['limits']))
    ok('Sem erros no console (normal, duas janelas)',not A.errs and not B.errs,(A.errs+B.errs)[:3]);c.close()
print(sum(R),'/',len(R))
