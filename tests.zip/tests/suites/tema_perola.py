import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re,os
pass
from playwright.sync_api import sync_playwright
from contrast import measure
URL=os.environ.get('WS_URL',HTTP_URL)
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:230] if d else ''))
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
PAL=['blue','perola','violet','teal','pink','orange','ouro','esmeralda','grafite']
SRC=open(ROOT+'/index.html',encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,pre=None):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=w<600,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1")
        if pre:c.add_init_script(pre)
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return c,pg
    def to_color(pg,name='Paul'):
        pg.goto(URL);pg.wait_for_selector('#mf');pg.wait_for_timeout(500);pg.click('#mf .mcrow >> nth=0');pg.click('#mgo');pg.wait_for_selector('#cf');pg.wait_for_timeout(500)
    def cf_to_sf(pg,name='Paul'):
        pg.click('#cf button:not([type=button])');pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=new]');pg.wait_for_selector('#nf');pg.fill('#nf [name=n]',name);pg.click('#nf button');pg.wait_for_selector('#sf')
    dp=lambda pg:pg.evaluate("document.documentElement.dataset.pal")
    dt=lambda pg:pg.evaluate("document.documentElement.dataset.theme")
    # ===== padrão =====
    c,pg=ctx();pg.goto(URL,wait_until='domcontentloaded')
    ok('Primeira visita: o Azul (cor padrão) já está aplicado desde o primeiro quadro (antes mesmo do app carregar), em modo claro',dp(pg)=='blue' and dt(pg)=='light')
    pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(500)
    ok('O padrão do app novo é o Azul (preferências iniciais), com o modo claro',pg.evaluate("S.pref.pal")=='blue' and pg.evaluate("S.pref.theme")=='light' and pg.evaluate("seed().pref.pal")=='blue')
    pg.evaluate("S.pref.pal='perola';applyPref()");pg.wait_for_timeout(150);ok('Quando escolhida, a cor-base da Pérola é #E8EDF5 (fundo perolizado) e o acento é azul-ardósia escuro (botões legíveis)',pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--b2').trim().toLowerCase()")=='#e8edf5' and pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--btn1').trim().toLowerCase()")=='#475c82',pg.evaluate("[getComputedStyle(document.documentElement).getPropertyValue('--b2'),getComputedStyle(document.documentElement).getPropertyValue('--btn1')]"));pg.evaluate("S.pref.pal='blue';applyPref()");pg.wait_for_timeout(100)
    ok('Sem erros no console (primeira visita)',not pg.errs,pg.errs);c.close()
    # ===== etapa de cor no cadastro =====
    c,pg=ctx();to_color(pg)
    ok('Fluxo: mascote → etapa "Escolha sua aparência" (antes de boas-vindas, nome e senha)',('Escolha sua aparência' in pg.inner_text('#lock h2')) and pg.locator('#sf').count()==0)
    names=pg.evaluate("[...document.querySelectorAll('#lock .cpals .pal')].map(b=>b.textContent.trim())")
    ok('As 9 cores aparecem em grade organizada, com o Azul (padrão) em primeiro lugar e a Pérola mantida',names==['Azul','Pérola','Violeta','Turquesa','Rosa','Laranja','Ouro','Esmeralda','Grafite'],names)
    ok('O Azul já vem selecionado (e a bolinha dele é a cor #2563EB)',pg.evaluate("document.querySelector('.cpals .pal.on').dataset.id")=='blue' and pg.locator('.cpals .pal.on').count()==1 and pg.evaluate("getComputedStyle(document.querySelector('.cpals .pal i')).backgroundColor")=='rgb(37, 99, 235)')
    ok('Acessível: grupo de opções (radiogroup) com estado marcado',pg.evaluate("document.querySelector('.cpals').getAttribute('role')")=='radiogroup' and pg.evaluate("[...document.querySelectorAll('.cpals .pal')].filter(b=>b.getAttribute('aria-checked')==='true').length")==1)
    r=[]
    for k in PAL[1:]+['perola']:
        pg.click(f'.cpals .pal[data-id={k}]');pg.wait_for_timeout(100)
        r.append(dp(pg)==k and pg.evaluate("document.querySelector('.cpals .pal.on').dataset.id")==k and pg.evaluate("S.pref.pal")==k)
    ok('Pré-visualização ao vivo: ao tocar em cada cor, o app inteiro muda na hora, o item fica marcado e a escolha é guardada',all(r),r)
    pg.click('[data-lk=cmode][data-id=dark]');pg.wait_for_timeout(200);ok('Os botões Claro/Escuro da etapa trocam o modo na hora',dt(pg)=='dark' and pg.evaluate("document.querySelector('[data-lk=cmode][data-id=dark]').classList.contains('b1')"))
    pg.click('.lkth');pg.wait_for_timeout(300);ok('O botão sol/lua do canto também fica em sincronia com Claro/Escuro da etapa',dt(pg)=='light' and pg.evaluate("document.querySelector('[data-lk=cmode][data-id=light]').classList.contains('b1')"))
    pg.click('[data-lk=cpick][data-id=violet]');pg.click('[data-lk=cmode][data-id=dark]');pg.wait_for_timeout(200)
    pg.click('[data-lk=backmasc]');pg.wait_for_selector('#mf');pg.click('#mgo');pg.wait_for_selector('#cf');ok('Voltar para o mascote e avançar de novo mantém a cor e o modo escolhidos',dp(pg)=='violet' and dt(pg)=='dark' and pg.evaluate("document.querySelector('.cpals .pal.on').dataset.id")=='violet')
    cf_to_sf(pg,'Ana');ok('Continuar leva (boas-vindas e nome) à senha, já no tema escolhido',dp(pg)=='violet' and dt(pg)=='dark')
    pg.click('[data-lk=backname]');pg.wait_for_selector('#nf');pg.click('[data-lk=backwel]');pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=backcolor]');pg.wait_for_selector('#cf');ok('Voltar da senha retorna, passo a passo, à etapa de cor',pg.locator('#cf').count()==1);cf_to_sf(pg,'Ana')
    pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(3500)
    ok('Cadastro concluído: a Home já abre na cor e no modo escolhidos (Violeta, escuro) e a escolha vai para a conta',dp(pg)=='violet' and dt(pg)=='dark' and pg.evaluate("S.pref.pal")=='violet' and pg.evaluate("S.pref.theme")=='dark')
    lk=json.loads(pg.evaluate("localStorage.getItem('wallstreet.look')"));ok('A escolha é espelhada para a tela de login (p e t em wallstreet.look)',lk.get('p')=='violet' and lk.get('t')=='dark',lk)
    pg.wait_for_timeout(1500);pg.reload();pg.wait_for_selector('#lf',timeout=20000);pg.wait_for_timeout(500)
    ok('Próximos acessos: a tela de login já aparece no tema escolhido (Violeta, escuro)',dp(pg)=='violet' and dt(pg)=='dark')
    pg.fill('#lf [name=u]','ana');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1200)
    ok('Depois de entrar, o app continua no tema escolhido',dp(pg)=='violet' and dt(pg)=='dark' and pg.evaluate("S.pref.pal")=='violet')
    pg.evaluate("go('cfg')");pg.wait_for_timeout(300)
    ok('Em Ajustes → Aparência as 9 cores continuam disponíveis (Azul primeiro, Pérola mantida) e a escolhida aparece marcada',pg.evaluate("[...document.querySelectorAll('#s-cfg .pals .pal')].map(b=>b.dataset.id)")==PAL and pg.evaluate("document.querySelector('#s-cfg .pals .pal.on').dataset.id")=='violet')
    ok('Sem erros no console (cadastro com cor)',not pg.errs,pg.errs);c.close()
    # ===== sem escolher
    c,pg=ctx();to_color(pg,'Ana');cf_to_sf(pg,'Ana');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1500)
    ok('Quem só toca em Continuar fica com o Azul (claro), o padrão',dp(pg)=='blue' and dt(pg)=='light' and pg.evaluate("S.pref.pal")=='blue');c.close()
    c,pg=ctx();pg.goto(URL);OB_NOSEC(pg,'Bia');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(600)
    ok('"Usar sem senha": entra direto no Azul (sem a etapa); dá para trocar em Ajustes → Aparência',dp(pg)=='blue' and pg.locator('#cf').count()==0);pg.evaluate("go('cfg')");pg.click('#s-cfg .pal[data-id=perola]');pg.wait_for_timeout(300);ok('Trocar para a Pérola em Ajustes funciona e fica salvo',dp(pg)=='perola' and pg.evaluate("S.pref.pal")=='perola' and pg.evaluate("JSON.parse(localStorage.getItem('wallstreet.v1')).pref.pal")=='perola');c.close()
    # ===== quem já usa o app não é afetado
    for pal,th in (('blue','light'),('grafite','dark'),('ouro','light')):
        c,pg=ctx(pre="localStorage.setItem('wallstreet.welcomed','1');localStorage.setItem('wallstreet.secskip','1');localStorage.setItem('wallstreet.look',JSON.stringify({t:'%s',p:'%s',g:1,m:'terno',a:0,s:0}));localStorage.setItem('wallstreet.v1',JSON.stringify({v:2,owner:'Antigo',opening:null,limits:{},ntf:{read:{}},pref:{theme:'%s',pal:'%s',av:{v:2,m:0,an:1,set:0}},items:[],inst:[],parc:[],debts:[],boxes:[]}))"%(th,pal,th,pal))
        pg.goto(URL,wait_until='domcontentloaded');first=dp(pg);pg.wait_for_selector('#s-home .mqc');pg.wait_for_timeout(1200)
        ok(f'Usuário que já usa o app com a cor {pal} ({th}): continua exatamente nela — desde o primeiro quadro e depois de carregar (a Pérola não troca nada)',first==pal and dp(pg)==pal and dt(pg)==th and pg.evaluate("S.pref.pal")==pal,(first,dp(pg)));c.close()
    c,pg=ctx(pre="localStorage.setItem('wallstreet.welcomed','1');localStorage.setItem('wallstreet.secskip','1');localStorage.setItem('wallstreet.v1',JSON.stringify({v:2,owner:'Antigo',opening:null,limits:{},ntf:{read:{}},pref:{theme:'light',pal:'xyz',av:{v:2,m:0,an:1,set:0}},items:[],inst:[],parc:[],debts:[],boxes:[]}))")
    pg.goto(URL);pg.wait_for_selector('#s-home .mqc');pg.wait_for_timeout(1000);ok('Cor desconhecida/corrompida nos dados vira o Azul (padrão), sem erro',dp(pg)=='blue' and not pg.errs,pg.errs);c.close()
    c,pg=ctx();pg.goto(URL);OB_NOSEC(pg,'Bia');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(600)
    pg.evaluate("importObj(Object.assign(JSON.parse(JSON.stringify(S)),{pref:Object.assign({},S.pref,{pal:'blue',theme:'dark'})}))");pg.click('[data-act=yes]');pg.wait_for_timeout(500);ok('Importar um backup com a cor Azul/escuro restaura essa cor (backups antigos continuam fiéis)',dp(pg)=='blue' and dt(pg)=='dark');c.close()
    # ===== a paleta Azul continua igual
    css=re.search(r'<style>(.*?)</style>',SRC,re.S).group(1)
    ok('A paleta Azul não foi alterada: continua com as mesmas cores do padrão antigo (#2563EB / #1D4ED8)',':root{--navy:#0B1730;--blue:#2563EB' in css and '--btn1:#2563EB;--btn2:#1D4ED8' in css)
    # ===== layout e contraste
    for (w,h) in ((320,568),(393,851),(851,393),(1280,800)):
        for th in ('light','dark'):
            c,pg=ctx(w,h);pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.evaluate(f"S.pref.theme='{th}';applyPref()");pg.wait_for_selector('#mf');pg.click('#mf .mcrow >> nth=0');pg.click('#mgo');pg.wait_for_selector('#cf');pg.wait_for_timeout(700)
            g=pg.evaluate("(()=>{const l=document.querySelector('#lock .lk').getBoundingClientRect(),bs=[...document.querySelectorAll('.cpals .pal')].map(b=>b.getBoundingClientRect());return{ov:"+OVER+",inside:bs.every(r=>r.left>=l.left-1&&r.right<=l.right+1),min:Math.min(...bs.map(r=>Math.min(r.width,r.height))),cols:new Set(bs.map(r=>Math.round(r.left))).size}})()")
            pg.evaluate("document.querySelector('#cf button:not([type=button])').scrollIntoView({block:'center'})");pg.wait_for_timeout(200);vis=pg.evaluate("(()=>{const e=document.querySelector('#cf button:not([type=button])'),r=e.getBoundingClientRect(),t=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return r.top>=0&&r.bottom<=innerHeight+1&&e.contains(t)})()")
            ok(f'{w}x{h} [{th}]: etapa de cor sem rolagem lateral, 3 colunas dentro do painel (alvo ≥ 44 px) e Continuar alcançável',g['ov'] and g['inside'] and g['min']>=44 and g['cols']==3 and vis,(g,vis));c.close()
    for th in ('light','dark'):
        c,pg=ctx();pg.goto(URL);OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(3800)
        pg.evaluate("(()=>{"+open(FIX+'/legacy_seed.js',encoding='utf-8').read()+";const o=legacySeed();o.pref=S.pref;o.owner=S.owner;S=o;migrate(S);S.pref.ma=0;S.pref.ms='terno';S.pref.pal='perola';S.pref.theme='"+th+"';save();render()})()");pg.wait_for_timeout(1500)
        bad=[];tot=0
        for v in ('home','rec','des','div','cx','rel','cfg','nt','cc'):
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(1300)
            for sc in ('content','nav'):
                for x in measure(pg,sc):
                    tot+=1
                    if x[0]<x[1]:bad.append((v,sc)+x)
        ok(f'[{th}] Pérola: contraste de {tot} textos em Home, Receitas, Despesas, Dívidas, Caixinhas, Relatórios, Ajustes, Anotações e Cartões — mínimo 4,5:1',not bad and tot>200,bad[:4]);c.close()
    for th in ('light','dark'):
        c,pg=ctx();to_color(pg);pg.evaluate(f"S.pref.theme='{th}';applyPref()");pg.wait_for_timeout(900);bad=[x for x in measure(pg,'lock') if x[0]<x[1]];tot=len(measure(pg,'lock'))
        ok(f'[{th}] Contraste dos textos da etapa de cor com a Pérola ({tot} medidos) — mínimo 4,5:1',not bad and tot>8,bad[:3]);c.close()
print(sum(R),'/',len(R))
