"""Identidade Wolfin: nome, slogan, título, metadados, manifesto, ausência da marca antiga em tudo que o usuário vê,
e COMPATIBILIDADE: os identificadores internos (chaves de armazenamento, cache, marca do backup) não mudaram, então uma conta
criada pela versão anterior abre no Wolfin com os mesmos dados e a mesma senha (fixture legacy/conta_protegida_v55.json)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html');man=json.loads(rd('manifest.webmanifest'));sw=rd('sw.js')
SLOGAN='Domine seu dinheiro.';OLD=re.compile(r'wall\s*street',re.I)
INTERNO=re.compile(r"wallstreet(?:\.[a-z]+|::|-backup|-guard|-v|-bot)|/wallstreet/|@wallstreet")   # identificadores internos permitidos (compatibilidade)
sem_internos=lambda t:INTERNO.sub('',t)
# ---------- código e metadados ----------
ok('Título da página: "Wolfin – Controle Financeiro"','<title>Wolfin – Controle Financeiro</title>' in html)
ok('Metadados: nome do aplicativo, título no iOS, descrição (SEO) com o slogan e Open Graph','name="application-name" content="Wolfin"' in html and 'apple-mobile-web-app-title" content="Wolfin"' in html and 'name="description"' in html and SLOGAN in html.split('name="description" content="')[1].split('"')[0] and 'og:title" content="Wolfin – Controle Financeiro"' in html and 'og:description" content="Domine seu dinheiro."' in html)
ok('Manifesto PWA: nome "Wolfin – Controle Financeiro", nome na tela inicial "Wolfin" (≤ 12), descrição = slogan',man['name']=='Wolfin – Controle Financeiro' and man['short_name']=='Wolfin' and len(man['short_name'])<=12 and man['description']==SLOGAN)
ok('Manifesto: identidade do PWA preservada (id, start_url, scope iguais) — o app instalado continua o mesmo',man['id']=='./' and man['start_url']=='./' and man['scope']=='./' and len(man['icons'])==3)
ok('Nenhuma referência visível à marca antiga no código do app nem ao slogan antigo — só sobram identificadores internos de compatibilidade',not OLD.search(sem_internos(html)) and 'Seu dinheiro, sob controle' not in html,[x.group(0) for x in OLD.finditer(sem_internos(html))][:3])
ok('Manifesto, Service Worker e documentação sem a marca antiga',not OLD.search(json.dumps(man,ensure_ascii=False)) and not OLD.search(sem_internos(sw)) and not re.search(r'WALL STREET|Wall Street',rd('LEIA-ME.md')))
# ---------- compatibilidade (nada interno foi renomeado) ----------
internos=["KEY='wallstreet.v1'","SECK='wallstreet.sec'","FK='wallstreet.fail'","'wallstreet.look'","'wallstreet.welcomed'","app:'wallstreet-backup'","'wallstreet::'"]
ok('Identificadores internos preservados (dados, senha, tentativas, backups e cache): nada foi renomeado, então ninguém perde dados nem refaz a senha',all(x in html or x in sw for x in internos),[x for x in internos if x not in html and x not in sw])
ok('Backups: o marcador interno do formato continua "wallstreet-backup" (arquivos antigos seguem aceitos) e os novos arquivos se chamam wolfin-backup-…',"o.app==='wallstreet-backup'" in html and "'wolfin-backup-'" in html and "'wolfin-backup-criptografado-'" in html)
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(init=None,rm=False):
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo',accept_downloads=True);c.add_init_script("window.__WS_NOTOUR=1")
        if init:c.add_init_script(init)
        return c
    def errs(pg):
        pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
    # ---------- tela de boas-vindas ----------
    c=ctx();pg=c.new_page();errs(pg);pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=new]');pg.wait_for_timeout(800)
    t=pg.inner_text('#lock')
    ok('Boas-vindas: nome WOLFIN em destaque e o slogan "Domine seu dinheiro."','WOLFIN' in t and SLOGAN in t and pg.inner_text('#lock h1')=='WOLFIN',t[:80])
    ok('Boas-vindas: título da aba "Wolfin – Controle Financeiro" e mascote descrito como "mascote do Wolfin"',pg.title()=='Wolfin – Controle Financeiro' and 'mascote do Wolfin' in pg.evaluate("document.querySelector('#lock .wolf').getAttribute('aria-label')"))
    ok('Boas-vindas: nada da marca antiga na tela',not OLD.search(pg.evaluate("document.body.innerText+' '+[...document.querySelectorAll('[aria-label],[title],img[alt]')].map(e=>(e.getAttribute('aria-label')||'')+(e.title||'')+(e.alt||'')).join(' ')")))
    pg.click('[data-lk=new]');pg.fill('#nf [name=n]','Teste');pg.click('#nf button');pg.wait_for_selector('#mf');pg.click('#mf .b1');pg.wait_for_selector('#cf');pg.click('#cf button:not([type=button])');pg.wait_for_selector('#sf');pg.wait_for_timeout(900)
    t=pg.inner_text('#lock');ok('Tela de criação do acesso (senha): com o nome WOLFIN e o slogan, sem marca antiga (e "Proteger o Wolfin" nas Ajustes)','WOLFIN' in t and SLOGAN in t and 'Crie seu acesso' in t and not OLD.search(t) and "'Proteger o Wolfin'" in html,t[:100]);c.close()
    # ---------- dentro do app: todas as telas, janelas, títulos, backup ----------
    c=ctx();pg=c.new_page();errs(pg);pg.goto(FILE_URL);pg.wait_for_selector('[data-lk=nosec]');pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Teste');pg.click('#nf button');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(900)
    pg.evaluate("S="+open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()+";S.org=S.org||{};save();go('home')");pg.wait_for_timeout(500)
    bad=[];titles={}
    for v in ['home','rec','des','div','cx','rel','cfg','nt','cc','ntf','conq']:
        pg.evaluate(f"go('{v}')");pg.wait_for_timeout(350)
        txt=pg.evaluate("(()=>{const s=document.getElementById(VIEWS[view][3]);return s.innerText+' '+[...s.querySelectorAll('[aria-label],[title],img[alt]')].map(e=>(e.getAttribute('aria-label')||'')+' '+(e.title||'')+' '+(e.alt||'')).join(' ')})()");titles[v]=pg.title()
        if OLD.search(txt):bad.append(v)
    ok('Nenhuma referência visível à marca antiga em 11 telas do app (texto, rótulos de acessibilidade, dicas)',not bad,bad)
    ok('Cada tela tem o título da página no formato "Tela · Wolfin"',all(t.endswith(' · Wolfin') for t in titles.values()),titles)
    pg.evaluate("go('home')");pg.wait_for_timeout(400);hero=pg.inner_text('#s-home .hero')
    ok('Home: o cartão principal mostra "WOLFIN · Domine seu dinheiro."','WOLFIN · Domine seu dinheiro.' in hero,hero[:90])
    pg.evaluate("go('cfg')");pg.wait_for_timeout(400);ab=pg.inner_text('#s-cfg')
    ok('Ajustes → Sobre: "Wolfin", o slogan e o texto institucional falam do Wolfin (sem marca antiga)','Wolfin' in ab and SLOGAN in ab and 'O Wolfin é uma ferramenta' in ab and not OLD.search(ab),ab[ab.find('Wolfin')-20:ab.find('Wolfin')+60] if 'Wolfin' in ab else ab[-200:])
    for nm,js in (('formulário',"form('Teste',[{k:'a',l:'Campo',v:''}],()=>{})"),('confirmação',"ask('Certeza?',()=>{})"),('seletor de avatar','ACT.avs()')):
        pg.evaluate(js);pg.wait_for_timeout(350);ok(f'Janela ({nm}): sem marca antiga',not OLD.search(pg.inner_text('#ov')));pg.evaluate('closeOv()')
    pg.evaluate("go('cfg')");pg.wait_for_timeout(300)
    with pg.expect_download() as dl:pg.evaluate("ACT.exp()")
    fn=dl.value.suggested_filename;ok('Exportar backup comum: o arquivo se chama "wolfin-backup-AAAA-MM-DD.json"',bool(re.match(r'^wolfin-backup-\d{4}-\d\d-\d\d\.json$',fn)),fn)
    okb=json.loads(open(dl.value.path(),encoding='utf-8').read());ok('O conteúdo do backup mantém o marcador interno de compatibilidade (importável por versões antigas e novas)',okb['__backup']['app']=='wallstreet-backup')
    pg.evaluate("go('home');tourStart(true)");pg.wait_for_selector('#tour');pg.wait_for_timeout(500)
    ok('Tutorial: janela "Tutorial do Wolfin"',pg.evaluate("document.getElementById('tour').getAttribute('aria-label')")=='Tutorial do Wolfin')
    for i in range(7):pg.click('#tour [data-tr=next]');pg.wait_for_timeout(250)
    tt=pg.inner_text('#tour .tx');ok('Tutorial (último passo): boas-vindas ao Wolfin com o slogan "domine seu dinheiro"','Wolfin' in tt and 'domine seu dinheiro' in tt.lower(),tt);pg.click('#tour [data-tr=skip]')
    ok('Notificações e lembretes (.ics) usam o nome Wolfin: título "Wolfin · …", PRODID e nome do arquivo',"'Wolfin · '+r.t" in html and 'PRODID:-//Wolfin//Lembretes//PT' in html and 'lembrete-wolfin.ics' in html)
    ok('Sem erros de JavaScript',not pg.errs,pg.errs[:2]);c.close()
    # ---------- compatibilidade: conta protegida criada pela versão ANTERIOR ----------
    fx=json.load(open(os.path.join(FIX,'legacy','conta_protegida_v55.json'),encoding='utf-8'))
    init="".join(f"localStorage.setItem({json.dumps(k)},{json.dumps(v)});" for k,v in fx['chaves'].items())
    c=ctx(init);pg=c.new_page();errs(pg);pg.goto(HTTP_URL);pg.wait_for_selector('#lf',timeout=20000);pg.wait_for_timeout(500)
    ok('Conta criada antes da mudança de nome: o Wolfin reconhece e mostra a tela de login (não pede cadastro novo)',pg.locator('#lf').count()==1 and pg.inner_text('#lock h1')=='WOLFIN',pg.inner_text('#lock')[:60])
    pg.fill('#lf [name=u]',fx['usuario']);pg.fill('#lf [name=p]',fx['senha']);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1200)
    got=pg.evaluate("({owner:S.owner,balance:balance(),items:S.items.map(i=>i.id),debts:S.debts.map(d=>d.id)})");ex=fx['esperado']
    ok('Entra com a MESMA senha e todos os dados estão lá (nome, saldo, receitas/despesas e dívidas)',got['owner']==ex['owner'] and got['balance']==ex['balance'] and got['items']==ex['items'] and got['debts']==ex['debts'],(got,ex))
    ok('O armazenamento protegido não foi reescrito nem trocado ao abrir (mesma criptografia, mesma chave guardada)',pg.evaluate("localStorage.getItem('wallstreet.sec')")==fx['chaves']['wallstreet.sec'] or pg.evaluate("JSON.parse(localStorage.getItem('wallstreet.sec')).w")==json.loads(fx['chaves']['wallstreet.sec'])['w'])
    ok('Sem erros de JavaScript (conta antiga)',not pg.errs,pg.errs[:2]);c.close()
    c=ctx(init);pg=c.new_page();errs(pg);pg.goto(HTTP_URL);pg.wait_for_selector('#lf',timeout=20000)
    pg.click('[data-lk=rec]');pg.wait_for_selector('#rf');pg.fill('#rf [name=k]',fx['codigo_recuperacao']);pg.fill('#rf [name=u]','novo');pg.fill('#rf [name=p]','NovaSenha-456!');pg.fill('#rf [name=c]','NovaSenha-456!');pg.click('#rf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000)
    pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1000)
    ok('Código de recuperação da conta antiga funciona no Wolfin: entra, mantém todos os dados e gera código novo',pg.evaluate("balance()")==ex['balance'] and pg.evaluate("S.items.length")==len(ex['items']),pg.evaluate("balance()"));c.close()
print(sum(R),'/',len(R))
