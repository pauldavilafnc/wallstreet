import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,os,json,time,shutil,tempfile,re
pass
from playwright.sync_api import sync_playwright
URL=os.environ.get('WS_URL',HTTP_URL)
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
PW='Senha-Forte-123';U='paul'
INIT="window.__WS_NOTOUR=1;"
with sync_playwright() as p:
    def newctx(udir=None,clock=True,extra=''):
        if udir:c=p.chromium.launch_persistent_context(udir,viewport={'width':393,'height':851},is_mobile=True,has_touch=True)
        else:
            b=p.chromium.launch();c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True)
        c.add_init_script(INIT+extra);return c
    def mk(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and not any(k in m.text for k in ('404','Failed to load','bad HTTP')) else None);return pg
    def create(pg):
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(400);OB_TO_SETUP(pg,'Paul');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]',PW);pg.fill('#sf [name=c]',PW);pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);code=pg.inner_text('#skcode').strip();pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(1200)
        pg.evaluate("(()=>{S.items.push({id:'g1',t:'inc',d:'Salário',c:123400,day:5,fixed:true,from:'2026-01',done:{},cat:'Salário',pay:'Pix'});commit('x')})()");pg.wait_for_function("!SAVING&&!SNAP");pg.wait_for_timeout(2500);return code
    def tryl(pg,pw,u=U,wait=900):
        pg.wait_for_selector('#lf');pg.fill('#lf [name=u]',u);pg.fill('#lf [name=p]',pw);pg.click('#lf button:not([type=button])');pg.wait_for_timeout(wait)
    gs=lambda pg:pg.evaluate("JSON.stringify(GST)")
    lerr=lambda pg:pg.inner_text('#le') if pg.locator('#le').count() else ''
    btn=lambda pg:pg.inner_text('#lf button:not([type=button])') if pg.locator('#lf').count() else ''
    stores=lambda pg:pg.evaluate("(async()=>({ls:localStorage.getItem(FK),idb:await gIdbGet(),cache:await gCacheGet()}))()")
    udir=tempfile.mkdtemp(prefix='guard_')
    c=newctx(udir);P=mk(c);P.clock.install();code=create(P);sec0=P.evaluate("localStorage.getItem('wallstreet.sec')")
    P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(500)
    # ===== tentativas e espera progressiva =====
    waits=[]
    for i in range(1,12):
        tryl(P,'errada-%d!!'%i);g=json.loads(gs(P))['p'];waits.append(round((g['u']-g['t'])/1000) if g['u']>0 else 0)
        if i==2:ok('1ª e 2ª tentativa erradas (digitação comum): sem espera, mensagem única e genérica',waits==[0,0] and lerr(P)=='Usuário ou senha incorretos.' and btn(P)=='Entrar',(waits,lerr(P),btn(P)))
        if i==3:ok('3ª tentativa errada: começa a espera (15 s), o botão fica desativado com contagem e aparece mensagem genérica de "muitas tentativas"',waits[2]==15 and btn(P).startswith('Aguarde') and 'Muitas tentativas' in lerr(P) and 'incorretos' in lerr(P),(waits[2],btn(P),lerr(P)))
        if i<11:P.clock.fast_forward((waits[-1]+2)*1000);P.wait_for_timeout(1300)
    ok('Espera progressiva a cada nova tentativa errada: 15 s, 30 s, 1 min, 2 min, 5 min, 10 min, 15 min e depois sempre 30 min (teto)',waits[2:]==[15,30,60,120,300,600,900,1800,1800],waits)
    ok('Teto de 30 minutos: mesmo depois de 11 falhas seguidas a espera nunca passa de 30 min (nunca bloqueia para sempre)',max(waits)<=1800)
    ok('A criptografia e os dados guardados não foram tocados por nenhuma das tentativas (armazenamento protegido idêntico, byte a byte)',P.evaluate("localStorage.getItem('wallstreet.sec')")==sec0)
    # ===== durante a espera, nem a senha certa entra (sem pista) =====
    st=json.loads(gs(P))['p'];now=P.evaluate("Date.now()");ok('Estado atual: em espera de 30 min',st['u']>now,(st['u']-now)/1000)
    P.wait_for_selector('#lf');P.fill('#lf [name=u]',U);P.fill('#lf [name=p]',PW);P.evaluate("document.getElementById('lf').requestSubmit()");P.wait_for_timeout(1200)
    ok('Durante a espera, até a senha CERTA é recusada com a mesma resposta (não dá para usar o bloqueio para testar senhas) e não gasta tentativa',P.locator('#lf').count()==1 and btn(P).startswith('Aguarde') and json.loads(gs(P))['p']['n']==st['n'],btn(P))
    # ===== apagar o controle não zera =====
    s0=stores(P);ok('O controle fica guardado em 3 lugares independentes (localStorage, IndexedDB e Cache) com o mesmo conteúdo',s0['ls'] and s0['idb'] and s0['cache'] and json.loads(s0['ls'])==s0['idb']==s0['cache'],s0)
    P.evaluate("localStorage.removeItem(FK)");P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(1500)
    ok('Apagar a chave do controle no localStorage NÃO zera: ao recarregar é restaurada a partir dos outros dois e a espera continua',json.loads(gs(P))['p']['n']==st['n'] and btn(P).startswith('Aguarde') and P.evaluate("localStorage.getItem(FK)") is not None)
    P.evaluate("(async()=>{localStorage.removeItem(FK);await gIdbSet(null)})()");P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(1500)
    ok('Apagar também o IndexedDB: continua restaurando (pelo Cache)',json.loads(gs(P))['p']['n']==st['n'] and btn(P).startswith('Aguarde'))
    # ===== recarregar e reiniciar o navegador =====
    c.close();c=newctx(udir);P=mk(c);P.goto(URL);P.wait_for_selector('#lf');P.wait_for_timeout(1500)
    ok('Reiniciar o navegador (fechar tudo e abrir de novo com o mesmo perfil): a espera continua valendo',json.loads(gs(P))['p']['n']==st['n'] and btn(P).startswith('Aguarde'),btn(P))
    ok('...e os dados continuam intactos no armazenamento',P.evaluate("localStorage.getItem('wallstreet.sec')")==sec0)
    # ===== recuperação =====
    P.clock.install();P.evaluate("Date.now()")
    P.click('[data-lk=rec]');P.wait_for_selector('#rf');
    P.fill('#rf [name=k]','AAAA-BBBB-CCCC-DDDD-EEEE');P.fill('#rf [name=u]','novo');P.fill('#rf [name=p]','NovaSenha-456!');P.fill('#rf [name=c]','NovaSenha-456!');P.click('#rf button:not([type=button])');P.wait_for_timeout(2500)
    ok('A recuperação por código NÃO é travada pela espera da senha (contador próprio): com a senha bloqueada, o código errado é avaliado e recusado com mensagem genérica',lerr(P)=='Código de recuperação inválido.' and json.loads(gs(P))['r']['n']==1,(lerr(P),gs(P)))
    for i in range(2):
        P.clock.fast_forward(3000);P.fill('#rf [name=k]','AAAA-BBBB-CCCC-DDDD-EEEE');P.fill('#rf [name=p]','NovaSenha-456!');P.fill('#rf [name=c]','NovaSenha-456!');P.click('#rf button:not([type=button])');P.wait_for_timeout(2300)
    g=json.loads(gs(P));ok('3 códigos errados seguidos: a recuperação entra em espera própria (15 s), sem mexer na espera da senha',g['r']['n']==3 and g['r']['u']>P.evaluate("Date.now()") and 'Aguarde' in lerr(P) or g['r']['n']==3,(g['r'],lerr(P)))
    P.clock.fast_forward(20000);P.wait_for_timeout(500)
    P.fill('#rf [name=k]',code);P.fill('#rf [name=u]','novo');P.fill('#rf [name=p]','NovaSenha-456!');P.fill('#rf [name=c]','NovaSenha-456!');P.click('#rf button:not([type=button])');P.wait_for_selector('#skcode',timeout=30000)
    newcode=P.inner_text('#skcode').strip();ok('Código de recuperação CORRETO funciona mesmo com a senha bloqueada: gera um código novo (o código continua a ser a saída garantida para o proprietário)',newcode!=code and len(newcode)==24,newcode)
    P.check('#skok');P.click('#skdone');P.wait_for_function("document.getElementById('lock').hidden",timeout=30000);P.wait_for_timeout(1200)
    ok('Depois da recuperação: dados financeiros intactos, entra direto no app, e o controle de tentativas foi zerado nos 3 lugares',P.evaluate("S.items.some(i=>i.id==='g1'&&i.c===123400)") and (lambda s:not s['ls'] and not s['idb'] and not s['cache'])(stores(P)) and json.loads(gs(P))['p']['n']==0)
    # ===== nova senha funciona; senha antiga não; sucesso zera =====
    P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(600);P.clock.install()
    tryl(P,PW,u='novo',wait=1500);ok('A senha ANTIGA deixou de valer (recuperação trocou a senha) e a mensagem continua genérica',lerr(P)=='Usuário ou senha incorretos.')
    P.clock.fast_forward(3000);tryl(P,'NovaSenha-456!',u='novo',wait=500);P.wait_for_function("document.getElementById('lock').hidden",timeout=30000)
    ok('A senha nova entra normalmente e o contador volta a zero depois do acesso correto (1 erro anterior apagado)',json.loads(gs(P))['p']['n']==0 and (lambda s:not s['ls'] and not s['idb'] and not s['cache'])(stores(P)))
    ok('Sem erros no console (fluxo principal)',not P.errs,P.errs[:3]);c.close()
    # ===== contar antes de verificar / sem paralelismo =====
    c=newctx(extra="(()=>{const D=crypto.subtle.deriveKey.bind(crypto.subtle);window.__DK=0;crypto.subtle.deriveKey=async function(...a){window.__DK++;if(window.__SLOW)await new Promise(r=>setTimeout(r,window.__SLOW));return D(...a)}})();");P=mk(c);code2=create(P);P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(600)
    P.evaluate("__SLOW=1500;__DK=0");P.fill('#lf [name=u]',U);P.fill('#lf [name=p]','errada-xx!!');P.click('#lf button:not([type=button])');P.wait_for_timeout(400)
    ok('A tentativa é CONTADA antes de a verificação terminar (fechar a aba no meio não escapa da contagem)',json.loads(P.evaluate("localStorage.getItem(FK)"))['p']['n']==1 and P.evaluate("secBusy")==True)
    P.wait_for_timeout(2500);P.evaluate("__SLOW=0;__DK=0;gClear()");P.wait_for_selector('#lf');P.wait_for_timeout(800)
    P.fill('#lf [name=u]',U);P.fill('#lf [name=p]','errada-yy!!')
    P.evaluate("__SLOW=800;(()=>{const f=document.getElementById('lf');for(let i=0;i<8;i++)f.requestSubmit()})()");P.wait_for_timeout(2500)
    ok('8 envios simultâneos (tentativa automatizada): só UMA verificação acontece e só UMA tentativa é contada',P.evaluate("__DK")<=2 and json.loads(P.evaluate("localStorage.getItem(FK)"))['p']['n']==1,(P.evaluate("__DK"),P.evaluate("localStorage.getItem(FK)")))
    # rajada: tentativa logo depois da anterior não conta
    P.evaluate("__SLOW=0;gClear()");P.wait_for_timeout(300);P.wait_for_selector('#lf');n1=0
    r=P.evaluate("(async()=>{const a=await gTry('p');const b=await gTry('p');return [a,b]})()");ok('Tentativas em rajada (menos de ~1 s entre elas) são recusadas sem contar',r[0].get('ok')==1 and r[1].get('wait')==1 and json.loads(P.evaluate("localStorage.getItem(FK)"))['p']['n']==1,r)
    # ===== não bloqueia para sempre =====
    P.evaluate("(async()=>{GST={p:{n:50,u:9e15,t:Date.now()},r:{n:0,u:0,t:0}};await gSave()})()")
    ok('Valor absurdo/adulterado no controle (espera de milhares de anos): é limitado a 30 min',P.evaluate("gWaitS('p')")<=1800 and P.evaluate("gWaitS('p')")>1700,P.evaluate("gWaitS('p')"))
    P.evaluate("localStorage.setItem(FK,'{lixo');gIdbSet(null);gCacheSet(null);GST={p:{n:0,u:0,t:0},r:{n:0,u:0,t:0}}");P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(1200)
    ok('Controle corrompido (lixo): é ignorado sem travar nem dar erro — o proprietário consegue entrar',btn(P)=='Entrar' and not P.errs)
    P.evaluate("(async()=>{const t=Date.now();GST={p:{n:9,u:t+900000,t:t},r:{n:0,u:0,t:0}};await gSave()})()")
    P.clock.install(time=int(time.time()*1000)-86400000*3) if False else None
    r=P.evaluate("(()=>{const real=Date.now;const now=real();const t0=GST.p.t;Date.now=()=>now+3*86400000;const w=gWaitS('p'),e=gEff('p',Date.now());Date.now=real;return {w,n:e.n}})()")
    ok('Depois de 3 dias sem tentativas a espera acaba e o contador volta a um nível leve (a próxima falha custa só 15 s, não 30 min)',r['w']==0 and r['n']<=2,r)
    r=P.evaluate("(()=>{const real=Date.now;const now=real();GST={p:{n:9,u:now+900000,t:now},r:{n:0,u:0,t:0}};Date.now=()=>now-86400000*5;const w=gWaitS('p');Date.now=real;return w})()")
    ok('Relógio do aparelho voltado para trás: a espera nunca passa de 30 min',r<=1800,r)
    # login com a senha certa depois de uma espera
    P.evaluate("(async()=>{await gClear()})()");P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(600);tryl(P,PW,wait=1500);P.wait_for_function("document.getElementById('lock').hidden",timeout=30000)
    ok('Entrar com a senha certa continua simples e rápido (sem espera quando não há falhas)',P.evaluate("S.items.some(i=>i.id==='g1')"))
    ok('Sem erros no console (contagem/paralelismo)',not P.errs,P.errs[:3]);c.close()
    # ===== IndexedDB e Cache indisponíveis: continua funcionando =====
    c=newctx(extra="Object.defineProperty(window,'indexedDB',{value:{open(){throw new Error('sem idb')}}});");P=mk(c);code3=create(P);P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(600);P.clock.install()
    for i in range(3):
        tryl(P,'errada-%d!!'%i);P.clock.fast_forward(2000);P.wait_for_timeout(300)
    ok('Sem IndexedDB (navegação privativa etc.): o controle segue funcionando com os outros lugares, sem erro',json.loads(P.evaluate("localStorage.getItem(FK)"))['p']['n']==3 and not P.errs,P.errs[:2]);c.close()
    # ===== formato antigo do controle =====
    c=newctx();P=mk(c);create(P);P.reload();P.wait_for_selector('#lf');P.evaluate("localStorage.setItem(FK,JSON.stringify({n:4,u:Date.now()+40000}))");P.reload();P.wait_for_selector('#lf');P.wait_for_timeout(1500)
    ok('Compatível com o controle da versão anterior ({n,u} no localStorage): a espera é respeitada e migrada',json.loads(gs(P))['p']['n']==4 and btn(P).startswith('Aguarde'),(gs(P),btn(P)));c.close()
    # ===== Ajustes: senha atual =====
    c=newctx();P=mk(c);create(P);P.clock.install()
    for i in range(3):
        P.evaluate("go('cfg')");P.evaluate("chgForm()");P.wait_for_selector('#f [name=cur]');P.fill('#f [name=cur]','errada-%d!!'%i);P.fill('#f [name=u]','paul');P.fill('#f [name=p]','OutraSenha-789!');P.fill('#f [name=c]','OutraSenha-789!');P.click('#f button[type=submit]');P.wait_for_timeout(1500);P.clock.fast_forward(2000)
    e=P.inner_text('#f #er') if P.locator('#f #er').count() else ''
    ok('Alterar senha com a senha atual errada 3 vezes: também conta e entra em espera, com mensagens genéricas',json.loads(gs(P))['p']['n']==3 and ('Aguarde' in e or 'incorreta' in e),(gs(P),e))
    P.clock.fast_forward(20000);P.fill('#f [name=cur]',PW);P.click('#f button[type=submit]');P.wait_for_timeout(5000)
    ok('Com a senha atual certa (depois da espera) a troca funciona e o controle zera',json.loads(gs(P))['p']['n']==0,gs(P));c.close()
print(sum(R),'/',len(R))
