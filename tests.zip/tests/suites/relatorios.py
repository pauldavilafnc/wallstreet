import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re,os,datetime
pass
from playwright.sync_api import sync_playwright
from contrast import measure
URL=FILE_URL
DATA=open(FIX+'/dados_ficticios.js',encoding='utf-8').read()
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
TODAY=datetime.date(2026,11,15);CM='2026-11'
# ---------- "oráculo": recalcula tudo em Python, direto dos dados brutos, sem usar o código do app ----------
def dim(y,m):return (datetime.date(y+(m==12),m%12+1,1)-datetime.timedelta(days=1)).day
def shift(ym,k):y,m=map(int,ym.split('-'));t=y*12+m-1+k;return '%04d-%02d'%(t//12,t%12+1)
def rows(S,t,m):return [i for i in S['items'] if i['t']==t and ((i['fixed'] and m>=i['from']) or (not i['fixed'] and i.get('ym')==m))]
def duedate(i,m):y,mo=map(int,m.split('-'));return datetime.date(y,mo,min(i['day'],dim(y,mo)))
def stat(i,m):return 'ok' if (i.get('done') or {}).get(m) is not None else ('late' if duedate(i,m)<TODAY else 'pend')
def flows(S):
    f={}
    def g(k):return f.setdefault(k,{'inc':0,'exp':0,'dp':0,'bx':0})
    for i in S['items']:
        for k,c in (i.get('done') or {}).items():g(k)[i['t']]+=c
    for d in S['debts']:
        for p in d['pays']:g(p['d'][:7])['dp']+=p['c']
    for b in S['boxes']:
        for p in b['moves']:g(p['d'][:7])['bx']+=p['c']
    for k in S.get('cards',[]):
        for p in k.get('pays',[]):g(p['d'][:7])['exp']+=p['c']

    for q in S.get('parc',[]) or []:   # parcela paga sai do caixa (paidOn > vencimento > mês da parcela)
        if q.get('paid') and isinstance(q.get('c'),int) and q['c']>0:
            d=q.get('paidOn') or q.get('due') or ((q['ym']+'-01') if q.get('ym') else '')
            if len(d)>=7 and d[4]=='-':g(d[:7])['exp']+=q['c']
    return f
def net(x):return x['inc']-x['exp']-x['dp']-x['bx']
def flow(S,m):
    F=flows(S);f=F.get(m,{'inc':0,'exp':0,'dp':0,'bx':0});ini=(S.get('opening') or {}).get('c',0)+sum(net(v) for k,v in F.items() if k<m)
    return {**f,'res':net(f),'ini':ini,'fin':ini+net(f)}
def parts(k):
    out=[]
    for b in k['buys']:
        np_=b.get('np') or 1;base=b['c']//np_;rest=b['c']-base*np_;dt=b['dt'];ym0=dt[:7]
        inv=ym0 if int(dt[8:])<=min(k['cl'],dim(*map(int,ym0.split('-')))) else shift(ym0,1)
        for n in range(np_):out.append({'b':b,'n':n+1,'of':np_,'ym':shift(inv,n),'cm':shift(ym0,n),'c':base+(rest if n==0 else 0)})
    return out
def ccdue(k,ym):
    y=ym if k['dd']>k['cl'] else shift(ym,1);yy,mm=map(int,y.split('-'));return datetime.date(yy,mm,min(k['dd'],dim(yy,mm)))
def commit(S,m):
    z=lambda:{'tot':0,'paid':0,'pend':0,'late':0}
    ct,pt,cc=z(),z(),z()
    for i in rows(S,'exp',m):
        s=stat(i,m);ct['tot']+=i['c']
        if s=='ok':ct['paid']+=i['done'][m]
        elif s=='late':ct['late']+=i['c']
        else:ct['pend']+=i['c']
    for q in [q for q in S['parc'] if q['ym']==m]:
        pt['tot']+=q['c']
        if q.get('paid'):pt['paid']+=q['c']
        elif (datetime.date.fromisoformat(q['due']) if q.get('due') else None) and datetime.date.fromisoformat(q['due'])<TODAY or (not q.get('due') and q['ym']<CM):pt['late']+=q['c']
        else:pt['pend']+=q['c']
    for k in S.get('cards',[]):
        pp=parts(k);yms={p['ym'] for p in pp}|{p['ym'] for p in k.get('pays',[])}
        for ym in yms:
            dd=ccdue(k,ym)
            if dd.isoformat()[:7]!=m:continue
            t=sum(p['c'] for p in pp if p['ym']==ym);pd=min(sum(p['c'] for p in k.get('pays',[]) if p['ym']==ym),t);rest=t-pd
            if not t:continue
            cc['tot']+=t;cc['paid']+=pd
            if rest>0:
                if dd<TODAY:cc['late']+=rest
                else:cc['pend']+=rest
    R_=sum(i['c'] for i in rows(S,'inc',m));Cm=ct['tot']+pt['tot']+cc['tot']
    return {'R':R_,'ct':ct,'pt':pt,'cc':cc,'Cm':Cm,'paid':ct['paid']+pt['paid']+cc['paid'],'pend':ct['pend']+pt['pend']+cc['pend'],'late':ct['late']+pt['late']+cc['late'],'ratio':(Cm/R_ if R_>0 else 0)}
with sync_playwright() as p:
    b=p.chromium.launch()
    def page(w=393,h=851,th='light',data=DATA,init=''):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1;"+init);pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and not any(k in m.text for k in ('404','Failed to load')) else None)
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(700)
        pg.evaluate("S="+data+";S.pref.theme='%s';applyPref();save();go('rel')"%th);pg.wait_for_timeout(1200);return c,pg
    c,pg=page();S=json.loads(pg.evaluate("JSON.stringify(S)"))
    txt=lambda:pg.inner_text('#s-rel')
    # ===== precisão: JS x oráculo independente =====
    bad=[]
    for m in ['2026-08','2026-09','2026-10','2026-11','2026-12','2027-01']:
        f=pg.evaluate(f"relFlow('{m}')");o=flow(S,m)
        if any(f[k]!=o[k] for k in ('inc','exp','dp','bx','res','ini','fin')):bad.append(('flow',m,f,o))
        c_=pg.evaluate(f"relCommit('{m}')");oc=commit(S,m)
        for k in ('R','Cm','paid','pend','late'):
            if c_[k]!=oc[k]:bad.append(('commit',m,k,c_[k],oc[k]))
        for part in ('ct','pt','cc'):
            for k in ('tot','paid','pend','late'):
                if c_[part][k]!=oc[part][k]:bad.append(('commit',m,part,k,c_[part][k],oc[part][k]))
    ok('Precisão: resumo (recebido, pago, dívidas, guardado, saldo inicial/final) e compromissos (contas, parcelas, cartões: pago/pendente/vencido) de 6 meses batem com um recálculo independente em Python direto dos dados',not bad,bad[:2])
    fs=pg.evaluate("finSit().m");rc=pg.evaluate(f"relCommit('{CM}')")
    ok('Consistência com a Situação financeira (mês atual): renda prevista, total comprometido e percentual são IGUAIS',fs['R']==rc['R'] and fs['Cm']==rc['Cm'] and abs(fs['ratio']-rc['ratio'])<1e-9,(fs['Cm'],rc['Cm']))
    ok('...e as despesas pagas do mês também (contas + cartões por vencimento = Situação)',pg.evaluate("finSit().m.Epaid")==rc['ct']['paid']+rc['cc']['paid'])
    ok('Consistência com o saldo principal: o saldo final do mês atual é IGUAL a balance() (sem lançamentos de data futura)',pg.evaluate(f"relFlow('{CM}').fin")==pg.evaluate("balance()") and pg.evaluate(f"relFlow('{CM}').fin")==pg.evaluate("finSit().m.bal"),(pg.evaluate("balance()"),))
    ok('Saldo inicial de um mês = saldo final do mês anterior (encadeado, sem buracos)',all(pg.evaluate(f"relFlow('{shift(m,1)}').ini")==pg.evaluate(f"relFlow('{m}').fin") for m in ['2026-08','2026-09','2026-10','2026-11']))
    # ===== presença e conteúdo dos cartões =====
    heads=pg.evaluate("[...document.querySelectorAll('#s-rel h3')].map(h=>h.textContent)")
    ok('A tela traz os novos cartões (Resumo do mês, Indicadores, Comprometimento, Despesas por categoria, Despesas recorrentes, Evolução das dívidas, Comparação mensal) e MANTÉM os que já existiam',all(h in heads for h in ['Resumo do mês','Indicadores do mês','Comprometimento da renda','Despesas por categoria','Despesas recorrentes','Evolução das dívidas','Comparação mensal','Gastos por categoria','Receitas recebidas por mês','Despesas pagas por mês','Receitas × despesas','Evolução do saldo (acumulado)','Progresso das caixinhas','Quitação das dívidas (acumulado pago)']) and 'Minha situação financeira' in txt(),heads)
    f=flow(S,CM);cm=commit(S,CM)
    resumo=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Resumo do mês').innerText")
    brl=lambda c:('-' if c<0 else '')+'R$ '+('{:,.2f}'.format(abs(c)/100).replace(',','X').replace('.',',').replace('X','.'))
    ok('Resumo do mês mostra os valores certos: receitas, despesas, dívidas pagas, guardado, saldo inicial, resultado e saldo final',all(brl(v) in resumo for v in (f['inc'],f['exp'],f['dp'],f['bx'],f['ini'],f['res'],f['fin'])),resumo[:400])
    ok('O resumo informa quanto das despesas pagas do mês são parcelas pagas (agora elas descontam do saldo; sem inventar valor)','de parcelas pagas neste mês' in pg.evaluate("(()=>{rpm='2026-10';render();return document.getElementById('s-rel').innerText})()")); pg.evaluate("rpm='2026-11';render()")
    comp=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Comprometimento da renda').innerText")
    ok('Comprometimento da renda: contas, parcelas, faturas, total e percentual (78%) corretos; pago, a pagar e vencido fecham com o total',all(brl(v) in comp for v in (cm['ct']['tot'],cm['pt']['tot'],cm['cc']['tot'],cm['Cm'],cm['paid'],cm['pend'],cm['late'])) and '78%' in comp and cm['paid']+cm['pend']+cm['late']==cm['Cm'],comp[:300])
    ok('Dívidas pagas no mês aparecem à parte (não somadas ao comprometimento), sem contar duas vezes',brl(f['dp']) in comp and cm['Cm']==cm['ct']['tot']+cm['pt']['tot']+cm['cc']['tot'])
    # dívidas
    dv=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Evolução das dívidas').innerText")
    od=sum(d['o'] for d in S['debts']);pd=sum(sum(p['c'] for p in d['pays']) for d in S['debts'])
    ok('Evolução das dívidas: valor inicial, já pago, saldo restante e % quitado de cada dívida e do total batem com os dados',all(brl(v) in dv for v in (od,pd,od-pd,300000,200000,80000)) and '26%' in dv and 'Vencida' in dv and 'Em aberto' in dv and 'último em 05/10/2026' in dv,dv[:500])
    ser=pg.evaluate("(()=>{const ms=Array.from({length:12},(_,i)=>shift(rpm,i-11)),F=S.debts.flatMap(d=>d.pays),od=S.debts.reduce((a,d)=>a+d.o,0);return ms.map(m=>od-F.filter(p=>p.d.slice(0,7)<=m).reduce((a,p)=>a+p.c,0))})()")
    exp_ser=[od-sum(p['c'] for d in S['debts'] for p in d['pays'] if p['d'][:7]<=shift('2026-11',i-11)) for i in range(12)]
    ok('A série do saldo devedor (12 meses) = valor inicial − pagamentos até cada mês (confere com o oráculo)',ser==exp_ser,(ser[-4:],exp_ser[-4:]))
    # recorrentes
    rc_=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Despesas recorrentes').innerText")
    fx=[i for i in rows(S,'exp',CM) if i['fixed']];tot=sum(i['c'] for i in fx)+20000+50000*0+50000
    ok('Despesas recorrentes: contas fixas (com dia e situação), parcelamento em andamento ("parcela 2 de 3 · restam 1") e compra parcelada no cartão ("2 de 3"), com o total e o % da renda',all(i['d'] in rc_ for i in fx) and 'parcela 2 de 3' in rc_ and 'restam 1' in rc_ and '2 de 3 · Nubank' in rc_ and 'Mercado' not in rc_ and 'Total que se repete' in rc_ and '53%' in rc_,rc_[:500])
    ok('Só aparece o que de fato se repete (contas fixas): gastos variáveis (Mercado, Cinema) ficam de fora','Cinema' not in rc_ and 'Mercado' not in rc_)
    # categorias
    cs=pg.evaluate("catSpend(rpm)");tp=sum(v['paid'] for v in cs.values());cat=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Despesas por categoria').innerText")
    pcs=[int(x) for x in re.findall(r'· (\d+)%',cat)]
    ok('Despesas por categoria: total pago e participação (%) de cada categoria conferem com os dados; as porcentagens somam ~100% e a maior vem primeiro',brl(tp) in cat and 98<=sum(pcs)<=102 and pcs==sorted(pcs,reverse=True),(pcs,tp))
    # comparação
    cmpt=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Comparação mensal').innerText")
    fa,fb=flow(S,'2026-10'),flow(S,'2026-11')
    ok('Comparação mensal (padrão: mês anterior × atual): valores de cada mês e diferenças corretos, com % de variação e setas',all(brl(v) in cmpt for v in (fa['inc'],fb['inc'],fa['exp'],fb['exp'],fa['dp'],fb['dp'],fa['res'],fb['res'])) and all((('+' if fb[k]-fa[k]>0 else '')+str(round((fb[k]-fa[k])/abs(fa[k])*100))+'%') in cmpt for k in ('inc','exp','res') if fa[k] and fb[k]!=fa[k]) and 'igual' in cmpt,cmpt[:420])
    pg.select_option('#rcA','2026-09');pg.select_option('#rcB','2026-09');pg.wait_for_timeout(300);cmp2=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Comparação mensal').innerText")
    ok('Escolher outros meses atualiza a comparação na hora (mesmo mês nos dois lados = tudo "igual")',cmp2.count('igual')==5 and brl(flow(S,'2026-09')['inc']) in cmp2)
    # indicadores
    ind=pg.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Indicadores do mês').innerText")
    ok('Indicadores do mês destacam positivo, atenção e crítico com as regras da Situação: saldo positivo, comprometimento 78% = Atenção, vencidos = Crítico','Saldo no fim do mês' in ind and 'Positivo' in ind and 'Atenção' in ind and 'Crítico' in ind and '78%' in ind,ind)
    # navegação de mês
    pg.evaluate("rpm='2026-11';render()");pg.click('[data-act=rpp]');pg.wait_for_timeout(200);t1=txt();f10=flow(S,'2026-10')
    ok('Navegar para o mês anterior (‹) atualiza todos os cartões: resumo, indicadores, comprometimento, categorias, recorrentes e dívidas',t1.count('outubro de 2026')>=5 and brl(f10['inc']) in t1)
    pg.click('[data-act=rpn]');pg.click('[data-act=rpn]');pg.wait_for_timeout(200);t2=txt()
    ok('Mês futuro (dezembro): só aparece o que é previsto, sem inventar recebimentos ou pagamentos (recebido/pago = R$ 0,00)',t2.count('dezembro de 2026')>=5 and 'R$ 0,00' in t2 and brl(flow(S,'2026-12')['inc'])=='R$ 0,00',t2[:50])
    pg.evaluate("rpm='2025-01';render()");t3=txt();ok('Mês antigo sem dados: mensagens de "sem dados" em vez de números vazios e sem NaN/undefined',not re.search(r'NaN|undefined|Infinity',t3),re.findall(r'.{20}(?:NaN|undefined|Infinity).{10}',t3)[:2])
    pg.evaluate("rpm='2026-11';render()")
    ok('Nenhum "NaN", "undefined" ou "Infinity" em toda a tela de Relatórios (dados reais)',not re.search(r'NaN|undefined|Infinity|\[object',txt()),re.findall(r'.{20}(?:NaN|undefined|Infinity|\[object).{10}',txt())[:2])
    # somente leitura
    sn=pg.evaluate("JSON.stringify(S)");pg.evaluate("for(let i=0;i<6;i++){rpm=shift(rpm,-1);render()}rpm='2026-11';render()");ok('A tela só lê: navegar pelos meses não altera nenhum dado financeiro',pg.evaluate("JSON.stringify(S)")==sn)
    # esconder valores
    pg.evaluate("S.pref.hide=1;render()");NEWC=['Resumo do mês','Indicadores do mês','Comprometimento da renda','Despesas por categoria','Despesas recorrentes','Evolução das dívidas','Comparação mensal']
    th={h:pg.evaluate("(h)=>[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent===h).innerText",h) for h in NEWC}
    ok('Com os valores escondidos (olho), todos os 7 novos cartões mascaram os valores em R$ e continuam mostrando percentuais e situação',all(('•••••' in v) and not re.search(r'R\$ \d',v) for v in th.values()) and '78%' in th['Comprometimento da renda'] and 'Atenção' in th['Indicadores do mês'],[h for h,v in th.items() if re.search(r'R\$ \d',v)])
    pg.evaluate("S.pref.hide=0;render()")
    ok('Sem erros no console',not pg.errs,pg.errs[:3]);c.close()
    # ===== indicadores: cenários =====
    def scen(js):
        c2,p2=page(data=DATA);p2.evaluate(js+";save();go('rel')");p2.wait_for_timeout(500);t=p2.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Indicadores do mês').innerText");c2.close();return t
    base_ok="S.items.forEach(i=>{if(i.t==='exp'){i.c=Math.round(i.c/4);i.done=Object.assign({},i.done,{'2026-11':i.c})}});S.parc=[];S.cards=[];S.debts.forEach(d=>d.due='2027-12-01')"
    t=scen(base_ok);ok('Cenário saudável (compromissos ≤ 60% da renda, nada vencido): comprometimento Positivo e nenhum Crítico','Comprometimento da renda' in t and re.search(r'Comprometimento da renda\s*\d+%\s*Positivo',t) and 'Crítico' not in t,t)
    t=scen("S.items.forEach(i=>{if(i.t==='exp')i.c=i.c*2});S.parc=[];S.cards=[]");ok('Cenário crítico (compromissos > 100% da renda): comprometimento Crítico',re.search(r'Comprometimento da renda\s*\d+%\s*Crítico',t) is not None,t)
    t=scen("S.items.forEach(i=>{if(i.t==='exp'&&i.done)i.done={}});S.opening=null");ok('Despesas não pagas com vencimento passado: "Compromissos vencidos" = Crítico',re.search(r'Compromissos vencidos\s*R\$[^C]*Crítico',t) is not None,t)
    t=scen("S.opening={c:-500000,d:'2026-01-01'}");ok('Saldo negativo no fim do mês: indicador de saldo Crítico',re.search(r'Saldo no fim do mês\s*-R\$[^R]*Crítico',t) is not None,t)
    t=scen("S.limits={'Casa':1000}");ok('Limite de categoria estourado: "Limites por categoria" = Atenção','estourado' in t and re.search(r'estourado\w*\s*Atenção',t) is not None,t)
    # ===== conta nova / vazia =====
    c3,p3=page(data="seed()");t=p3.inner_text('#s-rel')
    ok('Conta nova (sem dados): todos os cartões mostram mensagem de "sem dados", sem NaN/undefined e sem erros',not re.search(r'NaN|undefined|Infinity',t) and not p3.errs and 'Cadastre receitas' in t,p3.errs[:2]);c3.close()
    # ===== muitas categorias =====
    cats="S.items=S.items.concat(["+",".join("{id:'k%d',t:'exp',d:'x%d',c:%d,day:3,fixed:false,ym:'2026-11',done:{'2026-11':%d},cat:'Cat%d',pay:'Pix'}"%(i,i,1000*(i+1),1000*(i+1),i) for i in range(8))+"])"
    c4,p4=page(data=DATA,init="");p4.evaluate(cats+";save();go('rel')");p4.wait_for_timeout(400);cat=p4.evaluate("[...document.querySelectorAll('#s-rel .card')].find(x=>x.querySelector('h3').textContent==='Despesas por categoria').innerText")
    ok('Mais de 5 categorias: mostra as 5 maiores e agrupa o resto em "Outras categorias" (soma conferida)','Outras categorias' in cat and cat.count('· ')>=6,cat[:200]);c4.close()
    # ===== dados antigos =====
    leg=open(FIX+'/legacy_seed.js',encoding='utf-8').read()
    c5,p5=page(data="(()=>{"+leg+";const o=legacySeed();o.flags={tour:1};delete o.cards;return migrate(o)})()");t=p5.inner_text('#s-rel')
    ok('Compatível com dados de versões anteriores (sem cartões, formato antigo): a tela abre completa, sem erros nem valores inválidos',not p5.errs and 'Resumo do mês' in t and not re.search(r'NaN|undefined|Infinity',t),p5.errs[:2]);c5.close()
    # ===== desempenho =====
    big="(()=>{const o="+DATA+";for(let i=0;i<1500;i++)o.items.push({id:'z'+i,t:i%5?'exp':'inc',d:'Item '+i,c:1000+i,day:1+i%28,fixed:i%3===0,from:'2026-01',ym:'2026-11',done:{'2026-11':1000+i},cat:'C'+i%12,pay:'Pix'});return o})()"
    c6,p6=page(data=big);ms=p6.evaluate("(()=>{const t=[];for(let i=0;i<5;i++){const a=performance.now();render();t.push(performance.now()-a)}return Math.max(...t)})()")
    ok('Desempenho: com 1.500 lançamentos a tela de Relatórios desenha em menos de 600 ms',ms<600,round(ms));c6.close()
    # ===== layout e contraste =====
    for (w,h) in ((320,568),(393,851),(851,393),(1280,800)):
        for th in ('light','dark'):
            c7,p7=page(w,h,th);g=p7.evaluate("(()=>{const cs=[...document.querySelectorAll('#s-rel .card')],m=document.getElementById('s-rel').getBoundingClientRect();return{ov:"+OVER+",inside:cs.every(c=>{const r=c.getBoundingClientRect();return r.left>=m.left-1&&r.right<=m.right+1}),cards:cs.length,btn:[...document.querySelectorAll('#s-rel [data-act=rpp],#s-rel [data-act=rpn]')].every(b=>{const r=b.getBoundingClientRect();return r.width>=40&&r.height>=40})}})()")
            ok(f'{w}x{h} [{th}]: sem rolagem lateral, todos os cartões dentro da coluna e botões ‹ › com alvo ≥ 40 px',g['ov'] and g['inside'] and g['btn'] and g['cards']>=14,g);c7.close()
    for th in ('light','dark'):
        c8,p8=page(393,851,th);bad=[];tot=0
        p8.set_viewport_size({'width':393,'height':9000});p8.wait_for_timeout(600)
        for x in measure(p8,'content'):
            tot+=1
            if x[0]<x[1]:bad.append(x)
        ok(f'[{th}] Contraste dos textos da tela de Relatórios com os novos cartões ({tot} medidos) — mínimo 4,5:1',not bad and tot>150,bad[:4]);c8.close()
print(sum(R),'/',len(R))
