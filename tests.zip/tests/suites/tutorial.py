import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re,os
pass
from playwright.sync_api import sync_playwright
from contrast import measure
URL=os.environ.get('WS_URL',HTTP_URL)
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:230] if d else ''))
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
TITLES=['Seu painel','Lançamentos rápidos','Receitas','Despesas','Dívidas e Caixinhas','Relatórios','Ajustes','Pronto!']
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,reduce=False):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=w<600,timezone_id='America/Sao_Paulo',reduced_motion='reduce' if reduce else 'no-preference');c.add_init_script("window.__WS_NOCSP=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None);return c,pg
    def create(pg,pw=True,theme=None):
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(400)
        if theme:pg.evaluate(f"S.pref.theme='{theme}';applyPref()")
        if pw:
            OB_TO_SETUP(pg,'Paul');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000)
        else:
            OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000)
    info=lambda pg:pg.evaluate("""(()=>{const t=document.getElementById('tour');if(!t)return null;const sp=t.querySelector('.tspot').getBoundingClientRect(),cd=t.querySelector('.tcard').getBoundingClientRect();return{title:t.querySelector('.tt').textContent,n:t.querySelector('.tn').textContent,spot:[sp.left,sp.top,sp.right,sp.bottom],card:[cd.left,cd.top,cd.right,cd.bottom],nospot:t.classList.contains('nospot'),skip:(()=>{const r=t.querySelector('.tskip').getBoundingClientRect();return r.width>=44&&r.height>=44&&r.right<=innerWidth&&r.top>=0})(),vw:innerWidth,vh:innerHeight,next:t.querySelector('[data-tr=next]').textContent,prevVis:getComputedStyle(t.querySelector('[data-tr=prev]')).visibility}})()""")
    # ===== conta nova com senha =====
    c,pg=ctx();create(pg);pg.wait_for_selector('#tour',timeout=8000);pg.wait_for_timeout(900);i=info(pg)
    ok('Logo depois de criar a conta, o tutorial aparece sozinho, na Home, com o primeiro passo',i and i['title']=='Seu painel' and i['n']=='1 de 8' and pg.evaluate("view")=='home',i and i['title'])
    ok('Pequenas indicações visuais na própria tela: o destaque (anel) fica exatamente sobre o saldo (card principal) e o resto da tela escurece',pg.evaluate("(()=>{const h=document.querySelector('#s-home .hero').getBoundingClientRect(),s=document.querySelector('#tour .tspot').getBoundingClientRect();return Math.abs(s.left-(h.left-6))<3&&Math.abs(s.top-(h.top-6))<3&&Math.abs(s.width-(h.width+12))<3&&getComputedStyle(document.querySelector('#tour .tspot')).boxShadow.includes('rgba(7, 14, 35')})()"))
    ok('"Pular" está visível e é fácil de tocar (≥ 44 px) já no primeiro passo; o botão Voltar não aparece no primeiro passo',i['skip'] and i['prevVis']=='hidden' and i['next']=='Próximo')
    seq=[i['title']];sel={'Receitas':'rec','Despesas':'des','Relatórios':'rel','Ajustes':'cfg'};okp=[];okskip=[i['skip']]
    for k in range(7):
        pg.click('#tour [data-tr=next]');pg.wait_for_timeout(450);j=info(pg);seq.append(j['title']);okskip.append(j['skip'])
        card,spot=j['card'],j['spot']
        inside=card[0]>=0 and card[2]<=j['vw'] and card[1]>=0 and card[3]<=j['vh']
        sep=j['nospot'] or card[3]<=spot[1]+1 or card[1]>=spot[3]-1
        tgt=True
        if j['title'] in sel:
            r=pg.evaluate(f"(()=>{{const b=document.querySelector('#nav button[data-id={sel[j['title']]}]').getBoundingClientRect();return[b.left,b.top,b.right,b.bottom]}})()");tgt=abs(spot[0]-(r[0]-6))<3 and abs(spot[3]-(r[3]+6))<3
        if j['title']=='Dívidas e Caixinhas':
            r=pg.evaluate("(()=>{const a=document.querySelector('#nav button[data-id=div]').getBoundingClientRect(),b=document.querySelector('#nav button[data-id=cx]').getBoundingClientRect();return[a.left,b.right]})()");tgt=abs(spot[0]-(r[0]-6))<3 and abs(spot[2]-(r[1]+6))<3
        if j['title']=='Lançamentos rápidos':
            tgt=pg.evaluate("(()=>{const q=document.querySelector('#s-home .qa').getBoundingClientRect(),s=document.querySelector('#tour .tspot').getBoundingClientRect();return Math.abs(s.left-(q.left-6))<3&&Math.abs(s.top-(q.top-6))<3})()")
        okp.append((j['title'],inside,sep,tgt))
    ok('Os 8 passos, em ordem: Seu painel, Lançamentos rápidos, Receitas, Despesas, Dívidas e Caixinhas, Relatórios, Ajustes e Pronto!',seq==TITLES,seq)
    ok('Em cada passo o balão cabe na tela, não cobre o item destacado e o destaque está sobre o item certo (aba, par de abas ou atalhos)',all(x[1] and x[2] and x[3] for x in okp),[x for x in okp if not(x[1] and x[2] and x[3])])
    ok('"Pular" fica visível e tocável durante TODO o tutorial (nos 8 passos)',all(okskip),okskip)
    ok('No último passo o botão vira "Concluir" e o texto fala de calculadora, sino, Anotações e de rever o tutorial em Ajustes',info(pg)['next']=='Concluir' and all(w in pg.inner_text('#tour .tx') for w in ('calculadora','sino','Anotações','Ajustes')))
    pg.click('#tour [data-tr=prev]');pg.wait_for_timeout(350);ok('Voltar retorna ao passo anterior (Ajustes)',info(pg)['title']=='Ajustes' and info(pg)['next']=='Próximo')
    pg.click('#tour [data-tr=next]');pg.wait_for_timeout(350);pg.click('#tour [data-tr=next]');pg.wait_for_timeout(300)
    ok('Concluir fecha o tutorial e grava na conta que ele já foi visto',pg.locator('#tour').count()==0 and pg.evaluate("S.flags.tour")==1)
    pg.wait_for_timeout(1500);pg.reload();pg.wait_for_selector('#lf',timeout=20000);pg.fill('#lf [name=u]','paul');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(2500)
    ok('Nos próximos acessos (fechar, abrir e entrar com a senha) o tutorial NÃO volta',pg.locator('#tour').count()==0 and pg.evaluate("S.flags.tour")==1)
    ok('Sem erros no console (tutorial completo)',not pg.errs,pg.errs)
    # contas existentes não são afetadas: mesma conta, sem o registro de "visto" (como uma conta antiga), reabrindo e entrando
    pg.evaluate("delete S.flags.tour;save()");pg.wait_for_timeout(1500);pg.reload();pg.wait_for_selector('#lf',timeout=20000);pg.fill('#lf [name=u]','paul');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(3000)
    ok('Conta já existente (sem o registro de tutorial) NÃO é afetada: ao entrar, nada de tutorial',pg.locator('#tour').count()==0 and pg.evaluate("!(S.flags&&S.flags.tour)"));c.close()
    # app com dados já existentes abrindo normalmente
    c,pg=ctx();pg.add_init_script("localStorage.setItem('wallstreet.welcomed','1');localStorage.setItem('wallstreet.secskip','1');localStorage.setItem('wallstreet.v1',JSON.stringify({v:2,owner:'Antigo',opening:{c:10000,d:'2026-01-01'},limits:{},ntf:{read:{}},pref:{theme:'light',pal:'blue',av:{v:2,m:2,an:1,set:1}},items:[{id:'i1',t:'inc',d:'Salário',c:300000,day:5,fixed:true,from:'2026-01',done:{},cat:'Salário',pay:'Pix'}],inst:[],parc:[],debts:[],boxes:[]}))")
    pg.goto(URL);pg.wait_for_selector('#s-home .mqc');pg.wait_for_timeout(3500)
    ok('Usuário que já usa o app (dados existentes, sem passar pelo cadastro): abre direto na Home, sem tutorial',pg.locator('#tour').count()==0 and pg.evaluate("S.owner")=='Antigo' and pg.evaluate("!(S.flags&&S.flags.tour)") and pg.evaluate("document.getElementById('lock').hidden"));c.close()
    # sem senha + pular
    c,pg=ctx();create(pg,pw=False);pg.wait_for_selector('#tour',timeout=8000);pg.wait_for_timeout(500);pg.click('#tour [data-tr=next]');pg.wait_for_timeout(300);pg.click('#tour [data-tr=next]');pg.wait_for_timeout(300);pg.click('#tour [data-tr=skip]');pg.wait_for_timeout(250)
    ok('"Usar sem senha": o tutorial também aparece; "Pular" no meio fecha na hora e grava como visto',pg.locator('#tour').count()==0 and pg.evaluate("S.flags.tour")==1)
    pg.wait_for_timeout(1200);ok('Depois de pular, não volta (nem ao recarregar os dados já salvos)',pg.evaluate("(()=>{const o=migrate(JSON.parse(localStorage.getItem('wallstreet.v1')));return o.flags&&o.flags.tour===1})()") and pg.locator('#tour').count()==0)
    ok('Dados do usuário não são tocados pelo tutorial: só o registro de "visto" é gravado',pg.evaluate("S.items.length===0&&S.debts.length===0&&S.boxes.length===0&&S.owner==='Paul'"));c.close()
    # esc, bloqueio do fundo e manual
    c,pg=ctx();create(pg,pw=False);pg.wait_for_selector('#tour',timeout=8000);pg.wait_for_timeout(600)
    pg.mouse.click(200,420);pg.wait_for_timeout(200);ok('Enquanto o tutorial está aberto, tocar no fundo não abre nada por trás (nenhum formulário)',pg.evaluate("document.getElementById('ov').hidden")==True and pg.locator('#tour').count()==1)
    pg.keyboard.press('Escape');pg.wait_for_timeout(200);ok('A tecla Esc também pula o tutorial',pg.locator('#tour').count()==0 and pg.evaluate("S.flags.tour")==1)
    pg.evaluate("go('cfg')");pg.wait_for_timeout(300);pg.click('[data-act=tourgo]');pg.wait_for_selector('#tour');pg.wait_for_timeout(500);ok('Em Ajustes há "Ver o tutorial" para rever quando quiser (volta para a Home e começa do primeiro passo)',info(pg)['title']=='Seu painel' and pg.evaluate("view")=='home')
    pg.click('#tour [data-tr=skip]');pg.wait_for_timeout(200);ok('Rever e pular de novo funciona normalmente',pg.locator('#tour').count()==0);c.close()
    # movimento reduzido
    c,pg=ctx(reduce=True);create(pg,pw=False);pg.wait_for_selector('#tour',timeout=8000);pg.wait_for_timeout(500)
    ok('"Reduzir movimento": o destaque não anima nem pulsa',pg.evaluate("getComputedStyle(document.querySelector('#tour .tspot'),'::after').animationName")=='none' and pg.evaluate("getComputedStyle(document.querySelector('#tour .tcard')).animationName")=='none' and pg.evaluate("getComputedStyle(document.querySelector('#tour .tspot')).transitionDuration")in('0s',''));c.close()
    # leveza
    c,pg=ctx();create(pg,pw=False);pg.wait_for_selector('#tour',timeout=8000);pg.wait_for_timeout(500)
    ok('Leve: o tutorial usa poucos elementos (< 30), a pulsação termina sozinha (3 repetições) e o app continua sem setInterval',pg.evaluate("document.querySelectorAll('#tour *').length")<30 and 'setInterval(' not in open(ROOT+'/index.html',encoding='utf-8').read() and 'animation:tpulse 1.4s ease-out 3' in open(ROOT+'/index.html',encoding='utf-8').read());c.close()
    # layout e contraste
    for (w,h) in ((320,568),(393,851),(851,393),(1280,800)):
        for th in ('light','dark'):
            c,pg=ctx(w,h);create(pg,pw=False,theme=th);pg.wait_for_selector('#tour',timeout=8000);res=[];pg.wait_for_timeout(500)
            for k in range(8):
                j=info(pg);card,spot=j['card'],j['spot'];res.append(card[0]>=0 and card[2]<=j['vw'] and card[1]>=0 and card[3]<=j['vh'] and j['skip'] and pg.evaluate(OVER) and (w>=851 or j['nospot'] or card[3]<=spot[1]+1 or card[1]>=spot[3]-1))
                if k<7:pg.click('#tour [data-tr=next]');pg.wait_for_timeout(420)
            ok(f'{w}x{h} [{th}]: nos 8 passos o balão cabe na tela, "Pular" alcançável e sem rolagem lateral{" (e sem cobrir o item destacado)" if w<851 else ""}',all(res),res);c.close()
    for th in ('light','dark'):
        c,pg=ctx();create(pg,pw=False,theme=th);pg.wait_for_selector('#tour',timeout=8000);pg.wait_for_timeout(900);bad=[x for x in measure(pg,'tour') if x[0]<x[1]];tot=len(measure(pg,'tour'))
        ok(f'[{th}] Contraste dos textos do balão ({tot} medidos) — mínimo 4,5:1',not bad and tot>=4,bad[:3]);c.close()
print(sum(R),'/',len(R))
