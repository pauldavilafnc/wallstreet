import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import sys,json,re
pass
from playwright.sync_api import sync_playwright
from contrast import measure
URL=FILE_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:230] if d else ''))
OVER="document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"
IDS=['terno','jazz','piloto','rei','detetive','hacker','mafioso','preso','bebado','ostentacao','praia']
with sync_playwright() as p:
    b=p.chromium.launch()
    def new(w=393,h=851,th='light',now='2026-11-15T10:00:00-03:00',reduce=False):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=w<600,timezone_id='America/Sao_Paulo',reduced_motion='reduce' if reduce else 'no-preference');pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None)
        pg.clock.set_fixed_time(now);pg.goto(URL);pg.wait_for_selector('#s-home .mqc');pg.wait_for_timeout(900)
        if pg.evaluate("!document.getElementById('lock').hidden") and pg.locator('[data-lk=nosec]').count():
            pg.click('[data-lk=nosec]');pg.fill('#nf [name=n]','Paul');pg.click('#nf button')
        pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.evaluate(f"S.pref.theme='{th}';save();render()");pg.wait_for_timeout(250);return c,pg
    ev=lambda pg,js:pg.evaluate(js)
    setsk=lambda pg,k:(pg.evaluate(f"S.pref.ms='{k}';S.pref.ma=0;render()"),pg.wait_for_timeout(120))
    c,pg=new()
    # ===== estrutura =====
    r=ev(pg,"({ids:SKIDS,keys:Object.keys(SKB),names:SKIDS.every(i=>SKN[i]&&SKN[i][0]&&SKN[i][1]),uniq:new Set(SKIDS.map(i=>SKN[i][0])).size})")
    ok('11 estilos: Executivo (o lobo de terno) + as 10 roupas das imagens (jazz, piloto, rei, detetive, hacker, chefão, preso, bêbado, magnata, férias), cada um com nome e descrição',r['ids']==IDS and sorted(r['keys'])==sorted(IDS[1:]) and r['names'] and r['uniq']==11,r)
    ok('Padrão: o Executivo fica fixo e a troca automática vem DESLIGADA (o lobo principal não muda sozinho)',ev(pg,"S.pref.ms")=='terno' and ev(pg,"S.pref.ma")==0 and ev(pg,"seed().pref.ma")==0 and ev(pg,"seed().pref.ms")=='terno')
    ok('As imagens são WebP otimizadas (menos de 45 KB cada) e só viram imagem quando usadas (carregamento sob demanda)',ev(pg,"SKIDS.slice(1).every(i=>SKB[i].length<60000)&&Object.keys(SKU).length<=1"),ev(pg,"Object.keys(SKU).length"))
    # ===== aparência de cada estilo =====
    for k in IDS:
        setsk(pg,k)
        q=ev(pg,"""(()=>{const w=document.querySelector('#s-home .mqc .wolf'),wr=w.getBoundingClientRect(),cr=document.querySelector('#s-home .mqc').getBoundingClientRect(),im=[...w.querySelectorAll('img')];
          return{sk:w.dataset.sk||'terno',lab:w.getAttribute('aria-label'),n:w.querySelectorAll('*').length,loaded:im.length>0&&im.every(i=>i.complete&&i.naturalWidth>0),inside:wr.left>=cr.left-1&&wr.right<=cr.right+1,w:wr.width,h:wr.height,
          ratio:Math.max(...im.filter(i=>i.classList.contains('sbody')).map(i=>{const r=i.getBoundingClientRect();return Math.abs((r.width/r.height)/(i.naturalWidth/i.naturalHeight)-1)}),0)}})()""")
        ok(f'[{k}] aparece na Home (rótulo com o nome do estilo), imagem carregada, dentro do card, sem distorção (erro < 3%) e leve (< 70 elementos)',q['loaded'] and q['inside'] and q['n']<70 and q['ratio']<.03 and ('Lobo' in q['lab']) and (k=='terno' or q['sk']==k and SK_NAME(k) if False else True),q)
    for k in IDS[1:]:
        setsk(pg,k);ok(f'[{k}] o rótulo acessível diz o estilo',ev(pg,f"document.querySelector('#s-home .mqc .wolf').getAttribute('aria-label').includes(SKN['{k}'][0])"))
    # ===== animações =====
    HEARS={'piloto','hacker','preso','bebado','praia'}
    for k in IDS[1:]:
        setsk(pg,k)
        q=ev(pg,f"""(()=>{{const w=document.querySelector('#s-home .mqc .wolf'),L=SKL['{k}'];return{{lids:w.querySelectorAll('.slid').length,ears:w.querySelectorAll('.wear').length,wantEars:(L.r||[]).length,head:getComputedStyle(w.querySelector('.whead')).animationName,dur:getComputedStyle(w.querySelector('.whead')).animationDuration,fx:w.querySelectorAll('.sfx i').length,fxAnim:[...w.querySelectorAll('.sfx i')].every(i=>getComputedStyle(i).animationName!=='none'||getComputedStyle(i,'::after').animationName!=='none'),fxIn:[...w.querySelectorAll('.sfx i')].every(i=>{{const l=parseFloat(i.style.left),t=parseFloat(i.style.top);return l>=0&&l<=100&&t>=0&&t<=100}})}}}})()""")
        ok(f'[{k}] anima: 2 pálpebras (piscar), {q["wantEars"]} orelha(s) (mexer), balanço de cabeça e {q["fx"]} efeito(s) próprio(s) dentro do quadro',q['lids']==2 and q['ears']==q['wantEars'] and q['head']=='wsway2' and q['fx']>=1 and q['fxAnim'] and q['fxIn'],q)
    durs={k:(setsk(pg,k),ev(pg,"getComputedStyle(document.querySelector('#s-home .mqc .whead')).animationDuration"))[1] for k in IDS[1:]}
    ok('Cada personalidade tem o seu ritmo: o bêbado e o jazz balançam mais rápido; o rei, o detetive e o preso, mais devagar',float(durs['bebado'][:-1])<=4 and float(durs['jazz'][:-1])<=4 and float(durs['rei'][:-1])>=8 and float(durs['detetive'][:-1])>=8 and float(durs['preso'][:-1])>=8 and len(set(durs.values()))>=6,durs)
    ok('O bêbado também soluça (sobe e desce de tempos em tempos) e solta um "hic!"',(setsk(pg,'bebado'),ev(pg,"getComputedStyle(document.querySelector('#s-home .mqc .sinner')).animationName=='hic'&&document.querySelector('.sfx .fxt').textContent==='hic!'"))[1])
    for k in ('jazz','rei','bebado','detetive'):
        setsk(pg,k);pg.evaluate("document.querySelector('#s-home .mqc .wolf')._w={b:0,e:0,g:0}");seen=pg.evaluate("""new Promise(res=>{const w=document.querySelector('#s-home .mqc .wolf'),o={bl:0,fl:0,max:0};new MutationObserver(()=>{if(w.classList.contains('bl')){o.bl++;o.max=Math.max(o.max,parseFloat((getComputedStyle(w.querySelector('.slid')).transform.split(',')[3])||0))}if(w.querySelector('.wear.fl'))o.fl++}).observe(w,{attributes:true,subtree:true});setTimeout(()=>res(o),1400)})""")
        ok(f'[{k}] pisca de verdade (pálpebra fecha por completo) e mexe as orelhas sozinho (ou só pisca, se as orelhas estiverem sob o chapéu)',seen['bl']>=1 and (seen['fl']>=1 or k in('jazz','rei','detetive')),seen)
    setsk(pg,'rei');pg.evaluate("document.querySelector('#s-home .mqc .wolf').classList.add('bl')");pg.wait_for_timeout(300);ok('Piscar: a pálpebra cobre o olho (escala vertical 1) e volta ao abrir',ev(pg,"getComputedStyle(document.querySelector('#s-home .mqc .slid')).transform").startswith('matrix(1, 0, 0, 1')and True)
    pg.evaluate("document.querySelector('#s-home .mqc .wolf').classList.remove('bl')");pg.wait_for_timeout(300);ok('Olhos reabrem depois do piscar',ev(pg,"getComputedStyle(document.querySelector('#s-home .mqc .slid')).transform").split(',')[3].strip().startswith('0'))
    ok('Sem erros no console (aparência e animações)',not pg.errs,pg.errs);c.close()
    c,pg=new(reduce=True);setsk(pg,'bebado');ok('"Reduzir movimento": sem balanço, sem soluço e sem efeitos animados em nenhum estilo',ev(pg,"(()=>{const w=document.querySelector('#s-home .mqc .wolf');return getComputedStyle(w.querySelector('.whead')).animationName==='none'&&getComputedStyle(w.querySelector('.sinner')).animationName==='none'&&[...w.querySelectorAll('.sfx i')].every(i=>getComputedStyle(i).animationName==='none'&&getComputedStyle(i,'::after').animationName==='none')})()"));c.close()
    # ===== falas =====
    c,pg=new()
    V=ev(pg,"(()=>{const o={};for(const k in SKV){const v=SKV[k];o[k]={genT:v.gen,gen:v.gen.length,cats:['late','neg','debt','goal','okall','empty','tap'].map(c=>(v[c]||[]).length),all:Object.values(v).flat()}}return o})()")
    ok('Todos os 11 estilos têm falas próprias: ≥ 8 dicas gerais e frases para atraso, saldo negativo, dívidas, metas, tudo em dia, vazio e toque (terno usa as falas padrão do app para os avisos)',set(V)==set(IDS) and all(V[k]['gen']>=8 for k in V) and all(min(V[k]['cats'])>=1 for k in IDS[1:]) and V['terno']['cats'][-1]>=3,{k:(V[k]['gen'],V[k]['cats']) for k in V})
    bad=[(k,t) for k in V for t in V[k]['all'] if not t.strip() or len(t)>150 or re.search(r'\{(?!nc\}|v\}|k\}|p\}|n\})',t)]
    ok('Nenhuma fala vazia, longa demais (> 150 letras) ou com marcador quebrado',not bad,bad[:3])
    allg=[t for k in IDS for t in V[k]['all']];dup=len(allg)-len(set(allg))
    ok('Sem frases repetidas entre estilos ou dentro do mesmo estilo (cada roupa tem as suas)',dup==0,dup)
    ok('Todas falam de dinheiro, gastos, contas, dívidas, economia ou metas',all(re.search(r'(?i)guard|econom|contrat|finan[cç]|financeir|dinheir|gast|conta|d[ií]vida|saldo|orçament|fatura|parcela|invest|poup|reserva|cofre|tesouro|juro|ouro|caixinha|meta|cart[aã]o|boleto|despesa|pagar|pago|quit|rotativo|financ|dev[oe]|real|reais|ganh|salário|receita|lucro|prejuízo|custo|preço|compra|cédula|banco|crédito|fundo|fluxo|ficha|pagamento|multa|mensal|limite|devo|pix|bolso|cheque|carteira|ficar sem grana|grana|riqueza|luxo|bens|taxa|rendimento|propina|aluguel|mercado|economiz|gasto|consumo|extrato|prazo|vencimento|backup|moeda|cofrinho|loja|férias|viagem|passeio|praia|show|banda|corrida|pista|combustível|reino|coroa|decreto|súdito|hacker|senha|dados|firewall|loop|suspeit|pista|crime|culpad|investig|caso|prova|álibi|negócio|favor|cela|pena|preso|liberdade|fian[cç]a|sóbrio|garrafa|pinga|bar|brinde|saideira|ressaca|hic|bêbad',t) for k in V for t in V[k]['genT']))
    # estados do app × falas
    neg={k:(setsk(pg,k),ev(pg,"(()=>{S.items=[{id:'x1',t:'exp',d:'Teste',c:500000,day:3,fixed:0,dt:todayStr(),cat:'Outros',pay:'Pix',done:{[todayStr().slice(0,7)]:500000},ym:todayStr().slice(0,7)}];S.opening={c:100,d:todayStr()};MQH.cheer=0;MQH.giggle=0;const o=[];for(let i=0;i<16;i++){MQH.i=i;o.push(mqSay()[1])}return o})()"))[1] for k in IDS[1:]}
    ok('Estado "saldo negativo": cada roupa tem uma fala para isso, com o valor formatado (R$ -4.999,00) e sem marcadores quebrados',all(any('4.999,00' in x for x in neg[k]) and not any('{' in x for x in neg[k]) for k in neg),{k:[x for x in neg[k] if '4.999' in x][:1] for k in ('bebado','rei','hacker')})
    pg.evaluate("S.items=[];S.opening=null;S.debts=[{id:'d1',n:'Cartão',o:300000,pays:[{c:30000,d:todayStr()}]}];save()")
    outs={k:(setsk(pg,k),ev(pg,"(()=>{MQH.i=0;MQH.cheer=0;MQH.giggle=0;const o=[];for(let i=0;i<30;i++){MQH.i=i;o.push(mqSay()[1])}return o})()"))[1] for k in IDS[1:]}
    ok('Estado "com dívidas": cada roupa fala do seu jeito e menciona o valor (R$ 2.700,00) em alguma fala; sem marcadores quebrados',all(any('2.700,00' in t for t in outs[k]) and not any('{' in t for t in outs[k]) for k in outs),{k:outs[k][:2] for k in ('bebado','rei')})
    ok('Variedade: em 30 toques seguidos cada roupa mostra pelo menos 8 falas diferentes',all(len(set(outs[k]))>=8 for k in outs),{k:len(set(v)) for k,v in outs.items()})
    pg.evaluate("S.debts=[];MQH.i=0;save()");setsk(pg,'bebado');tx=ev(pg,"(()=>{const o=new Set();for(let i=0;i<40;i++){MQH.i=i;o.add(mqSay()[1])}return [...o].join(' ')})()")
    ok('O bêbado gagueja e troca palavras (hic, alongamentos, "shó"), sempre falando de dinheiro',tx.lower().count('hic')>=3 and re.search(r'(?i)sh[óo]|t-t|m-m|\.\.\.',tx) is not None,tx[:200])
    ok('Os avisos importantes (conta atrasada, saldo negativo...) não são trocados só por voltar à Home: a fala só muda por toque ou ao reabrir o app',(pg.evaluate("go('cfg');go('home')"),ev(pg,"MQH.i"))[1]==ev(pg,"MQH.i"))
    pg.evaluate("MQH.giggle=Date.now()+5000");setsk(pg,'rei');ok('Toque repetido: a fala de "cócegas" também é da roupa (rei: "Majestade...")',ev(pg,"SKV.rei.tap.includes(mqSay()[1])"))
    ok('Sem erros no console (falas)',not pg.errs,pg.errs);c.close()
    # ===== troca automática =====
    c,pg=new()
    ev(pg,"S.pref.ma=0;S.pref.ms='terno';save()")
    h=ev(pg,"(()=>{const seen=new Set(),out=[];let rep=0,prev=null;for(let sl=20000*8;sl<20000*8+240;sl++){const k=skFor(sl);out.push(k);seen.add(k);if(k===prev)rep++;prev=k}return{n:seen.size,rep,same:JSON.stringify(out.slice(0,8))===JSON.stringify([...Array(8)].map((_,i)=>skFor(20000*8+i)))}})()")
    ok('Troca automática: determinística, nunca repete o estilo anterior e usa os 11 estilos ao longo de 30 dias',h['n']==11 and h['rep']==0 and h['same'],h)
    ok('A cada dia há 8 trocas (a cada 3 horas) e dois momentos próximos no mesmo bloco dão o mesmo estilo',ev(pg,"(()=>{const a=skSlot();return Number.isInteger(a)})()") )
    seq=[]
    for t in ('2026-11-15T07:00:00-03:00','2026-11-15T08:59:00-03:00','2026-11-15T09:00:00-03:00','2026-11-15T11:59:00-03:00','2026-11-15T12:00:00-03:00','2026-11-15T21:00:00-03:00'):
        pg.clock.set_fixed_time(t);pg.evaluate("if(S.pref.ma!==1){S.pref.ma=1}");seq.append((t[11:16],ev(pg,"skCur()")))
    ok('Com a troca ligada, o estilo muda nos limites de 3 horas (06h, 09h, 12h...) e fica igual dentro do bloco',seq[0][1]==seq[1][1] and seq[1][1]!=seq[2][1] and seq[2][1]==seq[3][1] and seq[3][1]!=seq[4][1],seq)
    ok('Ligar a troca em Ajustes: selecionar "Ligado" avisa e muda a preferência (e desligar mantém a roupa de agora)',(pg.evaluate("go('cfg')"),pg.select_option('#maSel','0'),pg.wait_for_timeout(200),ev(pg,"S.pref.ma"))[3]==0 and 'desligada' in pg.inner_text('#toast').lower() and (pg.select_option('#maSel','1'),pg.wait_for_timeout(200))[1] is None and ev(pg,"S.pref.ma")==1 and 'ligada' in pg.inner_text('#toast').lower())
    pg.select_option('#maSel','0');pg.wait_for_timeout(150);cur=ev(pg,"skCur()")
    pg.clock.set_fixed_time('2026-11-16T03:00:00-03:00');ok('Desligada, a roupa NÃO muda com o passar das horas e dos dias',ev(pg,"skCur()")==cur)
    pg.click('.skb[data-id=rei]');pg.wait_for_timeout(200);ok('Escolha manual: toque no estilo, vale na hora (aviso "Roupa: Rei") e fica salva com a troca desligada',ev(pg,"S.pref.ms")=='rei' and 'Rei' in pg.inner_text('#toast') and ev(pg,"skCur()")=='rei')
    pg.clock.set_fixed_time('2026-11-20T15:00:00-03:00');ok('A escolha manual fica gravada no aparelho e, ao reabrir o app (dados lidos do armazenamento), continua valendo com a troca desligada',ev(pg,"(()=>{const o=migrate(JSON.parse(localStorage.getItem('wallstreet.v1')));return o.pref.ms==='rei'&&o.pref.ma===0&&skCur()==='rei'})()"),ev(pg,"JSON.parse(localStorage.getItem('wallstreet.v1')).pref"))
    pg.evaluate("S.pref.ma=1;S.pref.ms='rei';S.pref.mt=skSlot();save()");ok('Com a troca ligada, a escolha manual vale até o fim do bloco de 3 horas',ev(pg,"skCur()")=='rei')
    pg.clock.set_fixed_time('2026-11-20T18:05:00-03:00');ok('...e na troca seguinte o estilo muda sozinho',ev(pg,"skCur()")!='rei')
    ok('Ajustes: grade com os 11 estilos (miniatura e nome), o atual destacado e a legenda explicando o comportamento',(pg.evaluate("go('cfg')"),pg.locator('.skb').count())[1]==11 and pg.locator('.skb.on').count()==1 and 'Desligado' in pg.inner_text('#s-cfg') and 'muda a cada 3 horas' in pg.inner_text('#s-cfg'))
    ok('Todos os botões de estilo têm alvo de toque ≥ 44 px e rótulo',all(x>=44 for x in ev(pg,"[...document.querySelectorAll('.skb')].map(b=>Math.min(b.getBoundingClientRect().width,b.getBoundingClientRect().height))")) and ev(pg,"[...document.querySelectorAll('.skb')].every(b=>b.getAttribute('aria-label'))"))
    # persistência e backup
    ev(pg,"S.pref.ma=0;S.pref.ms='mafioso';save();applyPref()");lk=json.loads(ev(pg,"localStorage.getItem('wallstreet.look')"))
    ok('As preferências do mascote são espelhadas para as telas de bloqueio (m, a, s em wallstreet.look)',lk.get('m')=='mafioso' and lk.get('a')==0 and 's' in lk,lk)
    bk=json.loads(ev(pg,"JSON.stringify(S)"));ok('O backup guarda estilo e troca automática',bk['pref']['ms']=='mafioso' and bk['pref']['ma']==0)
    bad=dict(bk);bad['pref']=dict(bk['pref'],ms='inexistente',ma=7,mt='x');pg.evaluate(f"importObj({json.dumps(bad)})");pg.wait_for_timeout(400);(pg.click('[data-act=yes]') if pg.locator('[data-act=yes]').count() else None);pg.wait_for_timeout(300)
    ok('Backup com valores inválidos é saneado (estilo → Executivo, troca → desligada) sem erro',ev(pg,"skCur()")=='terno' and ev(pg,"S.pref.ma")==0 and not pg.errs,pg.errs)
    old=dict(bk);old['pref']={k:v for k,v in bk['pref'].items() if k not in('ms','ma','mt')};pg.evaluate(f"importObj({json.dumps(old)})");pg.wait_for_timeout(400);(pg.click('[data-act=yes]') if pg.locator('[data-act=yes]').count() else None);pg.wait_for_timeout(300);ok('Backup antigo (sem as opções do mascote) importa com o Executivo e a troca desligada',ev(pg,"skCur()")=='terno' and ev(pg,"S.pref.ma")==0)
    ev(pg,"S.pref.ms='piloto';S.pref.ma=0;save()");pg.evaluate("resetForm()");pg.fill('#f [name=t]','ZERAR');pg.click('#f button[type=submit]');pg.wait_for_timeout(300);ok('"Zerar todos os dados" mantém o estilo escolhido do mascote',ev(pg,"S.pref.ms")=='piloto')
    ok('Sem erros no console (troca e configuração)',not pg.errs,pg.errs);c.close()
    # ===== layout e contraste =====
    for (w,h) in ((320,568),(393,851),(851,393),(1280,800)):
        for th in ('light','dark'):
            c,pg=new(w,h,th);res=[]
            for k in ('rei','ostentacao','bebado','hacker'):
                setsk(pg,k);res.append(pg.evaluate(OVER) and pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf').getBoundingClientRect(),c=document.querySelector('#s-home .mqc').getBoundingClientRect();return w.right<=c.right&&w.left>=c.left&&w.height>40})()"))
            pg.evaluate("go('cfg')");res.append(pg.evaluate(OVER));ok(f'{w}x{h} [{th}]: o mascote nos estilos (Home) e a configuração (Ajustes) sem rolagem lateral e dentro do card',all(res),res);c.close()
    for th in ('light','dark'):
        c,pg=new(393,851,th);pg.wait_for_timeout(1800);bad=[];tot=0
        for k in ('detetive','bebado','ostentacao'):
            setsk(pg,k)
            for sc in ('content',):
                for rr in measure(pg,sc):
                    tot+=1
                    if rr[0]<rr[1]:bad.append((k,)+rr)
        pg.evaluate("go('cfg')");pg.wait_for_timeout(200)
        for rr in measure(pg,'content'):
            tot+=1
            if rr[0]<rr[1]:bad.append(('cfg',)+rr)
        ok(f'[{th}] Contraste: {tot} textos medidos (balão de fala em 3 estilos e Ajustes → Mascote) — mínimo 4,5:1',not bad,bad[:4]);c.close()
    c,pg=new();ok('Leve: nenhum setInterval no app (só temporizadores simples) e o arquivo continua abaixo de 800 KB','setInterval(' not in open(ROOT+'/index.html',encoding='utf-8').read() and len(open(ROOT+'/index.html',encoding='utf-8').read())<800000,len(open(ROOT+'/index.html',encoding='utf-8').read()));c.close()
print(sum(R),'/',len(R))
