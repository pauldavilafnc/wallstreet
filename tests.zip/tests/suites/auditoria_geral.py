import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json, os, shutil, sys, re, time
from playwright.sync_api import sync_playwright
URL=FILE_URL
PROF=TMP+'/profile'; shutil.rmtree(PROF,ignore_errors=True)
UA='Mozilla/5.0 (Linux; Android 13; 23021RAAEG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'
R=[]; 
def ok(n,c,d=''): R.append((n,bool(c),d)); print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d) if d else ''))
VIEWS=['home','rec','des','div','cx','rel','cfg','ntf','news']
OVER="""()=>{const w=document.documentElement.clientWidth,bad=[];document.querySelectorAll('body *').forEach(e=>{if(e.closest('svg')&&e.tagName!=='svg'&&e.tagName!=='SVG')return;const cs=getComputedStyle(e);if(cs.display==='none'||cs.position==='fixed'&&e.id==='toast')return;const r=e.getBoundingClientRect();if(r.width&&(r.right>w+.5||r.left<-.5))bad.push(e.tagName+'.'+e.className+' '+Math.round(r.left)+'→'+Math.round(r.right))});return{sw:document.documentElement.scrollWidth,cw:w,bad:bad.slice(0,6)}}"""
SMALL="""()=>{const o=[];document.querySelectorAll('button').forEach(b=>{const r=b.getBoundingClientRect();if(r.width&&(r.height<40||r.width<40))o.push((b.innerText||b.ariaLabel||'?').slice(0,14)+' '+Math.round(r.width)+'x'+Math.round(r.height))});return o}"""
CLIP="""()=>{const o=[];document.querySelectorAll('.v,.big,.a,b,.lbl,.tag,.pill,h2,h3,button').forEach(e=>{if(e.scrollWidth>e.clientWidth+1&&getComputedStyle(e).display!=='inline'&&e.clientWidth)o.push(e.tagName+'.'+e.className+':'+(e.innerText||'').slice(0,25))});return o}"""
NAVCOVER="""()=>{window.scrollTo(0,1e7);const s=[...document.querySelectorAll('main section')].find(x=>!x.hidden),l=s.lastElementChild,n=document.getElementById('nav').getBoundingClientRect(),r=l.getBoundingClientRect();return{gap:Math.round(n.top-r.bottom),navTop:Math.round(n.top)}}"""
with sync_playwright() as p:
    def launch(w=393,h=851,mobile=True,scale=2.75):
        c_=p.chromium.launch_persistent_context(PROF,viewport={'width':w,'height':h},device_scale_factor=scale,is_mobile=mobile,has_touch=mobile,user_agent=UA,accept_downloads=True,locale='pt-BR');c_.add_init_script('window.__WS_NOTOUR=1');return c_   # a intro tem suíte própria (intro_wolfin); aqui ela só atrasaria os cliques
    ctx=launch(); page=ctx.new_page()
    errs=[];reqs=[]
    page.on('console',lambda m: errs.append(m.type+': '+m.text) if m.type in('error','warning') else None)
    page.on('pageerror',lambda e: errs.append('PAGEERROR '+str(e)))
    page.on('request',lambda r: reqs.append(r.url))
    page.goto(URL); page.wait_for_timeout(300)
    ok('Viewport CSS 393x851 @2.75 (=1080x2400 físicos)',page.evaluate('[innerWidth,innerHeight,devicePixelRatio]')==[393,851,2.75],page.evaluate('[innerWidth,innerHeight,devicePixelRatio]'))
    nav=lambda v: page.evaluate(f"go('{v}')") if v in('ntf','news') else page.click(f'#nav button[data-id={v}]')
    st=lambda: page.evaluate('JSON.parse(JSON.stringify(S))')
    bal=lambda: page.evaluate('balance()')
    def fill(vals,submit=True):
        for k,v in vals.items():
            el=page.locator(f'#f [name={k}]')
            if el.evaluate('e=>e.tagName')=='SELECT': el.select_option(str(v))
            else: el.fill(str(v))
        if submit: page.click('#f button[type=submit]')
    # ---- 1/2 visual por seção e altura
    for h in (851,760,640):
        page.set_viewport_size({'width':393,'height':h})
        for v in VIEWS:
            nav(v); page.wait_for_timeout(50)
            o=page.evaluate(OVER); 
            ok(f'Sem rolagem horizontal/fora da tela · {v} · h{h}',o['sw']<=o['cw'] and not o['bad'],o)
            c=page.evaluate(NAVCOVER)
            ok(f'Barra inferior não cobre conteúdo · {v} · h{h}',c['gap']>=0,c)
            if h==851: page.evaluate('scrollTo(0,0)'); page.screenshot(path=f'{TMP}/shots/{v}.png')
    page.set_viewport_size({'width':393,'height':851})
    sm=set();cl=set()
    for v in VIEWS:
        nav(v); sm.update(page.evaluate(SMALL)); cl.update(page.evaluate(CLIP))
    ok('Botões ≥40px de toque',not sm,sorted(sm)[:8]); ok('Textos/valores não cortados',not cl,sorted(cl)[:8])
    # landscape
    page.set_viewport_size({'width':851,'height':393})
    for v in VIEWS:
        nav(v); o=page.evaluate(OVER); c=page.evaluate(NAVCOVER)
        ok(f'Paisagem 851x393 · {v}',o['sw']<=o['cw'] and not o['bad'] and c['gap']>=0,{**o,**c})
    page.set_viewport_size({'width':393,'height':851})
    # ---- 3 navegação repetida
    n0=None
    for i in range(6):
        for v in VIEWS: nav(v)
    nav('home'); n_home=page.evaluate('[...document.querySelectorAll("body *")].filter(e=>!e.closest(".rpl")).length')
    for i in range(20):
        for v in VIEWS: nav(v)
    nav('home'); n_home2=page.evaluate('[...document.querySelectorAll("body *")].filter(e=>!e.closest(".rpl")).length')
    ok('Navegação 140x: DOM estável (sem duplicar elementos)',n_home==n_home2,(n_home,n_home2))
    vis=[]
    for v in VIEWS:
        nav(v); vis.append((page.evaluate('[...document.querySelectorAll("main section")].filter(s=>!s.hidden).length'),len(page.inner_text('main').strip())>40,page.evaluate('scrollY')))
    ok('Uma seção visível por vez, nenhuma em branco, rolagem no topo',all(a==1 and b and c==0 for a,b,c in vis),vis)
    ok('Navegação sem recarregar a página',page.evaluate('performance.getEntriesByType("navigation").length')==1 and page.url==URL,page.url)
    c1=(nav('rel'),page.evaluate('document.querySelectorAll("#s-rel svg").length'))[1];e1=page.evaluate('document.querySelectorAll("#s-rel .empty").length')
    for _ in range(10): nav('home'); nav('rel')
    ok('Gráficos/avisos de Relatórios não duplicam após 10 visitas',page.evaluate('document.querySelectorAll("#s-rel svg").length')==c1 and page.evaluate('document.querySelectorAll("#s-rel .empty").length')==e1 and e1>=5,(c1,e1))
    ok('Input de arquivo oculto não aparece na tela',page.evaluate('getComputedStyle(document.getElementById("file")).display')=='none')
    ok('Meses não ficam com "De" maiúsculo',all(' De ' not in page.inner_text('#s-rec') for _ in [0]) or False)
    # ---- 6 precisão: parseMoney/brl
    cases={'29,90':2990,'72,98':7298,'597,88':59788,'1.922,00':192200,'1922':192200,'0,1':10,'R$ 10,00':1000,'1.234,5':123450,'10.5':1050,'':None}
    bad=[(k,page.evaluate(f'parseMoney({json.dumps(k)})'),v) for k,v in cases.items() if page.evaluate(f'parseMoney({json.dumps(k)})')!=v]
    ok('parseMoney: centavos corretos',not bad,bad)
    inv=[(k,page.evaluate(f'parseMoney({json.dumps(k)})')) for k in ['-5','abc','1,2,3']]
    ok('parseMoney: inválidos/negativos rejeitados',all(v is None or v!=v for _,v in inv) or inv,inv)
    ok('brl formata padrão brasileiro',page.evaluate('[brl(192200),brl(2990),brl(-59788),brl(7)]')==['R$ 1.922,00','R$ 29,90','-R$ 597,88','R$ 0,07'],page.evaluate('[brl(192200),brl(2990),brl(-59788),brl(7)]'))
    s=st()
    ok('Dados iniciais: receitas 1.922,00 / despesas 278,30',sum(i['c'] for i in s['items'] if i['t']=='inc')==192200 and sum(i['c'] for i in s['items'] if i['t']=='exp')==27830)
    ok('Dívidas iniciais somam 1.268,73',sum(d['o'] for d in s['debts'])==59788+4900+3785+7280+7298+43822==126873,sum(d['o'] for d in s['debts']))
    ok('Saldo inicial R$ 0,00 (nada previsto vira saldo)',bal()==0)
    # ---- 4 funcional: receitas
    nav('rec'); page.click('[data-act=addi][data-id=inc]')
    fill({'d':'','c':'10','day':'5'}); ok('Validação: descrição vazia bloqueia',page.inner_text('#er')!='' and page.evaluate('!document.getElementById("ov").hidden'),page.inner_text('#er'))
    fill({'d':'Teste Freela','c':'-5','day':'5'}); ok('Validação: valor negativo bloqueia',page.inner_text('#er')!='')
    fill({'d':'Teste Freela','c':'abc','day':'5'}); ok('Validação: valor texto bloqueia',page.inner_text('#er')!='')
    fill({'d':'Teste Freela','c':'29,90','day':'32'}); ok('Validação: dia 32 bloqueia',page.inner_text('#er')!='')
    fill({'d':'Teste Freela','c':'29,90','day':'12','cat':'Freelancer','pay':'Pix','fx':'0'})
    s=st(); it=[i for i in s['items'] if i['d']=='Teste Freela']
    ok('Adicionar receita (1 só registro, centavos, categoria, pagamento)',len(it)==1 and it[0]['c']==2990 and it[0]['cat']=='Freelancer' and it[0]['pay']=='Pix' and it[0]['fixed']==False,it)
    iid=it[0]['id']
    page.click(f'[data-act=tog][data-id="{iid}"]'); ok('Marcar recebida: saldo +29,90',bal()==2990,bal())
    page.click(f'[data-act=edi][data-id="{iid}"]'); fill({'c':'72,98'})
    ok('Editar receita não altera outros registros',[i['c'] for i in st()['items'] if i['d']!='Teste Freela']==[i['c'] for i in s['items'] if i['d']!='Teste Freela'] and [i['c'] for i in st()['items'] if i['d']=='Teste Freela']==[7298])
    page.click(f'[data-act=tog][data-id="{iid}"]'); page.click(f'[data-act=tog][data-id="{iid}"]'); ok('Desmarcar/remarcar usa novo valor 72,98',bal()==7298,bal())
    # rolagem preservada ao marcar
    nav('rec'); 
    page.click(f'[data-act=deli][data-id="{iid}"]'); page.click('[data-act=yes]'); ok('Excluir receita: some e saldo volta a 0',bal()==0 and not [i for i in st()['items'] if i['d']=='Teste Freela'])
    # despesas
    nav('des'); page.click('[data-act=addi][data-id=exp][data-f="0"]'); page.click('#ov .cd[data-d$="-03"]'); fill({'d':'Teste Mercado','c':'597,88','cat':'Alimentação','pay':'Cartão de débito','fx':'0'})
    d=[i for i in st()['items'] if i['d']=='Teste Mercado'][0]; ok('Despesa variável criada',d['fixed']==False and d['c']==59788 and d['cat']=='Alimentação')
    page.click(f'[data-act=tog][data-id="{d["id"]}"]'); ok('Marcar despesa paga: saldo -597,88',bal()==-59788,bal())
    html=page.inner_text('#s-des'); ok('Aba Despesas organizada: Fixas / Parceladas / Variáveis',all(x.lower() in html.lower() for x in ['Fixas','Parceladas','Variáveis']))
    # parcelada com linha do tempo
    page.click('[data-act=addinst]'); fill({'n':'Teste Geladeira','day':'10','pay':'Cartão de crédito','np':'3','pc':'33,33','fm':'2026-12'})
    inst=[x for x in st()['inst'] if x['n']=='Teste Geladeira'][0]; ps=[q for q in st()['parc'] if q['iid']==inst['id']]
    ok('Parcelada gera 3 parcelas de 33,33 em meses consecutivos',[q['ym'] for q in ps]==['2026-12','2027-01','2027-02'] and all(q['c']==3333 for q in ps),[q['ym'] for q in ps])
    ok('Linha do tempo individual visível e só da parcelada',page.locator('#s-des .tl').count()==1,page.locator('#s-des .tl').count())
    page.click(f'[data-act=hist][data-id="{inst["id"]}"]'); ok('Botão "Linha do tempo" alterna',page.locator('#s-des .tl').count()==0)
    page.click(f'[data-act=delinst][data-id="{inst["id"]}"]'); page.click('[data-act=yes]'); ok('Excluir parcelada remove suas parcelas',not [q for q in st()['parc'] if q['iid']==inst['id']])
    # dívidas
    nav('div'); sdb=st(); nxt=[x for x in sdb['debts'] if x['n']=='NEXT'][0]; viva=[x for x in sdb['debts'] if x['n']=='Vivo'][0]
    page.click(f'[data-act=pay][data-id="{nxt["id"]}"]'); fill({'c':'100,10'})
    n2=[x for x in st()['debts'] if x['n']=='NEXT'][0]; ok('Pagamento parcial NEXT: saldo 597,88-100,10=497,78',n2['o']-sum(p['c'] for p in n2['pays'])==49778)
    ok('Saldo disponível desconta pagamento (-597,88-100,10)',bal()==-59788-10010,bal())
    page.click(f'[data-act=pay][data-id="{nxt["id"]}"]'); fill({'c':'9999,00'}); ok('Pagar mais que o saldo é bloqueado',page.inner_text('#er')!=''); page.click('[data-act=close]')
    page.click(f'[data-act=pay][data-id="{viva["id"]}"]'); fill({'c':'37,85'}); ok('Quitar Vivo → QUITADA',('QUITADA' in page.inner_text('#s-div')) and [x for x in st()['debts'] if x['n']=='Vivo'][0]['pays'][0]['c']==3785)
    ok('Pagamento removido recalcula saldo',(page.click(f'[data-act=hist][data-id="{nxt["id"]}"]'),page.click('[data-act=delpay]'),page.click('[data-act=yes]'),sum(p['c'] for p in [x for x in st()['debts'] if x['n']=='NEXT'][0]['pays']))[3]==0)
    # caixinhas
    nav('cx'); em=[b for b in st()['boxes'] if b['n']=='Emergência'][0]
    page.click(f'[data-act=dep][data-id="{em["id"]}"]'); fill({'c':'100,10'})
    page.click(f'[data-act=wd][data-id="{em["id"]}"]'); fill({'c':'50,05'}); em=[b for b in st()['boxes'] if b['n']=='Emergência'][0]
    ok('Caixinha: guardar 100,10 − retirar 50,05 = 50,05',sum(m['c'] for m in em['moves'])==5005)
    page.click(f'[data-act=wd][data-id="{em["id"]}"]'); fill({'c':'60,00'}); ok('Retirar mais que guardado bloqueado',page.inner_text('#er')!=''); page.click('[data-act=close]')
    hb=[b for b in st()['boxes'] if b['n']=='Habilitação'][0]
    page.click(f'[data-act=dep][data-id="{hb["id"]}"]'); fill({'c':'500,00'}); ok('Percentual Habilitação 500/2000 = 25%','25%' in page.inner_text('#s-cx'))
    page.click(f'[data-act=edb][data-id="{hb["id"]}"]'); fill({'g':'1.000,00','m':'250,00','dl':'2027-05'}); ok('Alterar meta: 50% e falta R$ 500,00','50%' in page.inner_text('#s-cx'))
    page.click('[data-act=addb]'); fill({'n':'Teste Viagem','g':'','m':'','dl':''}); ok('Nova caixinha criada',any(b['n']=='Teste Viagem' for b in st()['boxes']))
    nb=[b for b in st()['boxes'] if b['n']=='Teste Viagem'][0]; page.click(f'[data-act=delb][data-id="{nb["id"]}"]'); page.click('[data-act=yes]'); ok('Excluir caixinha',not any(b['n']=='Teste Viagem' for b in st()['boxes']))
    expect=-59788-10010+0-3785-(10010-10010)  # NEXT pay removido
    expect=-59788-3785-(10010 and 0)  # após remoção do pagamento NEXT
    expect=-59788-3785-5005-50000
    ok('Saldo final coerente (despesa, dívida, caixinhas líquidas)',bal()==expect,(bal(),expect))
    # Home reflete
    nav('home'); h=page.inner_text('#s-home'); ok('Home exibe saldo atualizado',page.evaluate('brl(balance())') in h,page.evaluate('brl(balance())'))
    # ---- relatórios / config
    nav('rel'); ok('Relatórios renderizam com dados',page.locator('#s-rel svg').count()>=3)
    # tema/paleta
    nav('cfg'); page.click('[data-act=theme][data-id=dark]'); page.click('[data-act=pal][data-id=violet]')
    ok('Tema escuro + paleta violeta aplicados',page.evaluate('[document.documentElement.dataset.theme,document.documentElement.dataset.pal]')==['dark','violet'])
    for v in VIEWS:
        nav(v); o=page.evaluate(OVER); assert o['sw']<=o['cw'],(v,o)
    nav('cfg'); page.screenshot(path=TMP+'/shots/dark_cfg.png'); page.click('[data-act=theme][data-id=light]'); page.click('[data-act=pal][data-id=blue]')
    # export/import
    nav('cfg')
    with page.expect_download() as dl: page.click('[data-act=exp]')
    path=TMP+'/backup.json'; dl.value.save_as(path); bk=json.load(open(path)); before=st()
    bks=json.loads(json.dumps(before));bks['flags'].pop('bkp',None);bks['flags'].pop('bkpAt',None);bks['ach'].pop('bkp',None)  # a marca "Prevenido" é gravada DEPOIS do arquivo gerado
    bkc={k:v for k,v in bk.items() if k!='__backup'}  # o selo de integridade é do arquivo, não dos dados
    ok('Exportar backup gera JSON completo',bkc==bks and ('__backup' in bk) and dl.value.suggested_filename.startswith('wolfin-backup-'),dl.value.suggested_filename)
    before=bks
    # muda estado, importa de volta
    page.evaluate('S.owner="ALTERADO";save()')
    page.set_input_files('#file',path); page.click('[data-act=yes]'); imp=st();imc=json.loads(json.dumps(imp));imc['flags'].pop('imp',None);ex=json.loads(json.dumps(before));ex['flags']['bkpAt']=imp['flags'].get('bkpAt');ok('Importar backup válido restaura dados (e marca backup de hoje; registra a importação)',imc==ex and bool(imp['flags'].get('bkpAt')) and len(imp['flags'].get('imp',[]))==1);before=imp
    bad1=TMP+'/bad1.json'; open(bad1,'w').write('isto nao e json'); bad2=TMP+'/bad2.json'; json.dump({'owner':'x','items':'nao','debts':[]},open(bad2,'w'))
    bad3=TMP+'/bad3.json'; b3=json.loads(json.dumps(bk)); b3['debts'][0]['o']=1.5; json.dump(b3,open(bad3,'w'))
    for b,nm in ((bad1,'texto'),(bad2,'esquema errado'),(bad3,'centavos fracionados')):
        page.set_input_files('#file',b); page.wait_for_timeout(150)
        ok(f'Importar inválido ({nm}) rejeitado sem alterar dados',st()==before and page.evaluate('document.getElementById("ov").hidden') and ('inválido' in page.inner_text('#toast').lower() or 'corrompido' in page.inner_text('#toast').lower()),page.inner_text('#toast'))
    # ---- 5 persistência
    page.reload(); page.wait_for_timeout(200); ok('Persiste após atualizar a página',st()==before)
    nav('div'); nav('cx'); ok('Persiste ao trocar de seção',st()==before)
    p2=ctx.new_page(); p2.goto(URL); ok('Persiste em nova aba',p2.evaluate('JSON.parse(JSON.stringify(S))')==before); p2.close()
    ctx.close(); ctx=launch(); page=ctx.new_page(); page.goto(URL); ok('Persiste após fechar e reabrir o navegador',page.evaluate('JSON.parse(JSON.stringify(S))')==before)
    raw=page.evaluate('localStorage.getItem("wallstreet.v1")'); ok('localStorage tem a chave e é JSON válido',bool(raw) and json.loads(raw)==before)
    # ---- teclado virtual (emulado por redução da altura) e formulários
    page.on('pageerror',lambda e: errs.append('PAGEERROR '+str(e)))
    nav('rec'); page.click('[data-act=addi][data-id=inc]')
    for hh in (851,520,440):
        page.set_viewport_size({'width':393,'height':hh}); page.locator('#f [name=day]').focus(); page.wait_for_timeout(450)
        r=page.evaluate('(()=>{const f=document.querySelector("#f [name=day]").getBoundingClientRect(),s=document.querySelector(".sheet").getBoundingClientRect(),b=document.querySelector("#f button[type=submit]");b.scrollIntoView();const br=b.getBoundingClientRect();return{inputTop:Math.round(f.top),inputBottom:Math.round(f.bottom),sheetTop:Math.round(s.top),sheetBottom:Math.round(s.bottom),vh:innerHeight,btnInView:br.top>=0&&br.bottom<=innerHeight}})()')
        ok(f'Formulário utilizável com teclado simulado (viewport {hh}px)',r['sheetTop']>=0 and r['sheetBottom']<=r['vh']+1 and r['btnInView'],r)
    page.set_viewport_size({'width':851,'height':320}); r=page.evaluate('(()=>{const b=document.querySelector("#f button[type=submit]");b.scrollIntoView();const x=b.getBoundingClientRect();return x.top>=0&&x.bottom<=innerHeight})()'); ok('Formulário em paisagem + teclado (851x320): botão Salvar alcançável',r)
    page.screenshot(path=TMP+'/shots/form_land.png'); page.set_viewport_size({'width':393,'height':851}); page.click('[data-act=close]')
    meta=page.evaluate('document.querySelector("meta[name=viewport]").content'); ok('meta viewport inclui interactive-widget=resizes-content (teclado não cobre formulário)','interactive-widget' in meta,meta)
    # ---- desempenho
    t=page.evaluate('(()=>{const t=performance.now();for(let i=0;i<300;i++){view=VIEWS_ORDER[i%7];render()}return(performance.now()-t)/300})()'.replace('VIEWS_ORDER','["home","rec","des","div","cx","rel","cfg"]'))
    ok('Troca/renderização de seção rápida (<30 ms média)',t<30,f'{t:.1f} ms')
    h0=page.evaluate('performance.memory.usedJSHeapSize'); page.evaluate('for(let i=0;i<2000;i++){view=["home","rec","des","div","cx","rel","cfg"][i%7];render()}'); h1=page.evaluate('performance.memory.usedJSHeapSize')
    ok('Sem vazamento evidente de memória (2000 renders)',(h1-h0)<15e6,f'{(h1-h0)/1e6:.1f} MB')
    ext=[u for u in reqs if not u.startswith(('file://','blob:','data:'))]; ok('Sem recursos externos/bibliotecas (funciona offline)',not ext,ext)
    ok('Console sem erros/avisos/exceções',not errs,errs[:5])
    ctx.close()
    ctx=launch(); page=ctx.new_page(); page.goto(URL)
    # restaurar dados iniciais (em perfil temporário)
    nav('cfg'); page.click('[data-act=reset]'); page.fill('#f [name=t]','talvez'); page.click('#f button[type=submit]'); e1=page.inner_text('#er'); page.fill('#f [name=t]','zerar'); page.click('#f button[type=submit]'); page.wait_for_timeout(300); s=st(); ok('Zerar todos os dados: exige digitar ZERAR e deixa o app em branco',e1=='Digite ZERAR para confirmar.' and bal()==0 and s['items']==[] and s['debts']==[] and s['boxes']==[] and s['parc']==[] and s['inst']==[] and s['limits']=={} and s['opening'] is None)
    ctx.close()
print('\nRESUMO: %d/%d testes aprovados'%(sum(1 for r in R if r[1]),len(R)))
json.dump(R,open(TMP+'/result.json','w'))
