# Testes automatizados do Wolfin

Estrutura leve, sem mudar o app: **Python + Playwright** (um navegador Chromium controlado por script) e Node só para checar sintaxe.
Todos os testes usam **dados 100% fictícios**, em navegadores novos e isolados — **nunca** leem nem alteram dados reais de ninguém.

## Como rodar (no computador)
```bash
pip install -r tests/requirements.txt
python -m playwright install chromium
python tests/run_all.py                 # suítes principais
python tests/run_all.py --full          # + visual/experiência (tutorial, tema, mascote, boas-vindas...)
python tests/run_all.py --grupo seguranca
python tests/run_all.py --suite armazenamento
python tests/run_all.py --list          # lista tudo
```
O comando termina com **código 1 se qualquer teste falhar**. Um resumo fica em `tests/report/resumo.md` e um log por suíte em `tests/report/<suite>.log`.

## No GitHub (automático)
`.github/workflows/tests.yml` roda a cada envio (push) para `main`, em pull requests e manualmente (aba **Actions → Testes → Run workflow**).
Cada área é um job separado — o job vermelho mostra **qual área** falhou; abra o job para ver a lista de falhas (com anotações), e a página do resumo da execução tem a tabela completa. Os logs ficam como artefato por 14 dias.

## O que cada grupo cobre
| Grupo | Suítes | Conferência |
|---|---|---|
| estatico | `estatico` | sintaxe do JavaScript (app e `sw.js`), HTML, manifesto, ícones, versão, tamanho, app abre sem erros |
| calculos | `calculos_nucleo`, `calculos_situacao`, `correcoes_auditoria` (parcelas × saldo, aviso único, rótulos, workflows) | saldo, fluxo, dívidas, caixinhas, parcelas, cartões e situação financeira: 150 cenários aleatórios contra um recálculo independente em Python (`lib/oraculo.py`) |
| pagamentos | `pagamentos_cartao` | pagamento parcial, quitação, valor acima do devido, fatura quitada, cliques repetidos, dados antigos |
| armazenamento | `armazenamento` | salvamento normal e protegido, falhas de gravação, ordem das gravações, fechar durante o salvamento, duas janelas |
| seguranca | `seguranca_acesso`, `seguranca_tentativas`, `csp_privacidade` (CSP, só fala com o próprio site, bloqueio de exfiltração) | login, senha incorreta, criptografia, código de recuperação, espera progressiva, estado em 3 locais |
| backups | `backup_importacao`, `backup_modo_protegido`, `backup_basico` | exportar/importar, arquivos inválidos/corrompidos/duplicados, versões antigas (`fixtures/backups`), criptografados |
| relatorios | `relatorios` | resumo, indicadores, comprometimento, recorrentes, dívidas, comparação e gráficos conferidos com o Python |
| navegacao | `navegacao_rapida`, `auditoria_geral`, `acessibilidade` | telas, menus, janelas, formulários, teclado, foco, leitor de tela, contraste, redução de movimento |
| pwa | `pwa_instalacao`, `pwa_cache_atualizacao` | instalável, offline, atualização do Service Worker, caches próprios, outros projetos intactos |
| extras | intro animada, mascotes oficiais (10 = avatares), tutorial, tema Pérola, mascotes oficiais, boas-vindas, login visual, acabamento | experiência e visual (rodam no GitHub e com `--full`) |

## Se um teste falhar
1. Leia a linha `FAIL ...`: ela diz **o que** foi verificado e traz o valor/detalhe que deu errado.
2. Rode só aquela suíte: `python tests/run_all.py --suite <nome>`.
3. Se a mudança no app foi **intencional** e o teste é de "referência guardada" (golden), regrave: `WS_UPDATE_GOLDEN=1 python tests/suites/<nome>.py` e confira o que mudou em `tests/fixtures/golden/` antes de enviar.
4. Suíte que só passa na repetição aparece como "⚠️ instável" no resumo — não ignore: investigue.

## Organização
- `suites/` — uma suíte por arquivo (cada uma imprime `PASS`/`FAIL` e o total `N / M`).
- `lib/` — servidor local, caminhos, contraste, recálculo independente (`oraculo.py`), instrumentos de falha (`instr.js`).
- `fixtures/` — dados fictícios, backups de versões antigas, referências guardadas.
- `tools/` — utilitários de manutenção.

## Fonte
Os testes de layout usam a fonte **Inter** (a primeira do app). O workflow a instala (`fonts-inter`); no seu computador instale também, senão o navegador usa uma fonte mais larga e testes de "texto cortado" podem falhar sem haver defeito.

## Limites (o que os testes NÃO provam)
Rodam em Chromium simulado (inclusive tamanhos/modelos Android emulados). **Não** substituem testar em celular de verdade, com TalkBack, nem a hospedagem real do GitHub Pages.

## Ganchos de teste
`window.__WS_NOTOUR=1` desliga o tutorial, a intro, o aviso de parcelas e a CSP; `window.__WS_NOCSP=1` desliga só a CSP (o Playwright avalia texto como script, o que a CSP proíbe); `window.__WS_INTRO="css"` força a intro em CSS. A suíte `csp_privacidade` roda **sem** esses ganchos, como o usuário real.
